import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../models/suggested_route.dart';
import '../../services/suggested_route_service.dart';

const LatLng kDefaultMapCenter = LatLng(56.012027, 92.867245); // Центр карты как на экране гонок

class SuggestRouteScreen extends StatefulWidget {
  const SuggestRouteScreen({Key? key}) : super(key: key);

  @override
  State<SuggestRouteScreen> createState() => _SuggestRouteScreenState();
}

class _SuggestRouteScreenState extends State<SuggestRouteScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _linkController = TextEditingController();

  List<LatLng> _routePoints = [];
  double _routeLength = 0.0;
  bool _isLoading = false;

  void _addPoint(LatLng point) {
    setState(() {
      _routePoints.add(point);
      _routeLength = _calculateLength(_routePoints);
    });
  }

  void _clearRoute() {
    setState(() {
      _routePoints.clear();
      _routeLength = 0.0;
    });
  }

  double _calculateLength(List<LatLng> points) {
    if (points.length < 2) return 0.0;
    final Distance distance = const Distance();
    double sum = 0.0;
    for (int i = 1; i < points.length; i++) {
      sum += distance(points[i - 1], points[i]);
    }
    return sum / 1000.0; // в километрах
  }

  Future<void> _submit() async {
    if (_formKey.currentState!.validate() && _routePoints.length > 1) {
      setState(() { _isLoading = true; });
      try {
        final route = SuggestedRoute(
          name: _nameController.text.trim(),
          description: _descController.text.trim(),
          routePoints: _routePoints.map((p) => [p.latitude, p.longitude]).toList(),
          link: _linkController.text.trim().isEmpty ? null : _linkController.text.trim(),
        );
        await SuggestedRouteService().sendSuggestedRoute(route);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Маршрут отправлен на модерацию')),
        );
        _formKey.currentState!.reset();
        _clearRoute();
        _nameController.clear();
        _descController.clear();
        _linkController.clear();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка при отправке маршрута: $e')),
        );
      } finally {
        setState(() { _isLoading = false; });
      }
    } else if (_routePoints.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Нарисуйте маршрут на карте')), 
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text(
              'ПРЕДЛОЖИТЬ',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 18,
                letterSpacing: 1.8,
                color: Colors.black,
              ),
            ),
            Text(
              'МАРШРУТ',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 18,
                letterSpacing: 1.8,
                color: Colors.black,
              ),
            ),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: 'Название маршрута',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) =>
                          value == null || value.isEmpty ? 'Введите название' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _descController,
                      decoration: const InputDecoration(
                        labelText: 'Описание',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 2,
                      validator: (value) =>
                          value == null || value.isEmpty ? 'Введите описание' : null,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Text('Длина маршрута: '),
                        Text(_routeLength.toStringAsFixed(2) + ' км'),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 300,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: FlutterMap(
                    options: MapOptions(
                      center: kDefaultMapCenter,
                      zoom: 14.0,
                      onTap: (tapPosition, point) {
                        _addPoint(point);
                      },
                    ),
                    children: [
                      TileLayer(
                        urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                        subdomains: const ['a', 'b', 'c'],
                      ),
                      PolylineLayer(
                        polylines: [
                          Polyline(
                            points: _routePoints,
                            color: Colors.green,
                            strokeWidth: 4.0,
                          ),
                        ],
                      ),
                      MarkerLayer(
                        markers: _routePoints
                            .map((point) => Marker(
                                  point: point,
                                  width: 24,
                                  height: 24,
                                  child: const Icon(
                                    Icons.location_on,
                                    color: Colors.red,
                                    size: 24,
                                  ),
                                ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _clearRoute,
                      child: const Text(
                        'Очистить',
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _submit,
                      child: _isLoading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text(
                              'Предложить',
                              style: TextStyle(fontSize: 10),
                            ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
} 