import 'package:flutter/material.dart';
import 'package:frontend/screens/main/home_content_screen.dart'; // Import the HomeContentScreen
import 'package:frontend/screens/main/race_map_screen.dart'; // Import RaceMapScreen
// Добавляю импорт
import 'package:frontend/screens/main/friends_screen.dart'; // Добавляю импорт для FriendsScreen
import 'package:frontend/screens/main/profile_screen.dart';
import 'package:frontend/screens/main/activity_history_screen.dart'; // Добавляю импорт
import 'package:frontend/services/auth_service.dart'; // Import AuthService


class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  Map<String, dynamic>? _profileData;
  List<dynamic>? _activeChallengesData;

  void _onItemTapped(int index) {
    print('MainScreenState: _onItemTapped called with index: $index'); // Debug print
    setState(() {
      _selectedIndex = index;
    });
  }

  void _goToMapScreen() {
    print('MainScreenState: _goToMapScreen called'); // Debug print
    _onItemTapped(1); // Index for the Map tab is 1
  }

  @override
  void initState() {
    super.initState();
    print('MainScreenState: initState'); // Debug print
    _fetchProfileData(); // Вызов загрузки данных
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Обновлять данные при каждом возврате на главный экран
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    try {
      // Убедитесь, что вы извлекаете данные из Response
      final profileResponse = await AuthService().getProfile();
      final activeChallengesResponse = await AuthService().getUserChallenges();
      setState(() {
        _profileData = profileResponse.data; // Используйте .data для получения тела ответа
        _activeChallengesData = activeChallengesResponse.data; // Используйте .data для получения тела ответа
      });
    } catch (e) {
      print('Error fetching profile or challenges data: $e');
      // TODO: Обработайте ошибку соответствующим образом
    }
  }

  @override
  Widget build(BuildContext context) {
    print('MainScreenState: build method called. Selected index: $_selectedIndex'); // Debug print
    // Create screens list dynamically in the build method
    final List<Widget> screens = [
      HomeContentScreen(
        onStartRacePressed: _goToMapScreen,
        profileData: _profileData, 
        activeChallengesData: _activeChallengesData, 
      ),
      const RaceMapScreen(),
      const ActivityHistoryScreen(), 
      const FriendsScreen(), 
      const ProfileScreen(),
    ];

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _fetchProfileData,
        child: IndexedStack(
        index: _selectedIndex,
          children: screens,
        ),
      ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Theme.of(context).colorScheme.primary,
          unselectedItemColor: Colors.grey,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: 'Главная',
            ),
            BottomNavigationBarItem(
            icon: Icon(Icons.map_outlined),
              label: 'Карта',
            ),
            BottomNavigationBarItem(
            icon: Icon(Icons.run_circle_outlined),
            label: 'История активности',
            ),
            BottomNavigationBarItem(
            icon: Icon(Icons.people_outlined),
              label: 'Друзья',
            ),
            BottomNavigationBarItem(
            icon: Icon(Icons.person_outlined),
              label: 'Профиль',
            ),
          ],
        showSelectedLabels: false,
        showUnselectedLabels: false,
        ),
    );
  }
}
