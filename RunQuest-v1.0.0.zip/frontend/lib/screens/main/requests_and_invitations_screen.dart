import 'package:flutter/material.dart';
import 'package:frontend/models/friend_request_display_item.dart'; // Убедитесь, что этот импорт правильный
import 'package:frontend/models/joint_run_invitation_display_item.dart'; // Import JointRunInvitationDisplayItem
import 'package:frontend/models/planned_joint_run_display_item.dart'; // Import new model for planned joint runs
import 'package:frontend/services/friend_service.dart'; // Возможно понадобится для управления запросами
import 'package:frontend/services/auth_service.dart'; // Для получения текущего пользователя, если понадобится

class RequestsAndInvitationsScreen extends StatefulWidget {
  final List<FriendRequestDisplayItem> pendingRequests;
  final List<FriendRequestDisplayItem> sentRequests;
  final Future<void> Function()? onRefresh;

  const RequestsAndInvitationsScreen({
    super.key,
    required this.pendingRequests,
    required this.sentRequests,
    this.onRefresh,
  });

  @override
  State<RequestsAndInvitationsScreen> createState() => _RequestsAndInvitationsScreenState();
}

class _RequestsAndInvitationsScreenState extends State<RequestsAndInvitationsScreen> {
  final FriendService _friendService = FriendService();
  List<JointRunInvitationDisplayItem> _receivedInvitations = [];
  List<JointRunInvitationDisplayItem> _sentInvitations = [];
  List<PlannedJointRunDisplayItem> _plannedRuns = []; // New list for planned runs
  bool _isLoadingInvitations = true;
  bool _isLoadingPlannedRuns = true; // New loading flag

  @override
  void initState() {
    super.initState();
    _fetchJointRunInvitations();
    _fetchPlannedJointRuns(); // Fetch planned runs on init
  }

  Future<void> _fetchJointRunInvitations() async {
    setState(() {
      _isLoadingInvitations = true;
    });
    try {
      final received = await _friendService.fetchReceivedJointRunInvitations();
      final sent = await _friendService.fetchSentJointRunInvitations();
      setState(() {
        _receivedInvitations = received;
        _sentInvitations = sent;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка загрузки приглашений на совместные пробежки: $e')),
      );
    } finally {
      setState(() {
        _isLoadingInvitations = false;
      });
    }
  }

  Future<void> _fetchPlannedJointRuns() async {
    setState(() {
      _isLoadingPlannedRuns = true;
    });
    try {
      final planned = await _friendService.fetchPlannedJointRuns();
      setState(() {
        _plannedRuns = planned;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка загрузки запланированных совместных пробежек: $e')),
      );
    } finally {
      setState(() {
        _isLoadingPlannedRuns = false;
      });
    }
  }

  Future<void> _acceptFriendRequest(int requestId) async {
    try {
      await _friendService.acceptFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья принят!')),
      );
      // Возможно, потребуется обновить данные на родительском экране или здесь
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка принятия запроса: $e')),
      );
    }
  }

  Future<void> _rejectFriendRequest(int requestId) async {
    if (!mounted) return;
    try {
      await _friendService.rejectFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья отклонен.')),
      );
      // Возможно, потребуется обновить данные на родительском экране или здесь
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка отклонения запроса: $e')),
      );
    }
  }

  Future<void> _cancelFriendRequest(int requestId) async {
    if (!mounted) return;
    try {
      await _friendService.cancelSentFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья отменен.')),
      );
      // Возможно, потребуется обновить данные на родительском экране или здесь
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка отмены запроса: $e')),
      );
    }
  }

  // New methods for Joint Run Invitations actions
  Future<void> _acceptJointRunInvitation(int invitationId) async {
    try {
      await _friendService.acceptJointRunInvitation(invitationId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Приглашение на пробежку принято!')),
      );
      _fetchJointRunInvitations(); // Refresh invitations
      _fetchPlannedJointRuns(); // Also refresh planned runs as accepting creates one
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка при принятии приглашения: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _rejectJointRunInvitation(int invitationId) async {
    try {
      await _friendService.rejectJointRunInvitation(invitationId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Приглашение на пробежку отклонено.')),
      );
      _fetchJointRunInvitations(); // Refresh invitations
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка при отклонении приглашения: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _cancelJointRunInvitation(int invitationId) async {
    try {
      await _friendService.cancelJointRunInvitation(invitationId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Приглашение на пробежку отменено.')),
      );
      _fetchJointRunInvitations(); // Refresh invitations
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка при отмене приглашения: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _refreshAllData() async {
    await Future.wait([
      _fetchJointRunInvitations(),
      _fetchPlannedJointRuns(),
    ]);
    if (widget.onRefresh != null) {
      await widget.onRefresh!();
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3, // Три основные вкладки: "Запросы на дружбу", "Приглашения на пробежки" и "Запланированные пробежки"
      child: Column(
        children: [
          const TabBar(
            indicatorColor: Color(0xFFD5FF2E), // Неоново-зеленый индикатор
            labelColor: Color(0xFF00C507), // Неоново-зеленый для выбранной вкладки
            unselectedLabelColor: Colors.grey, // Серый для невыбранной вкладки
            labelStyle: TextStyle(
              fontFamily: 'Satoshi',
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            unselectedLabelStyle: TextStyle(
              fontFamily: 'Satoshi',
              fontWeight: FontWeight.normal,
              fontSize: 14,
            ),
            tabs: [
              Tab(icon: Icon(Icons.group_add)), // Иконка для 'Запросы на дружбу'
              Tab(icon: Icon(Icons.mail)), // Иконка для 'Приглашения на пробежки'
              Tab(icon: Icon(Icons.calendar_month_outlined)), // Иконка для 'Запланированные пробежки'
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                // Вкладка "Запросы на дружбу"
                RefreshIndicator(
                  onRefresh: _refreshAllData,
                  child: DefaultTabController(
                    length: 2,
                  child: Column(
                    children: [
                      const TabBar(
                        tabs: [
                          Tab(text: 'Входящие'),
                          Tab(text: 'Исходящие'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            widget.pendingRequests.isEmpty
                                ? const Center(child: Text('Нет ожидающих запросов.', style: TextStyle(fontFamily: 'Satoshi', fontSize: 16, color: Colors.grey)))
                                : ListView.builder(
                                    itemCount: widget.pendingRequests.length,
                                    itemBuilder: (context, index) {
                                      final request = widget.pendingRequests[index];
                                      return Container(
                                        margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                            borderRadius: BorderRadius.circular(20.0),
                                          border: Border.all(
                                              color: const Color(0xFF7B7B7B),
                                            width: 1.0,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                                color: Colors.black.withOpacity(0.17),
                                              spreadRadius: 0,
                                                blurRadius: 5.2,
                                                offset: const Offset(0, 0),
                                            ),
                                          ],
                                        ),
                                        child: Padding(
                                            padding: const EdgeInsets.all(16.0),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      border: Border.all(
                                                          color: const Color(0xFF000000),
                                                        width: 2.0,
                                                        ),
                                                    ),
                                                    child: CircleAvatar(
                                                        radius: 25,
                                                        backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2),
                                                      child: Text(
                                                        request.user.username[0].toUpperCase(),
                                                        style: const TextStyle(
                                                          fontFamily: 'Satoshi',
                                                          fontWeight: FontWeight.bold,
                                                            color: Color(0xFF000000),
                                                          ),
                                                      ),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 16),
                                              Text(
                                                request.user.username,
                                                style: const TextStyle(
                                                  fontFamily: 'Satoshi',
                                                  fontWeight: FontWeight.bold,
                                                      fontSize: 20,
                                                      color: Color(0xFF111827),
                                                ),
                                                  ),
                                                ],
                                              ),
                                                const SizedBox(height: 16),
                                              Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                                  Expanded(
                                                    child: ElevatedButton(
                                              onPressed: () => _acceptFriendRequest(request.id),
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor: const Color(0xFFD7FF35),
                                                          shape: const StadiumBorder(),
                                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                                                          elevation: 0,
                                                        ),
                                                        child: const Text('ПРИНЯТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 16),
                                                  Expanded(
                                                    child: ElevatedButton(
                                              onPressed: () => _rejectFriendRequest(request.id),
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor: const Color(0xFFFF3538),
                                                          shape: const StadiumBorder(),
                                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                                                          elevation: 0,
                                                        ),
                                                        child: const Text('ОТКЛОНИТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                            widget.sentRequests.isEmpty
                                ? const Center(child: Text('Нет исходящих запросов.', style: TextStyle(fontFamily: 'Satoshi', fontSize: 16, color: Colors.grey)))
                                : ListView.builder(
                                    itemCount: widget.sentRequests.length,
                                    itemBuilder: (context, index) {
                                      final request = widget.sentRequests[index];
                                      return Container(
                                        margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                            borderRadius: BorderRadius.circular(20.0),
                                          border: Border.all(
                                              color: const Color(0xFF7B7B7B),
                                            width: 1.0,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                                color: Colors.black.withOpacity(0.17),
                                              spreadRadius: 0,
                                                blurRadius: 5.2,
                                                offset: const Offset(0, 0),
                                            ),
                                          ],
                                        ),
                                        child: Padding(
                                            padding: const EdgeInsets.all(16.0),
                                          child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      border: Border.all(
                                                          color: const Color(0xFF000000),
                                                        width: 2.0,
                                                        ),
                                                    ),
                                                    child: CircleAvatar(
                                                        radius: 25,
                                                        backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2),
                                                      child: Text(
                                                        request.user.username[0].toUpperCase(),
                                                        style: const TextStyle(
                                                          fontFamily: 'Satoshi',
                                                          fontWeight: FontWeight.bold,
                                                            color: Color(0xFF000000),
                                                          ),
                                                      ),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 16),
                                              Text(
                                                request.user.username,
                                                style: const TextStyle(
                                                  fontFamily: 'Satoshi',
                                                  fontWeight: FontWeight.bold,
                                                      fontSize: 20,
                                                      color: Color(0xFF111827),
                                                ),
                                                  ),
                                                ],
                                              ),
                                                const SizedBox(height: 16),
                                              Align(
                                                alignment: Alignment.centerRight,
                                                child: ElevatedButton(
                                          onPressed: () => _cancelFriendRequest(request.id),
                                                  style: ElevatedButton.styleFrom(
                                                      backgroundColor: const Color(0xFFFF3538),
                                                      shape: const StadiumBorder(),
                                                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                                      elevation: 0,
                                                    ),
                                                    child: const Text('ОТМЕНИТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                          ],
                        ),
                      ),
                    ],
                    ),
                  ),
                ),
                // Вкладка "Приглашения на пробежки"
                RefreshIndicator(
                  onRefresh: _refreshAllData,
                  child: DefaultTabController(
                    length: 2,
                  child: Column(
                    children: [
                      const TabBar(
                        tabs: [
                          Tab(text: 'Входящие'),
                          Tab(text: 'Исходящие'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _isLoadingInvitations
                                ? const Center(child: CircularProgressIndicator())
                                : _receivedInvitations.isEmpty
                                    ? const Center(child: Text('Нет приглашений на пробежки.', style: TextStyle(fontFamily: 'Satoshi', fontSize: 16, color: Colors.grey)))
                                    : ListView.builder(
                                        itemCount: _receivedInvitations.length,
                                        itemBuilder: (context, index) {
                                          final invitation = _receivedInvitations[index];
                                          return Container(
                                            margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(20.0), // Закругление углов
                                              border: Border.all(
                                                color: const Color(0xFF7B7B7B), // Серый цвет границы
                                                width: 1.0,
                                            ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black.withOpacity(0.17), // Тень
                                                  spreadRadius: 0,
                                                  blurRadius: 5.2,
                                                  offset: const Offset(0, 0),
                                                ),
                                              ],
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(16.0), // Отступы
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Container(
                                                        decoration: BoxDecoration(
                                                          shape: BoxShape.circle,
                                                          border: Border.all(
                                                            color: const Color(0xFF000000), // Черный цвет обводки из friends_screen
                                                            width: 2.0,
                                                          ),
                                                        ),
                                                        child: CircleAvatar(
                                                          radius: 25, // Радиус 25, чтобы соответствовать friends_screen
                                                          backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2), // Цвет из friends_screen
                                                          child: Text(
                                                            invitation.sender.username[0].toUpperCase(),
                                                            style: const TextStyle(
                                                              fontFamily: 'Satoshi',
                                                              fontWeight: FontWeight.bold,
                                                              color: Color(0xFF000000), // Цвет текста из friends_screen
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 16),
                                                      Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'От: ${invitation.sender.username}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontWeight: FontWeight.bold,
                                                                fontSize: 18,
                                                                color: Color(0xFF111827),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 4),
                                                  Text(
                                                    'Когда: ${invitation.formattedSuggestedTime}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontSize: 14,
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                                  Text(
                                                    'Где: ${invitation.meetingLocation}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontSize: 14,
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                                  if (invitation.comments != null && invitation.comments!.isNotEmpty)
                                                    Padding(
                                                      padding: const EdgeInsets.only(top: 4.0),
                                                      child: Text(
                                                        'Комментарий: ${invitation.comments}',
                                                        style: const TextStyle(
                                                          fontFamily: 'Satoshi',
                                                          fontSize: 14,
                                                          color: Colors.grey,
                                                        ),
                                                      ),
                                                    ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(height: 16),
                                                  // Action buttons for invitations
                                                  Align(
                                                    alignment: Alignment.centerRight,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.end, // Выравниваем кнопки по правому краю
                                                    children: [
                                                      if (invitation.status == 'pending') ...[
                                                        ElevatedButton(
                                                          onPressed: () => _acceptJointRunInvitation(invitation.id),
                                                            style: ElevatedButton.styleFrom(
                                                              backgroundColor: const Color(0xFFD7FF35),
                                                              shape: const StadiumBorder(),
                                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                                                              elevation: 0,
                                                            ),
                                                            child: const Text('ПРИНЯТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                          ),
                                                          const SizedBox(width: 8), // Добавляем горизонтальный отступ между кнопками
                                                        ElevatedButton(
                                                          onPressed: () => _rejectJointRunInvitation(invitation.id),
                                                            style: ElevatedButton.styleFrom(
                                                              backgroundColor: const Color(0xFFFF3538),
                                                              shape: const StadiumBorder(),
                                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                                                              elevation: 0,
                                                            ),
                                                            child: const Text('ОТКЛОНИТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                        ),
                                                          ] 
                                                          else if (invitation.status == 'accepted') ...[
                                                          Chip(
                                                            label: const Text('Принято', style: TextStyle(color: Colors.white, fontFamily: 'Satoshi')),
                                                            backgroundColor: const Color(0xFFD7FF35),
                                                          ),
                                                          ] 
                                                          else if (invitation.status == 'rejected') ...[
                                                          Chip(
                                                            label: const Text('Отклонено', style: TextStyle(color: Colors.white, fontFamily: 'Satoshi')),
                                                            backgroundColor: const Color(0xFFFF3538),
                                                          ),
                                                          ] 
                                                          else if (invitation.status == 'cancelled') ...[
                                                            Chip(
                                                              label: const Text('Отменено', style: TextStyle(color: Colors.white, fontFamily: 'Satoshi')),
                                                              backgroundColor: const Color(0xFF00C6FF),
                                                            ),
                                                        ],
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                            _isLoadingInvitations
                                ? const Center(child: CircularProgressIndicator())
                                : _sentInvitations.isEmpty
                                    ? const Center(child: Text('Вы не отправляли приглашений на пробежки.', style: TextStyle(fontFamily: 'Satoshi', fontSize: 16, color: Colors.grey)))
                                    : ListView.builder(
                                        itemCount: _sentInvitations.length,
                                        itemBuilder: (context, index) {
                                          final invitation = _sentInvitations[index];
                                          return Container(
                                            margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(20.0), // Закругление углов как в SVG
                                              border: Border.all(
                                                color: const Color(0xFF7B7B7B), // Серый цвет границы как в SVG
                                                width: 1.0,
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black.withOpacity(0.17), // Тень как в SVG
                                                  spreadRadius: 0,
                                                  blurRadius: 5.2,
                                                  offset: const Offset(0, 0),
                                                ),
                                              ],
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(16.0), // Отступы внутри карточки
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Container(
                                                        decoration: BoxDecoration(
                                                          shape: BoxShape.circle,
                                                          border: Border.all(
                                                            color: const Color(0xFF000000), // Черный цвет обводки из friends_screen
                                                            width: 2.0,
                                                          ),
                                                        ),
                                                        child: CircleAvatar(
                                                          radius: 25, // Радиус 25, чтобы соответствовать friends_screen
                                                          backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2), // Цвет из friends_screen
                                                          child: Text(
                                                            invitation.recipient.username[0].toUpperCase(),
                                                            style: const TextStyle(
                                                              fontFamily: 'Satoshi',
                                                              fontWeight: FontWeight.bold,
                                                              color: Color(0xFF000000), // Цвет текста из friends_screen
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(width: 16),
                                                      Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'Кому: ${invitation.recipient.username}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontWeight: FontWeight.bold,
                                                                fontSize: 18,
                                                                color: Color(0xFF111827),
                                                    ),
                                                  ),
                                                  const SizedBox(height: 4),
                                                  Text(
                                                    'Когда: ${invitation.formattedSuggestedTime}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontSize: 14,
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                                  Text(
                                                    'Где: ${invitation.meetingLocation}',
                                                    style: const TextStyle(
                                                      fontFamily: 'Satoshi',
                                                      fontSize: 14,
                                                      color: Colors.grey,
                                                    ),
                                                  ),
                                                  if (invitation.comments != null && invitation.comments!.isNotEmpty)
                                                    Padding(
                                                      padding: const EdgeInsets.only(top: 4.0),
                                                      child: Text(
                                                        'Комментарий: ${invitation.comments}',
                                                        style: const TextStyle(
                                                          fontFamily: 'Satoshi',
                                                          fontSize: 14,
                                                          color: Colors.grey,
                                                        ),
                                                      ),
                                                    ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  const SizedBox(height: 16),
                                                  Align(
                                                    alignment: Alignment.centerRight,
                                                    child: ElevatedButton(
                                                          onPressed: () => _cancelJointRunInvitation(invitation.id),
                                                          style: ElevatedButton.styleFrom(
                                                        backgroundColor: const Color(0xFFFF3538),
                                                        shape: const StadiumBorder(),
                                                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                                        elevation: 0,
                                                        ),
                                                      child: const Text('ОТМЕНИТЬ', style: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontSize: 14)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                          ],
                        ),
                      ),
                    ],
                    ),
                  ),
                ),
                // Вкладка "Запланированные пробежки" (Planned Runs)
                RefreshIndicator(
                  onRefresh: _refreshAllData,
                  child: _isLoadingPlannedRuns
                    ? const Center(child: CircularProgressIndicator())
                    : _plannedRuns.isEmpty
                        ? const Center(child: Text('Нет запланированных пробежек.', style: TextStyle(fontFamily: 'Satoshi', fontSize: 16, color: Colors.grey)))
                        : ListView.builder(
                            itemCount: _plannedRuns.length,
                            itemBuilder: (context, index) {
                              final run = _plannedRuns[index];
                              return Container(
                                margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20.0), // Закругление углов
                                  border: Border.all(
                                    color: const Color(0xFF7B7B7B), // Серый цвет границы
                                    width: 1.0,
                                ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.17), // Тень
                                      spreadRadius: 0,
                                      blurRadius: 5.2,
                                      offset: const Offset(0, 0),
                                    ),
                                  ],
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0), // Отступы
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: const Color(0xFF000000), // Черный цвет обводки из friends_screen
                                                width: 2.0,
                                              ),
                                            ),
                                            child: CircleAvatar(
                                              radius: 25, // Радиус 25, чтобы соответствовать friends_screen
                                              backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2), // Цвет из friends_screen
                                              child: Text(
                                                run.participantsText[0].toUpperCase(), // Используем первую букву участника
                                                style: const TextStyle(
                                                  fontFamily: 'Satoshi',
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFF000000), // Цвет текста из friends_screen
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 16),
                                          Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Участники: ${run.participantsText}',
                                        style: const TextStyle(
                                          fontFamily: 'Satoshi',
                                          fontWeight: FontWeight.bold,
                                                    fontSize: 18,
                                                    color: Color(0xFF111827),
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'Когда: ${run.formattedSuggestedTime}',
                                        style: const TextStyle(
                                          fontFamily: 'Satoshi',
                                          fontSize: 14,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      Text(
                                        'Где: ${run.meetingLocation ?? run.suggestedRacetrackName ?? 'Не указано'}',
                                        style: const TextStyle(
                                          fontFamily: 'Satoshi',
                                          fontSize: 14,
                                          color: Colors.grey,
                                        ),
                                      ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                            ),            
                            
                          ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}