import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart';
import 'package:frontend/services/activity_feed_service.dart';

// Custom shape for buttons and cards with sharp cuts
class ZzzCustomShapeBorder extends ShapeBorder {
  final double cutSize;

  const ZzzCustomShapeBorder({this.cutSize = 10.0});

  @override
  EdgeInsetsGeometry get dimensions => const EdgeInsets.only();

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) {
    return getOuterPath(rect, textDirection: textDirection);
  }

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    return Path()
      ..moveTo(rect.topLeft.dx + cutSize, rect.topLeft.dy)
      ..lineTo(rect.topRight.dx - cutSize, rect.topRight.dy)
      ..lineTo(rect.topRight.dx, rect.topRight.dy + cutSize)
      ..lineTo(rect.bottomRight.dx, rect.bottomRight.dy - cutSize)
      ..lineTo(rect.bottomRight.dx - cutSize, rect.bottomRight.dy)
      ..lineTo(rect.bottomLeft.dx + cutSize, rect.bottomLeft.dy)
      ..lineTo(rect.bottomLeft.dx, rect.bottomLeft.dy - cutSize)
      ..lineTo(rect.topLeft.dx, rect.topLeft.dy + cutSize)
      ..close();
  }

  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {}

  @override
  ShapeBorder scale(double t) {
    return ZzzCustomShapeBorder(cutSize: cutSize * t);
  }
}

enum FilterType { my, all, available } // Define enum outside the class to be accessible everywhere

class AchievementsScreen extends StatefulWidget {
  final List<dynamic>? allAchievements;
  final List<dynamic>? userAchievements;
  final int? userId;
  final bool showEarnedOnly;

  const AchievementsScreen({
    super.key,
    this.allAchievements,
    this.userAchievements,
    this.userId,
    this.showEarnedOnly = false,
  });

  @override
  State<AchievementsScreen> createState() => _AchievementsScreenState();
}

class _AchievementsScreenState extends State<AchievementsScreen> {
  List<dynamic> _fetchedAllAchievements = [];
  List<dynamic> _fetchedUserAchievements = [];
  bool _isLoading = true;

  // Define colors based on Zenless Zone Zero aesthetic
  static const Color primaryBackgroundColor = Colors.white; // Чистый белый
  static const Color accentColor = Color(0xFF4CAF50); // Ярко-зеленый
  static const Color secondaryAccentColor = Color(0xFF00BFFF); // Электрический синий
  static const Color textColor = Colors.black87; // Темно-серый для основного текста
  static const Color mutedTextColor = Colors.grey; // Для скрытых элементов

  @override
  void initState() {
    super.initState();
    _fetchAchievements();
  }

  @override
  Widget build(BuildContext context) {
    // Сопоставляем userAchievements по achievement id
    final userAchMap = {for (var ua in _fetchedUserAchievements)
      (ua['achievement'] is int ? ua['achievement'] : ua['achievement']?['id']): ua};

    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Достижения', style: TextStyle(color: textColor))),
        body: const Center(child: CircularProgressIndicator(color: Color(0xFF4CAF50))),
        backgroundColor: primaryBackgroundColor,
      );
    }

    return Theme(
      data: Theme.of(context).copyWith(
        scaffoldBackgroundColor: primaryBackgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: primaryBackgroundColor,
          elevation: 0,
          titleTextStyle: TextStyle(
            fontFamily: 'AgencyFB', // Предполагаемый "техногенный" шрифт
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
        tabBarTheme: TabBarTheme(
          labelColor: Color(0xFF4CAF50),
          unselectedLabelColor: mutedTextColor,
          indicator: UnderlineTabIndicator(
            borderSide: BorderSide(width: 4.0, color: Color(0xFF4CAF50)),
          ),
          labelStyle: TextStyle(
            fontFamily: 'AgencyFB',
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'AgencyFB',
            fontSize: 16,
          ),
        ),
        listTileTheme: ListTileThemeData(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          shape: ZzzCustomShapeBorder(cutSize: 8.0), // Применяем кастомную форму
          tileColor: Colors.grey[50], // Светлый фон для карточек
          titleTextStyle: TextStyle(
            fontFamily: 'AgencyFB',
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
          subtitleTextStyle: TextStyle(
            fontFamily: 'Roboto', // Обычный, хорошо читаемый шрифт
            fontSize: 14,
            color: textColor.withOpacity(0.7),
          ),
        ),
        progressIndicatorTheme: const ProgressIndicatorThemeData(
          color: Color(0xFF4CAF50),
          linearTrackColor: mutedTextColor,
        ),
        // Add text theme for general text styles
        textTheme: Theme.of(context).textTheme.copyWith(
          bodyLarge: const TextStyle(color: textColor, fontFamily: 'Roboto'),
          bodyMedium: const TextStyle(color: textColor, fontFamily: 'Roboto'),
          bodySmall: const TextStyle(color: textColor, fontFamily: 'Roboto'),
        ),
      ),
      child: widget.showEarnedOnly
          ? Scaffold(
              appBar: AppBar(
                title: Text('Достижения пользователя ${widget.userId}'),
              ),
              body: _buildAchievementList(_fetchedAllAchievements, userAchMap, FilterType.my),
            )
          : DefaultTabController(
              length: 3, // Мои, Все, Доступные
              initialIndex: 1, // Start on 'Все' tab
              child: Scaffold(
                appBar: AppBar(
                  title: const Text('Достижения'),
                  bottom: const TabBar(
                    tabs: [
                      Tab(text: 'Мои'),
                      Tab(text: 'Все'),
                      Tab(text: 'Доступные'),
                    ],
                  ),
                ),
                body: TabBarView(
                  children: [
                    _buildAchievementList(_fetchedAllAchievements, userAchMap, FilterType.my), // Мои
                    _buildAchievementList(_fetchedAllAchievements, userAchMap, FilterType.all), // Все
                    _buildAchievementList(_fetchedAllAchievements, userAchMap, FilterType.available), // Доступные
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildAchievementList(List<dynamic> allAchievements, Map<dynamic, dynamic> userAchMap, FilterType filterType) {
    List<Map<String, dynamic>> filteredAchievements = [];

    for (var achievement in allAchievements.whereType<Map<String, dynamic>>()) {
      final userAch = userAchMap[achievement['id']];
      final bool isCompleted = userAch != null && (userAch['completed'] == true);
      final bool isSecret = achievement['is_secret'] == true;

      switch (filterType) {
        case FilterType.my:
          if (isCompleted) {
            filteredAchievements.add(achievement);
          }
          break;
        case FilterType.all:
          filteredAchievements.add(achievement);
          break;
        case FilterType.available:
          if (!isCompleted && !isSecret) { // Доступные = не заработанные и не секретные
            filteredAchievements.add(achievement);
          }
          break;
      }
    }

    if (filteredAchievements.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text(
            'Нет достижений для отображения',
            style: TextStyle(color: textColor),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: filteredAchievements.length,
      itemBuilder: (context, index) {
        final a = filteredAchievements[index];
        final userAch = userAchMap[a['id']];
        final bool isSecret = a['is_secret'] == true;
        final bool isCompleted = userAch != null && (userAch['completed'] == true);

        // Handle secret achievements display for 'all' and 'available' tabs
        if (isSecret && !isCompleted && (filterType == FilterType.all || filterType == FilterType.available)) {
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
            shape: Theme.of(context).listTileTheme.shape, // Use the custom shape
            color: Theme.of(context).listTileTheme.tileColor,
            child: ListTile(
              leading: Icon(Icons.help_outline, color: mutedTextColor),
              title: Text('???', style: TextStyle(color: mutedTextColor, fontFamily: 'AgencyFB')),
              subtitle: Text('???', style: TextStyle(color: mutedTextColor.withOpacity(0.7), fontFamily: 'Roboto')),
            ),
          );
        }

        final String name = a['name'] ?? 'Название достижения';
        final String description = a['description'] ?? 'Описание достижения';
        final double progress = (userAch?['progress'] as num?)?.toDouble() ?? 0;
        final double target = (a['target_value'] as num?)?.toDouble() ?? 1;

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
          shape: Theme.of(context).listTileTheme.shape, // Use the custom shape
          color: Theme.of(context).listTileTheme.tileColor,
          child: ListTile(
            leading: a['icon'] != null
                ? Image.network(a['icon'], width: 40, height: 40, fit: BoxFit.cover) // Увеличиваем размер иконки
                : Icon(Icons.emoji_events_outlined, color: const Color(0xFF4CAF50), size: 40), // Используем акцентный цвет
            title: Text(name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(description),
                if (target > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: LinearProgressIndicator(
                      value: progress / target,
                      backgroundColor: Theme.of(context).progressIndicatorTheme.linearTrackColor,
                      color: Theme.of(context).progressIndicatorTheme.color,
                      minHeight: 5,
                    ),
                  ),
                if (target > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 2.0),
                    child: Text(
                      'Прогресс: ${progress.toInt()} / ${target.toInt()}',
                      style: TextStyle(color: textColor.withOpacity(0.8), fontSize: 12),
                    ),
                  ),
              ],
            ),
            trailing: isCompleted
                ? Icon(Icons.check_circle, color: const Color(0xFF4CAF50), size: 28) // Больше и акцентный цвет
                : null,
          ),
        );
      },
    );
  }

  Future<void> _fetchAchievements() async {
    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.userId != null) {
        // Если передан userId, получаем достижения для этого пользователя
        final userAchievementsResponse = await AuthService().getUserAchievements(userId: widget.userId!);
        if (userAchievementsResponse.statusCode == 200) {
          if (userAchievementsResponse.data is List) {
            _fetchedUserAchievements = userAchievementsResponse.data;
          } else if (userAchievementsResponse.data is Map && userAchievementsResponse.data.containsKey('results') && userAchievementsResponse.data['results'] is List) {
            _fetchedUserAchievements = userAchievementsResponse.data['results'];
          }
        } else {
          print('Failed to fetch user achievements for userId ${widget.userId}: ${userAchievementsResponse.statusCode}');
        }

        // Для отображения деталей достижения, всегда нужны все достижения
        final allAchievementsResponse = await ActivityFeedService().getAllAchievements();
        if (allAchievementsResponse.statusCode == 200) {
          _fetchedAllAchievements = allAchievementsResponse.data;
        } else {
          print('Failed to fetch all achievements: ${allAchievementsResponse.statusCode}');
        }

      } else {
        // Если userId не передан, используем данные из виджета (для текущего пользователя)
        _fetchedAllAchievements = widget.allAchievements ?? [];
        _fetchedUserAchievements = widget.userAchievements ?? [];
      }
    } catch (e) {
      print('Error fetching achievements: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
}