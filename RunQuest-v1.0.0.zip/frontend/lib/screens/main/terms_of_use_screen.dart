import 'package:flutter/material.dart';

// Constants for colors
const Color _kAccentColor = Color(0xFFC0FF00); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон

class TermsOfUseScreen extends StatelessWidget {
  const TermsOfUseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'УСЛОВИЯ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
            Text(
              'ИСПОЛЬЗОВАНИЯ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection(
              '1. Введение',
              'Добро пожаловать в RUNQUEST! Настоящие Условия использования (&quot;Условия&quot;) регулируют ваш доступ к нашему мобильному приложению (&quot;Приложение&quot;) и его использование. Пожалуйста, внимательно прочтите эти Условия.',
            ),
            _buildSection(
              '2. Принятие условий',
              'Используя Приложение, вы подтверждаете, что прочитали, поняли и согласны соблюдать настоящие Условия. Если вы не согласны с Условиями, вы не должны использовать Приложение.',
            ),
            _buildSection(
              '3. Использование приложения',
              'Вы соглашаетесь использовать Приложение только в законных целях и в соответствии с настоящими Условиями. Вы несете ответственность за:',
            ),
            _buildSection(
              '4. Интеллектуальная собственность',
              'Приложение и его оригинальный контент, функции и функциональность являются и останутся исключительной собственностью RUNQUEST и ее лицензиаров.',
            ),
            _buildSection(
              '5. Ограничения ответственности',
              'В максимальной степени, разрешенной применимым законодательством, RUNQUEST ни при каких обстоятельствах не несет ответственности за любые косвенные, случайные, специальные, последующие или штрафные убытки...',
            ),
            const SizedBox(height: 20),
            Text(
              'Дата последнего обновления: 10 мая 2025 г.',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Colors.black.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontFamily: 'Roboto',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            content,
            style: TextStyle(
              fontFamily: 'Roboto',
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }
} 