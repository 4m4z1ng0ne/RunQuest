import 'package:flutter/material.dart';
import 'package:frontend/models/user.dart';
import 'package:frontend/services/friend_service.dart';
import 'package:frontend/models/friend_request_display_item.dart';
import 'package:frontend/screens/main/profile_screen.dart';
import 'package:frontend/screens/main/other_user_profile_screen.dart';
import 'package:frontend/screens/main/requests_and_invitations_screen.dart';



class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});

  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final FriendService _friendService = FriendService();
  List<User> _friends = [];
  List<FriendRequestDisplayItem> _pendingRequests = [];
  List<FriendRequestDisplayItem> _sentRequests = [];
  List<User> _searchResults = [];
  final TextEditingController _searchController = TextEditingController();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchData();
    _searchController.addListener(() { // Add listener to update UI when text changes
      setState(() {}); // Trigger rebuild to update suffixIcon
    });
  }

  @override
  void dispose() {
    _searchController.dispose(); // Dispose the controller when the state is disposed
    super.dispose();
  }

  Future<void> _fetchData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final friends = await _friendService.fetchFriends();
      final pendingRequests = await _friendService.fetchPendingFriendRequests();
      final sentRequests = await _friendService.fetchSentFriendRequests();
        setState(() {
          _friends = friends;
        _pendingRequests = pendingRequests;
        _sentRequests = sentRequests;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading data: $e')),
      );
    } finally {
        setState(() {
          _isLoading = false;
        });
    }
  }

  Future<void> _searchUsers(String query) async {
    if (query.isEmpty) {
        setState(() {
        _searchResults = [];
      });
      return;
    }
    try {
      final results = await _friendService.searchUsers(query);
      setState(() {
        _searchResults = results;
      });
    } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error searching users: $e')),
        );
    }
  }

  Future<void> _sendFriendRequest(int userId) async {
    try {
      await _friendService.sendFriendRequest(userId);
      ScaffoldMessenger.of(context).showSnackBar(

        const SnackBar(content: Text('Запрос на добавление в друзья отправлен!')),
      );
      _searchUsers(_searchController.text); // Обновить результаты поиска
      _fetchData(); // Обновить все данные, включая отправленные запросы
    } catch (e) {
      String errorMessage = 'Произошла ошибка при отправке запроса: $e';
      if (e.toString().contains('Запрос дружбы уже существует или уже принят.')) {
        errorMessage = 'Вы уже отправляли запрос на дружбу этому пользователю.';
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    }
  }

  Future<void> _acceptFriendRequest(int requestId) async {
     try {
      await _friendService.acceptFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Friend request accepted!')),
      );
      _fetchData(); // Refresh all data
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error accepting request: $e')),
      );
    }
  }

  Future<void> _rejectFriendRequest(int requestId) async {
    try {
      await _friendService.rejectFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Friend request rejected.')),
      );
      _fetchData(); // Refresh all data
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error rejecting request: $e')),
      );
    }
  }

  Future<void> _cancelFriendRequest(int requestId) async {
    try {
      await _friendService.cancelSentFriendRequest(requestId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Friend request cancelled.')),
      );
      _fetchData(); // Refresh all data
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error cancelling request: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent, // Make AppBar transparent
        elevation: 0, // Remove shadow
        title: const Text(
          'Друзья',
          style: TextStyle(
            fontFamily: 'Satoshi', // Apply game-like font
            fontWeight: FontWeight.w700, // Make it bold
            fontSize: 24, // Increase font size
            color: Colors.black, // Dark text for contrast
          ),
        ),
          bottom: TabBar(
            indicatorColor: const Color(0xFFD5FF2E), // Neon green indicator
            labelColor: const Color(0xFF00C507), // Neon green for selected tab
            unselectedLabelColor: Colors.grey[700], // Dark grey for unselected tab
            labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10, fontFamily: 'Satoshi'),
            unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.normal, fontSize: 8, fontFamily: 'Satoshi'),
            tabs: const [
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.people),
                  ],
                ),
              ),
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.notifications),
                      ],
                    ),
                  ],
                ),
              ),
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.search),
                  ],
                ),
              ),
          ],
        ),
      ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
        children: [
                  // Мои Друзья
                  RefreshIndicator(
                    onRefresh: _fetchData,
                    child: _friends.isEmpty
                        ? const Center(
                            child: Text(
                              'У вас пока нет друзей.',
                              style: TextStyle(
                                fontFamily: 'Satoshi',
                                fontSize: 18,
                                color: Colors.grey,
                              ),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _friends.length,
                            itemBuilder: (context, index) {
                              final friend = _friends[index];
                              return Card(
                                margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                elevation: 5,
                                color: Colors.white.withOpacity(0.9),
                                child: ListTile(
                                  leading: Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: const Color(0xFF000000),
                                        width: 2.0,
                                      ),
                                    ),
                                    child: CircleAvatar(
                                      radius: 25,
                                      backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2),
                                      child: Text(
                                        friend.username[0].toUpperCase(),
                                        style: const TextStyle(
                                          fontFamily: 'Satoshi',
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFF000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                  title: Text(
                                    friend.username,
                                    style: const TextStyle(
                                      fontFamily: 'Satoshi',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                      color: Colors.black,
                                    ),
                                  ),
                                  subtitle: Text(
                                    'Уровень: ${friend.level}',
                                    style: TextStyle(
                                      fontFamily: 'Satoshi',
                                      fontSize: 14,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => OtherUserProfileScreen(userId: friend.id),
                                    ),
                                  );
                                },
                                ),
                       );
                     },
                   ),
                  ),
                  // Запросы и Приглашения (новая вкладка)
                  RequestsAndInvitationsScreen(
                    pendingRequests: _pendingRequests,
                    sentRequests: _sentRequests,
                    onRefresh: _fetchData,
                  ),
                  // Найти Пользователей
                  RefreshIndicator(
                    onRefresh: () async {
                      await _searchUsers(_searchController.text);
                    },
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: TextField(
                            controller: _searchController,
                            style: const TextStyle(fontFamily: 'Satoshi', color: Colors.black),
                            decoration: InputDecoration(
                              labelText: 'Имя пользователя',
                              labelStyle: TextStyle(fontFamily: 'Satoshi', color: Colors.grey[700]),
                              filled: true,
                              fillColor: Colors.white.withOpacity(0.9),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide.none,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: const BorderSide(color: Color(0xFFD5FF2E), width: 2.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: const BorderSide(color: Color(0xFF00C6FF), width: 2.0),
                              ),
                              suffixIcon: _searchController.text.isNotEmpty
                                  ? IconButton(
                                      icon: const Icon(Icons.clear, color: Colors.grey),
                                      onPressed: () {
                                        _searchController.clear();
                                        _searchUsers('');
                                      },
                                    )
                                  : IconButton(
                                      icon: const Icon(Icons.search, color: Color(0xFFD5FF2E)),
                                      onPressed: () => _searchUsers(_searchController.text),
                                    ),
                            ),
                            onSubmitted: _searchUsers,
                          ),
                        ),
                        Expanded(
                          child: _searchResults.isEmpty && _searchController.text.isNotEmpty
                              ? const Center(
                                  child: Text(
                                    'Пользователи не найдены.',
                                    style: TextStyle(
                                      fontFamily: 'Satoshi',
                                      fontSize: 18,
                                      color: Colors.grey,
                                    ),
                                  ),
                                )
                              : ListView.builder(
                                  itemCount: _searchResults.length,
                                  itemBuilder: (context, index) {
                                    final user = _searchResults[index];
                                    return Card(
                                      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      elevation: 5,
                                      color: Colors.white.withOpacity(0.9),
                                      child: ListTile(
                                        leading: Container(
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: const Color(0xFF000000),
                                              width: 2.0,
                                            ),
                                          ),
                                          child: CircleAvatar(
                                            radius: 25,
                                            backgroundColor: const Color(0xFFD5FF2E).withOpacity(0.2),
                                            child: Text(
                                              user.username[0].toUpperCase(),
                                              style: const TextStyle(
                                                fontFamily: 'Satoshi',
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                        title: Text(
                                          user.username,
                                          style: const TextStyle(
                                            fontFamily: 'Satoshi',
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18,
                                            color: Colors.black,
                                          ),
                                        ),
                                      trailing: IconButton(
                                          icon: const Icon(Icons.person_add, color: Color(0xFF00C507)),
                                        onPressed: () => _sendFriendRequest(user.id),
                                      ),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => OtherUserProfileScreen(userId: user.id),
                                          ),
                                        );
                                      },
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
