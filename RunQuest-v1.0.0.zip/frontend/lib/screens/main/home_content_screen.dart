import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
//import 'dart:ui' as ui; // For ui.Gradient
//import 'package:frontend/screens/main/race_map_screen.dart';
import 'package:frontend/screens/main/active_training_screen.dart';
import 'package:frontend/screens/main/challenges_screen.dart';


class HomeContentScreen extends StatefulWidget {
  // TODO: Add necessary data parameters (profile, challenges) here
  // For now, let's make challenges list optional and default to empty
  final List<dynamic>? activeChallengesData;
  final VoidCallback? onStartRacePressed; // Add a callback for the button press
  final Map<String, dynamic>? profileData; // Add profile data parameter

  const HomeContentScreen({super.key, this.activeChallengesData, this.onStartRacePressed, this.profileData}); // Include profileData in constructor

  @override
  State<HomeContentScreen> createState() => _HomeContentScreenState();
}

class _HomeContentScreenState extends State<HomeContentScreen> {
  @override
  Widget build(BuildContext context) {
    // TODO: Add loading state check if profile data is passed and is null
    if (widget.profileData == null) {
      return const Center(child: CircularProgressIndicator()); // Show loading indicator if profile data is null
    }

    // Use actual data from widget.profileData
    final String level = widget.profileData!['level']?.toString() ?? 'N/A'; // Use level from profile data
    final Map<String, dynamic> statistics = widget.profileData!['statistics'] ?? {}; // Use statistics from profile data
    // Use widget.activeChallengesData or default to an empty list
    final List<dynamic> activeChallenges = widget.activeChallengesData ?? [];

    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F0), // Light grey background from Figma
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60.0),
        child: AppBar(
          automaticallyImplyLeading: false,
          title: Padding(
            padding: const EdgeInsets.only(left: 0.0, top: 10.0),
            child: SvgPicture.asset(
              'static/screens/dashboard/dashboardscreen.svg',
              height: 30.0,
            ),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0), // Adjust padding as needed
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Motivational text instead of RUNQUEST header
              // const Text(
              //   'Начни пробежку сейчас!', // Motivational phrase
              //   textAlign: TextAlign.center, // Center the text
              //   style: TextStyle(
              //     fontSize: 24,
              //     fontWeight: FontWeight.bold,
              //     color: Colors.black, // Adjust color as needed
              //   ),
              // ),
              // const SizedBox(height: 20), // Spacing

              // Training/Race Cards
              Row(
                children: [
                  Expanded(
                    child: InkWell( // Use InkWell for tap feedback
                      onTap: () {
                        // TODO: Implement navigation or action for starting workout
                        Navigator.push( // Add navigation
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ActiveTrainingScreen(), // Navigate to ActiveTrainingScreen
                          ),
                        );
                      },
                      child: Container( // Container for size and decoration
                        height: 178, // Height from Figma
                        width: 236, // Approximate width from Figma (adjust Expanded/constraints as needed)
                        decoration: BoxDecoration( // Decoration for gradient background and rounded corners
                          borderRadius: BorderRadius.circular(20), // Rounded corners
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xFFD5FF2E), // Neon green (start)
                              Color(0xFF00C6FF), // Bright blue (end)
                            ], // Gradient for training button
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [ // Add subtle shadow for depth
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: const Offset(0, 3),
                            ),
                          ],
                          border: Border.all( // Add border for the training card
                            color: const Color(0xFF86E0F8), // Light blue border
                            width: 2.0,
                          ),
                        ),
                        child: Stack( // Stack for layering image and text
                          children: [
                            // Optional: If you want a background image, uncomment and adjust. Otherwise, it will be just gradient.
                            // Positioned.fill(
                            //   child: ClipRRect(
                            //     borderRadius: BorderRadius.circular(20),
                            //     child: Image.asset(
                            //       'static/images/training_card_background.png',
                            //       fit: BoxFit.cover,
                            //     ),
                            //   ),
                            // ),
                            // Overlay with SVG icon for Training - positioned top-right or top-left for racing feel
                            Positioned(
                              top: 15,
                              left: 15, // Positioned top-left
                              child: SvgPicture.asset(
                                'static/images/training_icon.svg', // Use your training SVG
                                height: 50,
                                width: 50,
                                colorFilter: const ColorFilter.mode(Colors.black, BlendMode.srcIn), // Black icon for contrast on bright gradient
                              ),
                            ),
                            // Text content
                            Positioned(
                              bottom: 16, // Align to bottom with padding
                              left: 16, // Align to left with padding
                              right: 16, // Align to right with padding
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min, // Use minimum space
                                  children: [
                                    // Начать Тренировку Text
                                    Text(
                                      'Начать \nТренировку', // Text from Figma
                                      style: TextStyle(
                                        fontFamily: 'Satoshi', // Font family from Figma
                                      fontWeight: FontWeight.w700, // Bold
                                      fontSize: 16, // Slightly larger
                                      letterSpacing: 2, // Letter spacing
                                      color: Colors.black, // Black text for contrast
                                      height: 1.2, // Line height
                                      shadows: [
                                        Shadow(
                                          blurRadius: 5.0,
                                          color: Colors.black.withOpacity(0.3), // Softer shadow
                                          offset: const Offset(1.0, 1.0),
                                        ),
                                      ], // Add shadow for depth
                                    ),
                                  ),
                                  const SizedBox(height: 4), // Spacing between texts
                                    // Бег | ходьба Text
                                    Text(
                                      'бег/ходьба', // Text from Figma
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontFamily: 'Satoshi', // Font family from Figma
                                      fontWeight: FontWeight.w500, // Medium weight
                                      fontSize: 12, // Slightly larger
                                      letterSpacing: 0, // Letter spacing
                                      color: Colors.black87, // Slightly lighter black
                                      shadows: [
                                        Shadow(
                                          blurRadius: 3.0,
                                          color: Colors.black.withOpacity(0.2), // Softer shadow
                                          offset: const Offset(0.5, 0.5),
                                        ),
                                      ], // Add shadow for depth
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16), // Spacing between cards
                  Expanded(
                    child: InkWell( // Use InkWell for tap feedback
                      onTap: () {
                        // Call the provided callback if it exists
                        widget.onStartRacePressed?.call();
                      },
                      child: Container( // Container for size and decoration
                        height: 178, // Height from Figma (assuming same as workout card)
                        decoration: BoxDecoration( // Decoration for gradient background and rounded corners
                          borderRadius: BorderRadius.circular(20), // Rounded corners
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xFFCCFF00), // Pink (start)
                              Color(0xFFFF9900), // Bright orange/yellow (end)
                            ], // Gradient for race button
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [ // Add subtle shadow for depth
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: const Offset(0, 3),
                            ),
                          ],
                          border: Border.all( // Add border for the race card
                            color: const Color(0xFFD5FF2E), // Neon yellow/green border
                            width: 2.0,
                          ),
                        ),
                        child: Stack(
                          alignment: Alignment.bottomLeft,
                          children: [
                            // Optional: If you want a background image, uncomment and adjust. Otherwise, it will be just gradient.
                            // Positioned.fill(
                            //   child: ClipRRect(
                            //     borderRadius: BorderRadius.circular(20),
                            //     child: Image.asset(
                            //       'static/images/race_card_background.png',
                            //       fit: BoxFit.cover,
                            //     ),
                            //   ),
                            // ),
                            // Overlay with SVG icon for Race - positioned top-right or top-left for racing feel
                            Positioned(
                              top: 15,
                              left: 15, // Positioned top-left
                              child: SvgPicture.asset(
                                'static/images/race_icon.svg', // Use your race SVG
                                height: 50,
                                width: 50,
                                colorFilter: const ColorFilter.mode(Colors.black, BlendMode.srcIn), // Black icon for contrast on bright gradient
                              ),
                            ),
                            // Text content
                            Positioned(
                              bottom: 16, // Align to bottom with padding
                              left: 16, // Align to left with padding
                              right: 16, // Align to right with padding
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min, // Use minimum space
                                  children: [
                                  // Начать Гонку Text
                                    Text(
                                    'Начать \nГонку', // Text from Figma/screenshot
                                      style: TextStyle(
                                      fontFamily: 'Satoshi', // Font family from Figma
                                      fontWeight: FontWeight.w700, // Bold
                                      fontSize: 16, // Slightly larger
                                      letterSpacing: 2, // Letter spacing
                                      color: Colors.black, // Black text for contrast
                                      height: 1.2, // Line height
                                      shadows: [
                                        Shadow(
                                          blurRadius: 5.0,
                                          color: Colors.black.withOpacity(0.3), // Softer shadow
                                          offset: const Offset(1.0, 1.0),
                                        ),
                                      ], // Add shadow for depth
                                    ),
                                  ),
                                  const SizedBox(height: 4), // Spacing
                                    Text(
                                      'на время', // Text from Figma/screenshot
                                      style: TextStyle(
                                      fontFamily: 'Satoshi', // Font family from Figma
                                      fontWeight: FontWeight.w500, // Medium weight
                                      fontSize: 12, // Slightly larger
                                      letterSpacing: 0, // Letter spacing
                                      color: Colors.black87, // Slightly lighter black
                                      shadows: [
                                        Shadow(
                                          blurRadius: 3.0,
                                          color: Colors.black.withOpacity(0.2), // Softer shadow
                                          offset: const Offset(0.5, 0.5),
                                        ),
                                      ], // Add shadow for depth
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20), // Spacing

              // Weekly Stats
              Row(
                children: [
                  Expanded(
                    child: Card(
                      color: Colors.white, // Set card background to white
                      shape: RoundedRectangleBorder( // Add border and corner radius
                        borderRadius: BorderRadius.circular(20), // Approximate corner radius
                        side: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.0), // Light grey border
                      ),
                      elevation: 2, // Add a subtle shadow
                      // Ensure consistent height for stat cards
                      child: IntrinsicHeight( // Make the height intrinsically fit the content
                         child: Padding(
                           padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0), // Further adjusted padding
                           child: Column(
                             crossAxisAlignment: CrossAxisAlignment.start,
                             mainAxisAlignment: MainAxisAlignment.center, // Center content vertically
                             children: [
                               Text(
                                 'Общая дистанция', // Надпись
                                 style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurface), // Уменьшаем шрифт для надписи
                               ),
                               const SizedBox(height: 8),
                               Text(
                                 '${(statistics['total_distance_km'] as num?)?.toDouble().toStringAsFixed(2) ?? 'N/A'} КМ', // Use actual data
                                 style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold), // Further adjusted font size
                               ),
                                // TODO: Add wavy line icon
                               const SizedBox(height: 8), // Spacing
                               Align(
                                 alignment: Alignment.bottomRight,
                                 child: Image.asset(
                                   'static/screens/dashboard/lines.png', // Path to your wavy line PNG
                                   height: 20,
                                   width: 40,
                                 ),
                               ),
                             ],
                           ),
                         ),
                      ),
                    )
                  ),
                  const SizedBox(width: 16), // Spacing between cards
                  Expanded(
                    child: Card(
                      color: Colors.white, // Set card background to white
                      shape: RoundedRectangleBorder( // Add border and corner radius
                        borderRadius: BorderRadius.circular(20), // Approximate corner radius
                        side: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.0), // Light grey border
                      ),
                      elevation: 2, // Add a subtle shadow
                      // TODO: Add visual styling based on Figma
                      // Ensure consistent height for stat cards
                      child: IntrinsicHeight( // Make the height intrinsically fit the content
                         child: Padding(
                           padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0), // Further adjusted padding
                           child: Column(
                             crossAxisAlignment: CrossAxisAlignment.start,
                             mainAxisAlignment: MainAxisAlignment.center, // Center content vertically
                             children: [
                               Text(
                                 'Общее время', // Надпись
                                 style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurface), // Уменьшаем шрифт для надписи
                               ),
                               const SizedBox(height: 8),
                               Text(
                                 // Format duration from hours (e.g., 1.5) to "1ч 30мин"
                                 () {
                                   final double? totalHours = (statistics['total_duration_hours'] as num?)?.toDouble();
                                   if (totalHours == null || totalHours.isNaN) return 'N/A';

                                   final int hours = totalHours.floor();
                                   final int minutes = ((totalHours - hours) * 60).round();

                                   if (hours > 0 && minutes > 0) return '$hoursч $minutesм';
                                   if (hours > 0) return '$hoursч';
                                   if (minutes > 0) return '$minutesм';
                                   return '0м';
                                 }(),
                                 style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold), // Further reduced font size
                               ),
                               // TODO: Add wavy line icon
                               const SizedBox(height: 8), // Spacing
                               Align(
                                 alignment: Alignment.bottomRight,
                                 child: Image.asset(
                                   'static/screens/dashboard/dots.png', // Path to your dotted icon PNG
                                   height: 20,
                                   width: 40,
                                 ),
                               ),
                             ],
                           ),
                         ),
                       ),
                  ),
                  ),
                ],
              ),
              const SizedBox(height: 20), // Spacing

              // Level Progress (Moved Here)
              Card(
                color: Colors.white, // Set card background to white
                shape: RoundedRectangleBorder( // Add border and corner radius
                  borderRadius: BorderRadius.circular(20), // Approximate corner radius
                  side: BorderSide(color: Colors.grey.withOpacity(0.3), width: 1.0), // Light grey border
                ),
                elevation: 2, // Add a subtle shadow
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Уровень $level', // Use placeholder or actual data
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold), // Apply font styles
                      ),
                      const SizedBox(height: 8),
                      // Display XP progress
                      if (widget.profileData!['experience_points'] != null) // Check if experience_points is available
                         Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: [
                             Text(
                               // Calculate XP needed for next level assuming 1000 XP per level starting from level 1 = 0-999 XP
                               // Level 1: 0-999 XP, Level 2: 1000-1999 XP, Level 3: 2000-2999 XP
                               // XP needed for next level is 1000 * current_level
                               // Current level is int(experience_points / 1000) + 1
                               // XP needed for next level is (level * 1000) - current_xp
                               // Let's refine: XP for current level range is (level-1)*1000 to level*1000 - 1
                               // If current level is L, next level starts at L * 1000 XP.
                               // XP needed is (L * 1000) - current_xp.
                               // Be careful with floating point division for level calculation.
                               // Let's assume level in profileData is already the integer level.

                               () {
                                 final int? currentLevel = widget.profileData!['level'] as int?;
                                 final int? currentXP = widget.profileData!['experience_points'] as int?;

                                 if (currentLevel == null || currentXP == null) return 'XP: N/A';

                                 // Assuming each level requires 1000 XP, starting XP for level L is (L-1) * 1000
                                 // XP needed for the *next* level (Level L+1) is L * 1000.
                                 // XP progress within current level is currentXP - (currentLevel - 1) * 1000
                                 // XP needed for the next level is 1000

                                 final int xpForCurrentLevelStart = (currentLevel - 1) * 1000;
                                 final int xpProgressInCurrentLevel = currentXP - xpForCurrentLevelStart;
                                 const int xpNeededForNextLevel = 1000; // Assuming fixed 1000 XP per level

                                 // Handle the case of reaching the next level exactly or exceeding
                                  if (xpProgressInCurrentLevel >= xpNeededForNextLevel) {
                                     // This case ideally shouldn't happen if level is correctly calculated on backend
                                     // If it does, it means user is at the start of a new level or beyond
                                     // Let's show progress towards the next level based on the new level.
                                     // If user is level L with XP >= (L-1)*1000, they are working towards L+1 which starts at L*1000.
                                     final int nextLevelXPThreshold = currentLevel * 1000;
                                     final int remainingXP = nextLevelXPThreshold - currentXP;
                                     // If remainingXP is negative, it means they are well into the next level.
                                     // Let's just show total XP in that case or indicate max level reached.
                                     // For simplicity, let's show total XP if remaining is <= 0.
                                     if (remainingXP <= 0) return 'XP: $currentXP';
                                     return 'XP: $currentXP / $nextLevelXPThreshold';

                                  }

                                 return 'XP: $xpProgressInCurrentLevel / $xpNeededForNextLevel';
                               }(), // Immediately invoke the lambda
                               style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w500), // Adjusted style
                             ),
                             const SizedBox(height: 4.0),
                      LinearProgressIndicator(
                               value: () {
                                 final int? currentLevel = widget.profileData!['level'] as int?;
                                 final int? currentXP = widget.profileData!['experience_points'] as int?;
                                 if (currentLevel == null || currentXP == null || currentLevel == 0) return 0.0;
                                  final int xpForCurrentLevelStart = (currentLevel - 1) * 1000;
                                  final int xpProgressInCurrentLevel = currentXP - xpForCurrentLevelStart;
                                  const int xpNeededForNextLevel = 1000; // Assuming fixed 1000 XP per level
                                  if (xpNeededForNextLevel <= 0) return 0.0; // Avoid division by zero
                                  return (xpProgressInCurrentLevel / xpNeededForNextLevel).clamp(0.0, 1.0);
                               }(),
                               // Immediately invoke the lambda for value
                        backgroundColor: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
                                valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).colorScheme.secondary),
                                minHeight: 10,
                                borderRadius: BorderRadius.circular(5), // Rounded corners for progress bar
                              ),
                           ],
                         )
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20), // Spacing

              // Challenges Section
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                 children: [
                   Row( // Use Row for title and button
                     mainAxisAlignment: MainAxisAlignment.spaceBetween, // Space between title and button
                     children: [
                       Text(
                         'Челленджи', // Section Title
                           style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold), // Apply font styles
                       ),
                       // Button to view all challenges
                       TextButton(
                         onPressed: () {
                           // TODO: Implement navigation to the full challenges screen
                            Navigator.push( // Add navigation
                             context,
                             MaterialPageRoute(
                               builder: (context) => const ChallengesScreen(), // Navigate to ChallengesScreen
                             ),
                           );
                         },
                         child: Text('Все',
                           style: Theme.of(context).textTheme.labelLarge?.copyWith(color: Theme.of(context).colorScheme.primary), // Apply font styles
                         ),
                       ),
                     ],
                   ),
                   const SizedBox(height: 10), // Spacing
                  // Display only the first 2 active challenges
                   if (activeChallenges.isNotEmpty)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        for (var i = 0; i < activeChallenges.length && i < 2; i++)
                          Card(
                            color: Colors.white, // Set card background to white
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.grey.withOpacity(0.3), width: 0.5), // Subtle border
                            ),
                            margin: const EdgeInsets.only(bottom: 8.0), // Spacing between challenge cards
                            elevation: 1, // Add a subtle shadow
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row( // Wrap in a Row to place circle and text side by side
                                    children: [
                                      Container(
                                        width: 10, // Diameter of the circle
                                        height: 10,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: i == 0 ? const Color(0xFFD5FF2E) : Colors.grey, // Neon green for first, grey for others
                                        ),
                                      ),
                                      const SizedBox(width: 8), // Spacing between circle and text
                                      Expanded( // Ensure text takes remaining space
                                        child: Text(
                                          activeChallenges[i]['challenge']?['name'] ?? 'Название челленджа', // Challenge Name
                                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, fontFamily: 'Roboto'),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4), // Spacing
                                  Text(
                                    activeChallenges[i]['challenge']?['description'] ?? 'Описание челленджа', // Challenge Description
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurface, fontFamily: 'Roboto'),
                                  ),
                                  // TODO: Display progress if applicable
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  // Placeholder for challenges if none are active
                   if (activeChallenges.isEmpty)
                     Column(
                       crossAxisAlignment: CrossAxisAlignment.stretch,
                       children: [
                         Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.grey.withOpacity(0.3), width: 0.5), // Subtle border
                            ),
                            elevation: 1, // Add a subtle shadow
                            child: Padding(
                               padding: const EdgeInsets.all(12.0),
                               child: Text('Нет активных челленджей. Посмотрите доступные челленджи!',
                                 style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurface, fontFamily: 'Roboto'),
                               ),
                            ),
                         ),
                       ],
                     ),
                 ],
               ),
            ],
          ),
        ),
      ),
    );
  }
} 