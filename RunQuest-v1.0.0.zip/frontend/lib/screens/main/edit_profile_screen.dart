import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:intl/intl.dart'; // For date formatting
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _dateOfBirthController = TextEditingController();

  bool _isLoading = true;
  File? _avatarFile;
  bool _isPublic = true;
  bool _showAchievements = true;
  bool _showChallenges = true;
  bool _showRuns = true;

  // Define accent color
  final Color accentColor = const Color(0xFFC0FF00); // Ярко-зеленый, неоновый

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  @override
  void dispose() {
    _bioController.dispose();
    _dateOfBirthController.dispose();
    super.dispose();
  }

  Future<void> _fetchProfileData() async {
    try {
      final response = await _authService.getProfile();
      if (response.statusCode == 200) {
        setState(() {
          final profileData = response.data;
          _bioController.text = profileData?['bio'] ?? '';
          _isPublic = profileData?['is_public'] ?? true;
          _showAchievements = profileData?['show_achievements'] ?? true;
          _showChallenges = profileData?['show_challenges'] ?? true;
          _showRuns = profileData?['show_runs'] ?? true;
          // Format date of birth if available
          if (profileData?['date_of_birth'] != null) {
            try {
              final DateTime dob = DateTime.parse(profileData!['date_of_birth']);
              _dateOfBirthController.text = DateFormat('yyyy-MM-dd').format(dob);
            } catch (e) {
              print('Error parsing date of birth: $e');
              _dateOfBirthController.text = '';
            }
          }
        });
      } else {
        print('Failed to load profile data for editing: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching profile data for editing: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _pickAvatar() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _avatarFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _saveProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      try {
        final profileData = {
          'bio': _bioController.text,
          'date_of_birth': _dateOfBirthController.text.isNotEmpty ? _dateOfBirthController.text : null,
          'is_public': _isPublic,
          'show_achievements': _showAchievements,
          'show_challenges': _showChallenges,
          'show_runs': _showRuns,
        };
        final response = await _authService.updateProfile(profileData, avatarFile: _avatarFile);
        if (response.statusCode == 200) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Профиль успешно обновлен')),
          );
          Navigator.pop(context);
        } else {
          print('Failed to update profile: ${response.statusCode}');
          print('Response data: ${response.data}');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Ошибка обновления профиля: ${response.data?['detail'] ?? response.statusCode}')),
          );
        }
      } catch (e) {
        print('Error updating profile: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Произошла ошибка: $e')),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Function to show a date picker
  Future<void> _selectDateOfBirth(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _dateOfBirthController.text.isNotEmpty
          ? DateTime.parse(_dateOfBirthController.text)
          : DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(
              primary: accentColor, // Цвет заголовка и кнопок
              onPrimary: Colors.black, // Цвет текста на акцентном цвете
              onSurface: Colors.black, // Цвет текста в календаре
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(foregroundColor: accentColor), // Цвет кнопок "ОК", "ОТМЕНА"
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _dateOfBirthController.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Чистый белый фон
      appBar: AppBar(
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Text(
              'РЕДАКТИРОВАТЬ',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
                color: Colors.black,
              ),
            ),
            Text(
              'ПРОФИЛЬ',
          style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
                color: Colors.black,
              ),
          ),
          ],
        ),
        backgroundColor: Colors.white, // Белый фон AppBar
        elevation: 0, // Убираем тень
        centerTitle: true, // Центрируем заголовок
        iconTheme: const IconThemeData(color: Colors.black), // Черные иконки
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFC0FF00)), // Акцентный цвет для индикатора загрузки
            )
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(20.0), // Немного увеличим отступы
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Center(
                        child: Stack(
                          children: [
                            CircleAvatar(
                              radius: 60, // Увеличим радиус аватара
                              backgroundColor: Colors.grey.shade200, // Более светлый серый
                              backgroundImage: _avatarFile != null ? FileImage(_avatarFile!) : null,
                              child: _avatarFile == null ? Icon(Icons.person, size: 60, color: Colors.grey.shade600) : null,
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: GestureDetector( // Используем GestureDetector для более кастомизированной кнопки
                                onTap: _pickAvatar,
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: accentColor, // Акцентный цвет
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.white, width: 2), // Белая обводка
                                  ),
                                  child: const Icon(Icons.camera_alt, color: Colors.black, size: 24), // Черная иконка
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30.0), // Увеличим отступ
                      TextFormField(
                        controller: _bioController,
                        decoration: InputDecoration(
                          labelText: 'БИОГРАФИЯ', // Стилизуем текст
                          labelStyle: TextStyle(
                            color: Colors.grey.shade700, // Темно-серый текст
                            fontWeight: FontWeight.bold,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero, // Острые углы
                            borderSide: BorderSide(color: Colors.grey.shade400, width: 1.5), // Более заметная рамка
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: Colors.grey.shade400, width: 1.5),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: accentColor, width: 2.0), // Акцентный цвет при фокусе
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0), // Отступы внутри поля
                        ),
                        maxLines: 3,
                        style: const TextStyle(color: Colors.black), // Черный текст внутри поля
                      ),
                      const SizedBox(height: 20.0),
                      TextFormField(
                        controller: _dateOfBirthController,
                        decoration: InputDecoration(
                          labelText: 'ДАТА РОЖДЕНИЯ',
                          labelStyle: TextStyle(
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.bold,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: Colors.grey.shade400, width: 1.5),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: Colors.grey.shade400, width: 1.5),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.zero,
                            borderSide: BorderSide(color: accentColor, width: 2.0),
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(Icons.calendar_today, color: accentColor), // Акцентный цвет для иконки календаря
                            onPressed: () => _selectDateOfBirth(context),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                        ),
                        readOnly: true,
                        onTap: () => _selectDateOfBirth(context),
                        style: const TextStyle(color: Colors.black),
                        validator: (value) {
                          if (value != null && value.isNotEmpty) {
                            final regex = RegExp(r'^\d{4}-\d{2}-\d{2}$');
                            if (!regex.hasMatch(value)) {
                              return 'Введите дату в формате ГГГГ-ММ-ДД';
                            }
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: const Text(
                              'ПУБЛИЧНЫЙ ПРОФИЛЬ',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Switch(
                            value: _isPublic,
                            onChanged: (value) {
                              setState(() {
                                _isPublic = value;
                              });
                            },
                            activeColor: accentColor, // Акцентный цвет для активного состояния
                            inactiveThumbColor: Colors.grey.shade400, // Серый для неактивного ползунка
                            inactiveTrackColor: Colors.grey.shade200, // Светло-серый для неактивного трека
                            activeTrackColor: accentColor.withOpacity(0.5), // Полупрозрачный акцентный цвет для активного трека
                          ),
                        ],
                      ),
                      const SizedBox(height: 16.0), // Добавим отступ
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: const Text(
                              'ПОКАЗЫВАТЬ ПРОБЕЖКИ',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Switch(
                            value: _showRuns,
                            onChanged: (value) {
                              setState(() {
                                _showRuns = value;
                              });
                            },
                            activeColor: accentColor, // Акцентный цвет
                            inactiveThumbColor: Colors.grey.shade400,
                            inactiveTrackColor: Colors.grey.shade200,
                            activeTrackColor: accentColor.withOpacity(0.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16.0), // Добавим отступ
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: const Text(
                              'ПОКАЗЫВАТЬ ДОСТИЖЕНИЯ',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Switch(
                            value: _showAchievements,
                            onChanged: (value) {
                              setState(() {
                                _showAchievements = value;
                              });
                            },
                            activeColor: accentColor, // Акцентный цвет
                            inactiveThumbColor: Colors.grey.shade400,
                            inactiveTrackColor: Colors.grey.shade200,
                            activeTrackColor: accentColor.withOpacity(0.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16.0), // Добавим отступ
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: const Text(
                              'ПОКАЗЫВАТЬ ЧЕЛЛЕНДЖИ',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Switch(
                            value: _showChallenges,
                            onChanged: (value) {
                              setState(() {
                                _showChallenges = value;
                              });
                            },
                            activeColor: accentColor, // Акцентный цвет
                            inactiveThumbColor: Colors.grey.shade400,
                            inactiveTrackColor: Colors.grey.shade200,
                            activeTrackColor: accentColor.withOpacity(0.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 40.0), // Увеличим отступ перед кнопкой
                      ElevatedButton(
                        onPressed: _isLoading ? null : _saveProfile,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFC0FF00), // Цвет кнопки
                          foregroundColor: Colors.black, // Цвет текста
                          padding: const EdgeInsets.symmetric(vertical: 15.0), // Отступы
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                          ),
                          elevation: 5, // Тень кнопки
                          textStyle: const TextStyle(
                            fontSize: 16.0, // Размер шрифта
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        child: _isLoading
                            ? const CircularProgressIndicator(color: Colors.black) // Индикатор загрузки
                            : const Text('СОХРАНИТЬ ИЗМЕНЕНИЯ'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
} 