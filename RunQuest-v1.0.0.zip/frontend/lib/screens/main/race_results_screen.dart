// race_results_screen.dart
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:share_plus/share_plus.dart';
import 'package:frontend/services/auth_service.dart';
import 'package:frontend/models/user.dart';
import 'package:frontend/screens/main/leaderboard_screen.dart'; // Import LeaderboardScreen

class RaceResultsScreen extends StatefulWidget {
  final String? trackName;
  final int? durationSeconds;
  final double? distanceCoveredKm;
  final List<LatLng>? recordedRoute;
  final int? trackId;
  final int? attemptId;
  final int? xpEarned;
  final List<dynamic>? achievementsEarned;
  final bool? isRecordBroken;
  final List<dynamic>? challengesCompleted;
  final User? currentUser;

  const RaceResultsScreen({
    super.key,
    this.trackName,
    this.durationSeconds,
    this.distanceCoveredKm,
    this.recordedRoute,
    this.trackId,
    this.attemptId,
    this.xpEarned,
    this.achievementsEarned,
    this.isRecordBroken,
    this.challengesCompleted,
    this.currentUser,
  });

  @override
  State<RaceResultsScreen> createState() => _RaceResultsScreenState();
}

class _RaceResultsScreenState extends State<RaceResultsScreen> {
  Map<String, dynamic>? attemptDetails;
  bool isLoading = false;
  String? error;

  // Zenless Zone Zero inspired colors (light scheme)
  final Color _primaryAccentColor = const Color(0xFFC0FF00); // Ярко-зеленый
  final Color _secondaryAccentColor = const Color(0xFFC0FF00); // Ярко-зеленый
  final Color _textColor = Colors.black;
  final Color _backgroundColor = Colors.white;
  final Color _borderColor = const Color(0xFFACACAC); // Серый для границ
  final Color _secondaryTextColor = Colors.black54; // Lighter black for labels

  @override
  void initState() {
    super.initState();
    if (widget.attemptId != null) {
      _loadAttempt();
    }
  }

  Future<void> _loadAttempt() async {
    setState(() {
      isLoading = true;
      error = null;
    });
    try {
      final details = await AuthService().fetchRaceAttemptDetails(widget.attemptId!);
      setState(() {
        attemptDetails = details;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = 'Ошибка загрузки данных';
        isLoading = false;
      });
    }
  }

  // Helper method to format time from seconds into HH:MM:SS
  String _formatTime(int seconds) {
    final hours = (seconds ~/ 3600).toString().padLeft(2, '0');
    final minutes = ((seconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final remainingSeconds = (seconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$remainingSeconds';
  }

  // Helper method to calculate average pace (minutes per kilometer)
  String _calculateAveragePace(int durationSeconds, double distanceKm) {
    if (distanceKm > 0 && durationSeconds > 0) {
      final double pace = durationSeconds / distanceKm / 60;
      final int paceMinutes = pace.floor();
      final int paceSeconds = ((pace - paceMinutes) * 60).round();
      return '${paceMinutes.toString().padLeft(2, '0')}:${paceSeconds.toString().padLeft(2, '0')} МИН/КМ'; // Uppercase units
    } else {
      return '00:00 МИН/КМ'; // Uppercase units
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = attemptDetails;
    final isLoaded = data != null;

    // Dynamically choose data source: loaded details or widget properties
    final trackName = isLoaded ? (data['race_track_name'] ?? 'БЕЗ НАЗВАНИЯ').toUpperCase() : (widget.trackName ?? 'БЕЗ НАЗВАНИЯ').toUpperCase();
    final durationSeconds = isLoaded ? (data['duration_seconds'] ?? 0) : (widget.durationSeconds ?? 0);
    final distanceKm = isLoaded ? ((data['actual_distance_meters'] ?? 0) / 1000.0) : (widget.distanceCoveredKm ?? 0.0);
    final recordedRoute = widget.recordedRoute ?? (isLoaded && data['route_definition'] != null && data['route_definition']['coordinates'] != null
        ? (data['route_definition']['coordinates'] as List)
            .map((coord) => LatLng(coord[1], coord[0]))
            .toList()
        : []);
    final xpEarned = isLoaded ? (data['xp_earned'] ?? 0) : (widget.xpEarned ?? 0);
    final achievements = isLoaded ? (data['earned_achievements'] ?? []) : (widget.achievementsEarned ?? []);
    final challenges = isLoaded ? (data['completed_challenges'] ?? []) : (widget.challengesCompleted ?? []);
    final isRecordBroken = isLoaded ? (data['is_record_broken'] ?? false) : (widget.isRecordBroken ?? false);
    final baseXp = isLoaded ? (data['base_xp'] ?? 0) : 0;
    final recordBonusXp = isLoaded ? (data['record_bonus_xp'] ?? 0) : 0;
    final achievementsXp = isLoaded ? (data['achievements_xp'] ?? 0) : 0;
    final challengesXp = isLoaded ? (data['challenges_xp'] ?? 0) : 0;
    final trackId = isLoaded ? (data['track']?.toString() ?? widget.trackId?.toString()) : widget.trackId?.toString(); // Ensure trackId is String for LeaderboardScreen

    // Fetch currentUser from AuthService on build if not provided, or ensure it's up-to-date
    final currentUser = widget.currentUser ?? AuthService().currentUser;

    // Determine map center (e.g., middle of the route or start point)
    LatLng initialMapCenter = recordedRoute.isNotEmpty
        ? recordedRoute[(recordedRoute.length / 2).floor()]
        : const LatLng(56.012027, 92.867245); // Default center if no route

    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        backgroundColor: _backgroundColor,
        foregroundColor: _textColor,
        elevation: 0,
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'РЕЗУЛЬТАТЫ',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 20,
                letterSpacing: 1.8,
                color: _textColor,
              ),
            ),
            Text(
              'ГОНКИ',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 20,
                letterSpacing: 1.8,
                color: _textColor,
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.close, color: _textColor, size: 28),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.black)) // Darker indicator
          : error != null
              ? Center(child: Text(error!, style: TextStyle(color: _textColor)))
              : LayoutBuilder(
                  builder: (context, constraints) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.all(16.0), // Consistent padding
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Track Name Header Block
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0), // Измененный padding
                            decoration: BoxDecoration(
                              color: Colors.white, // Белый фон
                              border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
                              borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                              // Убрана тень
                            ),
                            child: Text(
                              'ТРАССА: $trackName',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 12, // Уменьшенный размер шрифта
                                fontWeight: FontWeight.w500, // Измененный вес шрифта
                                color: _textColor,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // Metric Columns
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _buildMetricColumn('', _formatTime(durationSeconds), _secondaryAccentColor, Icons.timer),
                              _buildMetricColumn('', '${distanceKm.toStringAsFixed(2)} КМ', _primaryAccentColor, Icons.straighten),
                              _buildMetricColumn('', _calculateAveragePace(durationSeconds, distanceKm), _secondaryAccentColor, Icons.speed), // Label changed to 'ТЕМП'
                            ],
                          ),
                          const SizedBox(height: 20),

                          // XP Earned Section
                          _buildSectionHeader('ЗАРАБОТАНО XP:', _primaryAccentColor),
                          const SizedBox(height: 5),
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              '${xpEarned} XP',
                              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: _secondaryAccentColor, letterSpacing: 1.0),
                            ),
                          ),
                          const SizedBox(height: 15),

                          // Achievements Section
                          _buildSectionHeader('ЗАРАБОТАНО ДОСТИЖЕНИЙ:', _primaryAccentColor),
                          const SizedBox(height: 5),
                          if (achievements.isNotEmpty)
                            ...achievements.map((achievement) => _buildGameListItem(
                                  title: achievement['name'] ?? 'Неизвестное достижение',
                                  icon: Icons.emoji_events,
                                  color: _primaryAccentColor,
                                ))
                          else
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                                'Нет заработанных достижений',
                                style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic, color: _secondaryTextColor),
                              ),
                            ),
                          const SizedBox(height: 15),

                          // Challenges Section
                          _buildSectionHeader('ВЫПОЛНЕННЫЕ ЧЕЛЛЕНДЖИ:', _primaryAccentColor),
                          const SizedBox(height: 5),
                          if (challenges.isNotEmpty)
                            ...challenges.map((challenge) => _buildGameListItem(
                                  title: '${challenge['name'] ?? 'Неизвестный челлендж'} (XP: ${challenge['xp_reward'] ?? 0})',
                                  icon: Icons.task_alt,
                                  color: _secondaryAccentColor,
                                ))
                          else
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                                'Нет выполненных челленджей',
                                style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic, color: _secondaryTextColor),
                              ),
                            ),
                          const SizedBox(height: 15),

                          // Level Progress Section
                          // if (currentUser != null) ...[
                          //   _buildSectionHeader('ПРОГРЕСС УРОВНЯ:', _primaryAccentColor),
                          //   const SizedBox(height: 5),
                          //   Padding(
                          //     padding: const EdgeInsets.only(left: 8.0),
                          //     child: Column(
                          //       crossAxisAlignment: CrossAxisAlignment.start,
                          //       children: [
                          //         Text(
                          //           'УРОВЕНЬ: ${currentUser.level}',
                          //           style: TextStyle(fontSize: 16, color: _textColor, fontWeight: FontWeight.w500),
                          //         ),
                          //         Text(
                          //           'ОПЫТ: ${currentUser.experience_points} XP',
                          //           style: TextStyle(fontSize: 16, color: _textColor, fontWeight: FontWeight.w500),
                          //         ),
                          //       ],
                          //     ),
                          //   ),
                          //   const SizedBox(height: 15),
                          // ],

                          // Record Broken Alert
                          if (isRecordBroken == true)
                            Container(
                              margin: const EdgeInsets.symmetric(vertical: 15),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: _primaryAccentColor.withOpacity(0.2),
                                borderRadius: BorderRadius.zero,
                                border: Border.all(color: _primaryAccentColor, width: 2.5),
                                boxShadow: [
                                  BoxShadow(
                                    color: _primaryAccentColor.withOpacity(0.4),
                                    blurRadius: 12,
                                    spreadRadius: 1,
                                    offset: const Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Text(
                                  'ПОЗДРАВЛЯЕМ! ВЫ ПОБИЛИ РЕКОРД ТРАССЫ!\nБОНУС: +$recordBonusXp XP',
                                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: _textColor, letterSpacing: 1.0),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),

                          // Map Section
                          Container(
                            height: 200, // Высота карты остается прежней
                            decoration: BoxDecoration(
                              border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
                              borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                              // Убрана тень
                            ),
                            child: FlutterMap(
                              options: MapOptions(
                                initialCenter: initialMapCenter,
                                initialZoom: 14.0,
                                interactiveFlags: InteractiveFlag.all,
                              ),
                              children: [
                                TileLayer(
                                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                  userAgentPackageName: 'com.runquest.app',
                                ),
                                if (recordedRoute.isNotEmpty)
                                  PolylineLayer(
                                    polylines: [
                                      Polyline(
                                        points: recordedRoute,
                                        strokeWidth: 4.0,
                                        color: _primaryAccentColor,
                                      ),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),

                          // XP Breakdown Section
                          _buildXpBreakdownSection(xpEarned, achievements, challenges, baseXp, recordBonusXp, achievementsXp, challengesXp),
                          const SizedBox(height: 25),

                          // Share Button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () {
                                final shareText = 'Результаты гонки RunQuest:\nТрасса: $trackName\nВремя: ${_formatTime(durationSeconds)}\nДистанция: ${distanceKm.toStringAsFixed(2)} КМ\nСредний темп: ${_calculateAveragePace(durationSeconds, distanceKm)}';
                                Share.share(shareText, subject: 'Результаты гонки RunQuest');
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFC0FF00), // Ярко-зеленый фон
                                foregroundColor: Colors.black, // Черный текст
                                padding: const EdgeInsets.symmetric(vertical: 15.0), // Отступы как у других кнопок
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                                ),
                                elevation: 5, // Тень
                                textStyle: const TextStyle(
                                  fontSize: 16.0, // Размер шрифта
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              child: const Text('ПОДЕЛИТЬСЯ РЕЗУЛЬТАТАМИ'),
                            ),
                          ),
                          const SizedBox(height: 10),

                          // Leaderboard Button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => LeaderboardScreen(
                                      trackId: trackId ?? '', // Pass the trackId to LeaderboardScreen
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFC0FF00), // Ярко-зеленый фон
                                foregroundColor: Colors.black, // Черный текст
                                padding: const EdgeInsets.symmetric(vertical: 15.0), // Отступы как у других кнопок
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                                ),
                                elevation: 5, // Тень
                                textStyle: const TextStyle(
                                  fontSize: 16.0, // Размер шрифта
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              child: const Text('ПОСМОТРЕТЬ ТАБЛИЦУ ЛИДЕРОВ'),
                            ),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ),
                    );
                  },
                ),
    );
  }

  // --- Reusable Widgets (copied from TrainingResultsScreen and adapted) ---

  // Metric Column Widget
  Widget _buildMetricColumn(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        height: 100.0, // Фиксированная высота для одинакового размера
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10), // Уменьшенный padding
        margin: const EdgeInsets.all(4.0), // Отступ между карточками
        decoration: BoxDecoration(
          color: Colors.white, // Белый фон
          border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
          borderRadius: BorderRadius.circular(10.0), // Скругленные углы
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05), // Легкая тень
              blurRadius: 5,
              spreadRadius: 1,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Выравнивание по центру
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.grey.shade700, size: 20), // Иконка серого цвета
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(fontSize: 9, fontWeight: FontWeight.w500, color: Colors.grey.shade700, letterSpacing: 0.5), // Уменьшенный размер и вес шрифта
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: _textColor, letterSpacing: 0.8), // Уменьшенный размер шрифта
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // Section Header Widget
  Widget _buildSectionHeader(String title, Color borderColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0), // Измененный padding
      decoration: BoxDecoration(
        color: Colors.white, // Белый фон
        border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
        borderRadius: BorderRadius.circular(10.0), // Скругленные углы
        // Убрана тень
      ),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12, // Уменьшенный размер шрифта
          fontWeight: FontWeight.w500, // Измененный вес шрифта
          color: _textColor,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // Game List Item Widget (for Achievements and Challenges)
  Widget _buildGameListItem({required String title, required IconData icon, required Color color}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0), // Отступ между элементами
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 20), // Увеличенный padding
        decoration: BoxDecoration(
          color: Colors.white, // Белый фон
          border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
          borderRadius: BorderRadius.circular(10.0), // Скругленные углы
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05), // Легкая тень
              blurRadius: 5,
              spreadRadius: 1,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.grey.shade700, size: 20), // Иконка серого цвета
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                title,
                style: TextStyle(fontSize: 12, color: _textColor, fontWeight: FontWeight.w500), // Уменьшенный размер и измененный вес шрифта
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // XP Breakdown Section (adapted for race results with record bonus)
  Widget _buildXpBreakdownSection(int? xp, List<dynamic>? achievements, List<dynamic>? challenges, int baseXp, int recordBonusXp, int achievementsXp, int challengesXp) {
    if (xp == null || xp == 0) {
      return Padding(
        padding: const EdgeInsets.only(left: 8.0),
        child: Text(
          'ДЕТАЛИЗАЦИЯ XP: 0 XP',
          style: TextStyle(fontSize: 14, fontStyle: FontStyle.italic, color: _secondaryTextColor),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader('ДЕТАЛИЗАЦИЯ XP:', _primaryAccentColor),
        const SizedBox(height: 5),
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ЗА ГОНКУ: $baseXp XP', style: TextStyle(fontSize: 15, color: _textColor)),
              if (recordBonusXp > 0)
                Text('БОНУС ЗА РЕКОРД: +$recordBonusXp XP', style: TextStyle(fontSize: 15, color: _primaryAccentColor)),
              if (achievementsXp > 0)
                Text('ДОСТИЖЕНИЯ: +$achievementsXp XP', style: TextStyle(fontSize: 15, color: _primaryAccentColor)),
              if (challengesXp > 0)
                Text('ЧЕЛЛЕНДЖИ: +$challengesXp XP', style: TextStyle(fontSize: 15, color: _secondaryAccentColor)),
            ],
          ),
        ),
      ],
    );
  }
}