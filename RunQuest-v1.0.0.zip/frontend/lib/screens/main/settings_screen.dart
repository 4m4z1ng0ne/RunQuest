import 'package:flutter/material.dart';
import 'package:frontend/screens/main/edit_profile_screen.dart'; // For navigation to EditProfileScreen
import 'package:frontend/screens/main/unit_settings_screen.dart'; // Import UnitSettingsScreen
import 'package:frontend/screens/main/about_app_screen.dart'; // Import AboutAppScreen
import 'package:frontend/screens/main/notification_settings_screen.dart'; // Import NotificationSettingsScreen
import 'package:frontend/screens/main/suggest_route_screen.dart'; // Import SuggestRouteScreen

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Define accent colors and text colors for consistent styling
  final Color _primaryAccentColor = const Color(0xFFC0FF00); // Ярко-зеленый
  final Color _textColor = Colors.black;
  final Color _backgroundColor = Colors.white;
  final Color _borderColor = const Color(0xFFACACAC); // Серый для границ
  final Color _secondaryTextColor = Colors.black54;

  // State for toggle switches
  bool _showMyResults = true;
  bool _isProfilePrivate = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        backgroundColor: _backgroundColor, // Белый фон AppBar
        elevation: 0, // Убираем тень
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'НАСТРОЙКИ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: _textColor,
              ),
            ),
          ],
        ),
        centerTitle: true, // Центрируем заголовок
        iconTheme: IconThemeData(color: _textColor), // Черные иконки
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Section: АККАУНТ
            _buildSectionTitle('АККАУНТ'),
            _buildGridActionButton(
              icon: Icons.person,
              label: 'РЕДАКТИРОВАТЬ ПРОФИЛЬ',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const EditProfileScreen()),
                );
              },
            ),
            const SizedBox(height: 20),

            // Section: ПРЕДПОЧТЕНИЯ
            _buildSectionTitle('ПРЕДПОЧТЕНИЯ'),
            _buildGridActionButton(
              icon: Icons.straighten, // Иконка для единиц измерения
              label: 'ЕДИНИЦЫ ИЗМЕРЕНИЯ',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const UnitSettingsScreen()),
                );
              },
            ),
            _buildGridActionButton(
              icon: Icons.notifications, // Иконка для уведомлений
              label: 'УВЕДОМЛЕНИЯ',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NotificationSettingsScreen()),
                );
              },
            ),
            const SizedBox(height: 20),

            // Section: ПРИВАТНОСТЬ
            _buildSectionTitle('ПРИВАТНОСТЬ'),
            _buildPrivacySwitch(
              icon: Icons.visibility,
              label: 'Показывать мои результаты',
              value: _showMyResults,
              onChanged: (bool value) {
                setState(() {
                  _showMyResults = value;
                });
                // TODO: Save setting
              },
            ),
            _buildPrivacySwitch(
              icon: Icons.lock,
              label: 'Приватный профиль',
              value: _isProfilePrivate,
              onChanged: (bool value) {
                setState(() {
                  _isProfilePrivate = value;
                });
                // TODO: Save setting
              },
            ),
            const SizedBox(height: 20),

            // Section: О ПРИЛОЖЕНИИ
            _buildSectionTitle('О ПРИЛОЖЕНИИ'),
            _buildGridActionButton(
              icon: Icons.info,
              label: 'О ПРИЛОЖЕНИИ',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AboutAppScreen()),
                );
              },
            ),
            // Кнопка для перехода на экран предложения маршрута
            _buildGridActionButton(
              icon: Icons.alt_route,
              label: 'ПРЕДЛОЖИТЬ МАРШРУТ',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SuggestRouteScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // Reusable widget for section titles
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 4.0),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontFamily: 'Satoshi',
          fontWeight: FontWeight.w700,
          fontSize: 14,
          color: _textColor.withOpacity(0.7),
        ),
      ),
    );
  }

  // Reusable widget for grid action buttons
  Widget _buildGridActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.all(4.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.0),
        border: Border.all(color: _borderColor, width: 1.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10.0),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Оборачиваем часть с иконкой и текстом в Expanded, чтобы она занимала доступное пространство
              Expanded(
                child: Row(
                  children: [
                    Icon(icon, size: 20, color: const Color.fromARGB(255, 94, 94, 94)),
                    const SizedBox(width: 8),
                    // Оборачиваем текст в Flexible, чтобы он мог переноситься на новую строку
                    Flexible(
                      child: Text(
                        label,
                        style: TextStyle(
                          fontFamily: 'Satoshi',
                          fontWeight: FontWeight.w500,
                          fontSize: 12,
                          color: _textColor,
                        ),
                        maxLines: 2, // Разрешаем до двух строк
                        overflow: TextOverflow.ellipsis, // Добавляем многоточие, если текст все равно не помещается
                        softWrap: true, // Включаем перенос текста
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[700]),
            ],
          ),
        ),
      ),
    );
  }

  // Reusable widget for privacy switches
  Widget _buildPrivacySwitch({
    required IconData icon,
    required String label,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.all(4.0),
      padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 15.0), // Smaller padding for switches
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.0),
        border: Border.all(color: _borderColor, width: 1.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Оборачиваем часть с иконкой и текстом в Expanded, чтобы она занимала доступное пространство
          Expanded(
            child: Row(
              children: [
                Icon(icon, size: 20, color: const Color.fromARGB(255, 94, 94, 94)),
                const SizedBox(width: 8),
                // Оборачиваем текст в Flexible, чтобы он мог переноситься на новую строку
                Flexible(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontFamily: 'Satoshi',
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                      color: _textColor,
                    ),
                    maxLines: 2, // Разрешаем до двух строк
                    overflow: TextOverflow.ellipsis, // Добавляем многоточие, если текст все равно не помещается
                    softWrap: true, // Включаем перенос текста
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: _primaryAccentColor, // Ярко-зеленый
            inactiveThumbColor: Colors.grey,
            inactiveTrackColor: Colors.grey.shade300,
          ),
        ],
      ),
    );
  }
}