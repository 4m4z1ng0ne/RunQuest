import 'package:flutter/material.dart';

class LastActivitiesScreen extends StatefulWidget {
  const LastActivitiesScreen({super.key});

  @override
  State<LastActivitiesScreen> createState() => _LastActivitiesScreenState();
}

class _LastActivitiesScreenState extends State<LastActivitiesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('история'), // Title from Figma
        // TODO: Add back button if needed (depends on navigation flow)
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Список последних активностей (TODO)', // Placeholder text
              style: TextStyle(fontSize: 18),
            ),
            // TODO: Implement actual list view for activities based on data
          ],
        ),
      ),
    );
  }
} 