import 'package:flutter/material.dart';

class StatisticsScreen extends StatefulWidget {
  final Map<String, dynamic>? profileData;

  const StatisticsScreen({super.key, this.profileData});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {

  // Helper function to format distance
  String _formatDistance(double meters) {
     if (meters == 0 || meters < 0) return 'N/A';
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} м';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} км';
    }
  }

  // Helper to format time from hours to HH:MM:SS or similar if needed
  String _formatHours(double hours) {
       if (hours <= 0) return '0ч 0м';
        int totalSeconds = (hours * 3600).round();
        int minutes = (totalSeconds ~/ 60) % 60;
        int hoursInt = totalSeconds ~/ 3600;
        return '$hoursIntч $minutesм';
    }

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic>? statistics = widget.profileData?['statistics'];

    if (statistics == null || statistics.isEmpty) {
      // Return a message if statistics are not available
      return Scaffold(
        appBar: AppBar(
          title: const Text('Статистика'),
        ),
        body: const Center(
          child: Text('Статистика недоступна.'),
        ),
      );
    }

    // Extract statistics data with null and type checks
    final int totalRuns = (statistics['total_runs'] as num?)?.toInt() ?? 0;
    final double totalDistanceKm = (statistics['total_distance_km'] as num?)?.toDouble() ?? 0.0;
    final double totalDurationHours = (statistics['total_duration_hours'] as num?)?.toDouble() ?? 0.0;
    final int totalXpEarned = (statistics['total_xp_earned'] as num?)?.toInt() ?? 0;
    final int completedChallengesCount = (statistics['completed_challenges_count'] as num?)?.toInt() ?? 0;
    final int achievementsCount = (statistics['achievements_count'] as num?)?.toInt() ?? 0;


    return Scaffold(
      appBar: AppBar(
        title: const Text('Статистика'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Общая статистика',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8.0),
              Card(
                elevation: 2.0,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Всего забегов: $totalRuns', style: const TextStyle(fontSize: 12)),
                      Text('Общая дистанция: ${_formatDistance(totalDistanceKm * 1000)}', style: const TextStyle(fontSize: 12)),
                      Text('Общее время: ${_formatHours(totalDurationHours)}', style: const TextStyle(fontSize: 12)),
                      Text('Всего опыта заработано: $totalXpEarned', style: const TextStyle(fontSize: 12)),
                      Text('Выполнено челленджей: $completedChallengesCount', style: const TextStyle(fontSize: 12)),
                      Text('Получено достижений: $achievementsCount', style: const TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              ),
               const SizedBox(height: 16.0), // Spacing after the statistics card
               // TODO: Add more detailed statistics sections here later
            ],
          ),
        ),
      ),
    );
  }
} 