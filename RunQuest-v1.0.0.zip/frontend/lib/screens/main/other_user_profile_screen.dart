import 'package:flutter/material.dart';
import 'package:frontend/screens/main/achievements_screen.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
//import 'package:frontend/screens/auth/login_screen.dart'; // Import LoginScreen for navigation
import 'package:frontend/screens/main/run_detail_screen.dart'; // Import RunDetailScreen
//import 'package:frontend/screens/main/edit_profile_screen.dart'; // Import EditProfileScreen
//import 'package:frontend/screens/tabs/achievements_screen.dart'; // Import AchievementsScreen
import 'package:frontend/services/activity_feed_service.dart'; // Import ActivityFeedService
import 'package:frontend/screens/main/statistics_screen.dart'; // Import StatisticsScreen
import 'package:frontend/screens/main/schedule_joint_run_screen.dart'; // Import ScheduleJointRunScreen
import 'package:dio/dio.dart'; // Import Dio for error handling
//import 'package:frontend/models/user.dart'; // Import User model
import 'package:frontend/services/friend_service.dart'; // Import FriendService
import 'package:frontend/models/challenge.dart'; // Import Challenge model
import 'package:frontend/models/user_challenge.dart'; // Import UserChallenge model
import 'package:frontend/screens/main/challenges_screen.dart'; // Import ChallengesScreen


class OtherUserProfileScreen extends StatefulWidget {
  final int userId;

  const OtherUserProfileScreen({super.key, required this.userId});

  @override
  State<OtherUserProfileScreen> createState() => _OtherUserProfileScreenState();
}

class _OtherUserProfileScreenState extends State<OtherUserProfileScreen> {
  final AuthService _authService = AuthService();
  Map<String, dynamic>? _profileData;
  List<dynamic> _achievements = [];
  List<UserChallenge> _userChallenges = []; // New list for user challenges
  List<dynamic> _allAchievements = []; // Needed to display achievement details
  bool _isLoading = true;
  String? _errorMessage;
  String? _friendshipStatus; // Field to store friendship status
  int? _friendshipId; // Field to store friendship ID
  bool profileAccessDenied = false;
  String message = '';
  bool _isBlockedByViewer = false; // Новая переменная для статуса блокировки
  bool _viewerIsBlocked = false;   // Новая переменная для статуса блокировки

  // Define accent colors
  final Color _primaryAccentColor = const Color(0xFF6BFF00); // Ярко-зеленый, неоновый
  final Color _secondaryAccentColor = const Color(0xFFFF8C00); // Ярко-оранжевый, неоновый

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    if (!mounted) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final profileResponse = await _authService.getProfile(userId: widget.userId);
      final achievementsResponse = await _authService.getUserAchievements(userId: widget.userId);
      final userChallengesResponse = await _authService.getUserChallenges(userId: widget.userId);
      final allAchievementsResponse = await ActivityFeedService().getAllAchievements();
      final friendshipStatusResponse = await _authService.getFriendshipStatus(widget.userId);
      final blockStatusResponse = await _authService.getBlockStatus(widget.userId); // Получаем статус блокировки

      if (!mounted) return;

      if (profileResponse.statusCode == 200 && 
          achievementsResponse.statusCode == 200 && 
          userChallengesResponse.statusCode == 200 &&
          allAchievementsResponse.statusCode == 200 &&
          friendshipStatusResponse.statusCode == 200 &&
          blockStatusResponse.isNotEmpty) { // Проверяем, что ответ о блокировке не пустой
        setState(() {
          _profileData = profileResponse.data;

          profileAccessDenied = _profileData?['profile_access_denied'] ?? false;
          message = _profileData?['message'] ?? '';

          // Обновляем статусы блокировки
          _isBlockedByViewer = blockStatusResponse['is_blocked_by_viewer'] ?? false;
          _viewerIsBlocked = blockStatusResponse['viewer_is_blocked'] ?? false;

          if (achievementsResponse.data is List) {
            _achievements = achievementsResponse.data;
          } else if (achievementsResponse.data is Map && achievementsResponse.data.containsKey('results') && achievementsResponse.data['results'] is List) {
            _achievements = achievementsResponse.data['results'];
          } else {
            _achievements = [];
            print('Warning: Unexpected format for user achievements API response. Data: ${achievementsResponse.data}');
          }

          if (userChallengesResponse.data is List) {
            _userChallenges = (userChallengesResponse.data as List)
                .map((json) => UserChallenge.fromJson(json))
                .toList();
          } else if (userChallengesResponse.data is Map && userChallengesResponse.data.containsKey('results') && userChallengesResponse.data['results'] is List) {
            _userChallenges = (userChallengesResponse.data['results'] as List)
                .map((json) => UserChallenge.fromJson(json))
                .toList();
          } else {
            _userChallenges = [];
            print('Warning: Unexpected format for user challenges API response. Data: ${userChallengesResponse.data}');
          }

          if (allAchievementsResponse.data is List) {
            _allAchievements = allAchievementsResponse.data;
          } else if (allAchievementsResponse.data is Map && allAchievementsResponse.data.containsKey('results') && allAchievementsResponse.data['results'] is List) {
            _allAchievements = allAchievementsResponse.data['results'];
          } else {
            _allAchievements = [];
            print('Warning: Unexpected format for all achievements API response. Data: ${allAchievementsResponse.data}');
          }
           _friendshipStatus = friendshipStatusResponse.data['status']; // Save friendship status
           _friendshipId = friendshipStatusResponse.data['id']; // Save friendship ID
          _isLoading = false;
        });
      } else {
         // Handle specific error cases based on status codes if needed
        String errorDetail = 'Не удалось загрузить данные пользователя.\n';
         if (profileResponse.statusCode != 200) errorDetail += 'Профиль: ${profileResponse.statusCode}\n';
         if (achievementsResponse.statusCode != 200) errorDetail += 'Достижения: ${achievementsResponse.statusCode}\n';
         if (userChallengesResponse.statusCode != 200) errorDetail += 'Челленджи: ${userChallengesResponse.statusCode}\n'; // Add challenges status
          if (allAchievementsResponse.statusCode != 200) errorDetail += 'Все достижения: ${allAchievementsResponse.statusCode}\n';
          if (friendshipStatusResponse.statusCode != 200) errorDetail += 'Статус дружбы: ${friendshipStatusResponse.statusCode}\n';

        if (!mounted) return;
        setState(() {
          _errorMessage = errorDetail;
          _isLoading = false;
        });
        print('Error fetching user data: $errorDetail');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Произошла ошибка при загрузке данных: $e';
        _isLoading = false;
      });
      print('Error in _fetchUserData: $e');
    }
  }

  Future<void> _sendFriendRequest() async {
    if (!mounted) return;
    try {
      await FriendService().sendFriendRequest(widget.userId);
      setState(() {
        _friendshipStatus = 'pending';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья отправлен!')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка отправки запроса в друзья: $e')),
      );
    }
  }

  Future<void> _acceptFriendRequest() async {
    if (!mounted || _friendshipId == null) return;
    try {
      await FriendService().acceptFriendRequest(_friendshipId!);
      setState(() {
        _friendshipStatus = 'accepted';
        _friendshipId = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья принят!')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка принятия запроса в друзья: $e')),
      );
    }
  }

  Future<void> _rejectFriendRequest() async {
    if (!mounted || _friendshipId == null) return;
    try {
      await FriendService().rejectFriendRequest(_friendshipId!);
      setState(() {
        _friendshipStatus = 'rejected';
        _friendshipId = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Запрос в друзья отклонен.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка отклонения запроса в друзья: $e')),
      );
    }
  }

  Future<void> _cancelSentFriendRequest() async {
    if (!mounted || _friendshipId == null) return;
    try {
      await FriendService().cancelSentFriendRequest(_friendshipId!);
      setState(() {
        _friendshipStatus = 'not_friends'; // Assuming cancelling means they are no longer pending
        _friendshipId = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Отправленный запрос в друзья отменен.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка отмены запроса в друзья: $e')),
      );
    }
  }

  // New method to block a user
  Future<void> _blockUser() async {
    if (!mounted) return;
    try {
      final success = await _authService.blockUser(widget.userId);
      if (success) {
        setState(() {
          _isBlockedByViewer = true;
          // After blocking, friend status should reflect this
          _friendshipStatus = 'not_friends'; // Assuming blocking removes friendship
          _friendshipId = null;
          // Re-fetch data to update UI based on new block status (e.g., hide private profile content)
          _fetchUserData(); 
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Пользователь заблокирован.')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Не удалось заблокировать пользователя.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка блокировки пользователя: $e')),
      );
    }
  }

  // New method to unblock a user
  Future<void> _unblockUser() async {
    if (!mounted) return;
    try {
      final success = await _authService.unblockUser(widget.userId);
      if (success) {
        setState(() {
          _isBlockedByViewer = false;
          // Re-fetch data to update UI based on new block status
          _fetchUserData(); 
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Пользователь разблокирован.')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Не удалось разблокировать пользователя.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка разблокировки пользователя: $e')),
      );
    }
  }

  // Helper function to format duration
  String _formatDuration(int seconds) {
    if (seconds < 0) return 'N/A';
    final int hours = seconds ~/ 3600;
    final int minutes = (seconds % 3600) ~/ 60;
    final int remainingSeconds = seconds % 60;
    String result = '';
    if (hours > 0) result += '${hours}ч ';
    if (minutes > 0 || hours > 0) result += '${minutes}м '; // Always show minutes if hours are shown or if minutes are present
    result += '${remainingSeconds}с';
    return result.trim();
  }

  // Helper function to format distance
  String _formatDistance(double meters) {
    if (meters < 0) return 'N/A';
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} м';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} км';
    }
  }

  // Helper function to find achievement details by ID
  Map<String, dynamic>? _getAchievementDetails(int achievementId) {
    try {
      return _allAchievements.firstWhere(
          (achievement) => achievement['id'] == achievementId,
          // orElse: () => null, // Use orElse if you need to handle not found explicitly
        );
    } catch (e) {
      // Handle the case where no achievement is found with that ID
      print('Achievement with ID \$achievementId not found in _allAchievements.');
      return null;
    }
  }

  // New method to build the challenges section
  Widget _buildChallengesSection() {
    final bool showChallenges = _profileData?['show_challenges'] ?? false;
    final bool isCurrentUserProfile = widget.userId == (_authService.currentUser?.id ?? -1);

    if (!showChallenges && !isCurrentUserProfile) {
      return const SizedBox.shrink();
    }

    if (_userChallenges.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 8.0), // Отступы только по вертикали
      color: Colors.white, // Белый фон карточки
      elevation: 0, // Убираем стандартную тень Card
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero), // Острые углы
      child: Container( // Оборачиваем Padding в Container для рамки и тени
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), // Выраженная тень
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(color: _secondaryAccentColor, width: 2.0), // Рамка акцентного цвета (оранжевого)
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0), // Увеличиваем паддинг
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ВЫПОЛНЕННЫЕ ЧЕЛЛЕНДЖИ'.toUpperCase(), // Все заглавные
                style: const TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.0,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 16.0), // Увеличиваем отступ
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _userChallenges.length > 2 ? 2 : _userChallenges.length,
                itemBuilder: (context, index) {
                  final userChallenge = _userChallenges[index];
                  final challenge = userChallenge.challenge;

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10.0), // Отступ между элементами списка
                    child: Container(
                      padding: const EdgeInsets.all(12.0), // Паддинг внутри элемента
                      decoration: BoxDecoration(
                        color: _secondaryAccentColor.withOpacity(0.2), // Светлый оранжевый фон
                        borderRadius: BorderRadius.zero, // Острые углы
                        border: Border.all(color: _secondaryAccentColor, width: 1.0), // Оранжевая рамка
                      ),
                      child: Row(
                        children: [
                          Icon(
                            userChallenge.completed ? Icons.check_circle : Icons.circle_outlined,
                            color: userChallenge.completed ? _primaryAccentColor : Colors.grey[700], // Зеленый или темно-серый
                            size: 24, // Увеличиваем размер иконки
                          ),
                          const SizedBox(width: 12.0), // Отступ
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(challenge.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black)), // Все заглавные
                                Text(challenge.description?.toUpperCase() ?? '', style: TextStyle(color: Colors.black87, fontSize: 12)), // Все заглавные
                                if (userChallenge.completionDate != null)
                                  Text('ЗАВЕРШЕН: ${userChallenge.completionDate!.day.toString().padLeft(2, '0')}.${userChallenge.completionDate!.month.toString().padLeft(2, '0')}.${userChallenge.completionDate!.year}', style: TextStyle(color: Colors.black54, fontSize: 11)), // Все заглавные
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            if (_userChallenges.length > 2) // Show "Посмотреть все" button only if there are more than 2 challenges
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChallengesScreen(userId: widget.userId, showCompletedOnly: true), // Передаем userId
                      ),
                    );
                  },
                  style: TextButton.styleFrom(foregroundColor: _primaryAccentColor, textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 0.5)), // Стилизуем кнопку
                  child: const Text('ПОСМОТРЕТЬ ВСЕ'), // Все заглавные
                ),
              ),
          ],
        ),
      ),
    )
  );
}

  Widget _buildProfileSection() {
    if (_profileData == null) {
      return const SizedBox.shrink(); // Hide the section if profile data is not available
    }

    final username = _profileData!['username'] ?? 'N/A';
    final level = _profileData!['level'] ?? 0;
    final xp = _profileData!['experience_points'] ?? 0;

    // Determine if the current user is viewing their own profile
    final bool isCurrentUser = _authService.currentUser?.id == widget.userId;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 8.0), // Отступы только по вертикали
      color: Colors.white, // Белый фон карточки
      elevation: 0, // Убираем стандартную тень Card
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero), // Острые углы
      child: Container( // Оборачиваем Padding в Container для рамки и тени
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), // Выраженная тень
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(color: _primaryAccentColor, width: 2.0), // Рамка акцентного цвета
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0), // Увеличиваем паддинг
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                username.toUpperCase(), // Все заглавные
                style: const TextStyle(
                  fontSize: 28.0, // Увеличенный размер
                  fontWeight: FontWeight.w900, // Очень жирный
                  letterSpacing: 1.5,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 12.0), // Увеличиваем отступ
              if (_isBlockedByViewer) // Если текущий пользователь заблокировал этого пользователя
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ВЫ ЗАБЛОКИРОВАЛИ ЭТОГО ПОЛЬЗОВАТЕЛЯ. ВЫ НЕ МОЖЕТЕ ПРОСМАТРИВАТЬ ЕГО ПРОФИЛЬ ИЛИ ВЗАИМОДЕЙСТВОВАТЬ С НИМ.'.toUpperCase(), // Все заглавные
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.red[800], fontWeight: FontWeight.bold, fontSize: 14), // Более темный красный, жирный, побольше
                    ),
                    const SizedBox(height: 20.0), // Увеличиваем отступ
                    ElevatedButton(
                      onPressed: _unblockUser,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primaryAccentColor, // Акцентный цвет
                        foregroundColor: Colors.black, // Черный текст
                        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero, side: BorderSide(color: Colors.black, width: 2)), // Острые углы, черная обводка
                        elevation: 0,
                      ),
                      child: const Text('РАЗБЛОКИРОВАТЬ'),
                    ),
                  ],
                )
              else if (_viewerIsBlocked) // If the viewer is blocked by the profile owner
                Text(
                  'ВАС ЗАБЛОКИРОВАЛ ЭТОТ ПОЛЬЗОВАТЕЛЬ.'.toUpperCase(), // Все заглавные
                  style: TextStyle(fontStyle: FontStyle.italic, color: Colors.red[800], fontWeight: FontWeight.bold, fontSize: 14), // Темнее, жирнее, побольше
                )
              else if (profileAccessDenied && !_isBlockedByViewer) // If profile is private and not blocked by viewer
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      message.toUpperCase(), // Все заглавные
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey[700], fontWeight: FontWeight.bold, fontSize: 14), // Темнее, жирнее, побольше
                    ),
                    const SizedBox(height: 20.0), // Увеличиваем отступ
                    // Show friend request button only if not blocked
                    if (!_isBlockedByViewer) // Дублирование проверки, чтобы точно не показывалось
                      _buildFriendRequestButton(),
                  ],
                )
              else if (!profileAccessDenied) ...[ // Existing content for public/friend profiles, and not blocked
                Text(
                  'УРОВЕНЬ: $level'.toUpperCase(), // Все заглавные
                  style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                const SizedBox(height: 8.0),
                Text(
                  'ОПЫТ: $xp XP'.toUpperCase(), // Все заглавные
                  style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                const SizedBox(height: 20.0), // Увеличиваем отступ
                // Show friend request button only if not blocked
                if (!_isBlockedByViewer) // Дублирование проверки
                  _buildFriendRequestButton(),

                // Add Statistics and Joint Run Buttons here
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0), // Отступы только по вертикали
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 10.0), // Отступ между кнопками
                      // Hide these buttons if blocked by viewer or viewer is blocked
                      if (!_isBlockedByViewer && !_viewerIsBlocked) ...[
                        _buildActionButton(
                          text: 'ПОСМОТРЕТЬ СТАТИСТИКУ',
                          onPressed: () {
                            if (_profileData != null) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => StatisticsScreen(profileData: _profileData), // Pass profileData
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Данные профиля недоступны для статистики.')),
                              );
                            }
                          },
                          buttonColor: _primaryAccentColor,
                        ),
                        const SizedBox(height: 10.0), // Отступ между кнопками
                        _buildActionButton(
                          text: 'ПРИГЛАСИТЬ НА СОВМЕСТНУЮ ПРОБЕЖКУ',
                          onPressed: () {
                            if (_profileData != null) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ScheduleJointRunScreen(
                                    invitedUserId: widget.userId,
                                    invitedUsername: _profileData!['username'],
                                  ),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Данные профиля недоступны для приглашения.')),
                              );
                            }
                          },
                          buttonColor: _secondaryAccentColor, // Оранжевая кнопка
                        ),
                        const SizedBox(height: 10.0),
                      ], // End of conditional rendering for other buttons
                      // Block/Unblock Button
                      if (!isCurrentUser) // Do not show block button on own profile
                        if (_isBlockedByViewer) // If currently blocked by viewer, show unblock button
                          _buildActionButton(
                            text: 'РАЗБЛОКИРОВАТЬ',
                            onPressed: _unblockUser,
                            buttonColor: Colors.blueGrey, // Отдельный цвет для разблокировки
                          )
                        else if (!_viewerIsBlocked) // If not blocked by viewer and viewer not blocked, show block button
                          _buildActionButton(
                            text: 'ЗАБЛОКИРОВАТЬ',
                            onPressed: _blockUser,
                            buttonColor: Colors.red[700]!, // Красная кнопка для блокировки
                          ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

   Widget _buildAchievementsSection() {
     // Проверяем, должны ли показываться достижения
     final bool showAchievements = _profileData?['show_achievements'] ?? false;
     final bool isCurrentUserProfile = widget.userId == (_authService.currentUser?.id ?? -1);

     if (!showAchievements && !isCurrentUserProfile) {
       return const SizedBox.shrink(); // Скрываем, если достижения скрыты и это не профиль текущего пользователя
     }

     if (_achievements.isEmpty) {
      return const SizedBox.shrink(); // Не строим раздел, если нет достижений
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 8.0), // Отступы только по вертикали
      color: Colors.white, // Белый фон карточки
      elevation: 0, // Убираем стандартную тень Card
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero), // Острые углы
      child: Container( // Оборачиваем Padding в Container для рамки и тени
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.zero,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), // Выраженная тень
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(color: _primaryAccentColor, width: 2.0), // Рамка акцентного цвета (зеленого)
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0), // Увеличиваем паддинг
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ДОСТИЖЕНИЯ'.toUpperCase(), // Все заглавные
                style: const TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.0,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 16.0), // Увеличиваем отступ
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _achievements.length > 2 ? 2 : _achievements.length, // Display only the last 2 earned achievements
                itemBuilder: (context, index) {
                  final achievement = _achievements[index];
                  final achievementDetails = _getAchievementDetails(achievement['achievement']);
                  final bool isEarned = achievement['is_earned'] ?? false;
                  final String earnedDate = achievement['earned_date'] != null ? '${DateTime.parse(achievement['earned_date']).day.toString().padLeft(2, '0')}.${DateTime.parse(achievement['earned_date']).month.toString().padLeft(2, '0')}.${DateTime.parse(achievement['earned_date']).year}' : 'НЕИЗВЕСТНО'; // Все заглавные

                  if (achievementDetails == null) {
                     return const SizedBox.shrink(); // Skip if achievement details not found
                  }

                  final String name = achievementDetails['name'] ?? 'N/A';
                  final String description = achievementDetails['description'] ?? 'N/A';

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10.0), // Отступ между элементами списка
                    child: Container(
                      padding: const EdgeInsets.all(12.0), // Паддинг внутри элемента
                      decoration: BoxDecoration(
                        color: _primaryAccentColor.withOpacity(0.2), // Светлый зеленый фон
                        borderRadius: BorderRadius.zero, // Острые углы
                        border: Border.all(color: _primaryAccentColor, width: 1.0), // Зеленая рамка
                      ),
                      child: Row(
                        children: [
                          Icon(
                            isEarned ? Icons.check_circle : Icons.circle_outlined,
                            color: isEarned ? _primaryAccentColor : Colors.grey[700], // Зеленый или темно-серый
                            size: 24, // Увеличиваем размер иконки
                          ),
                          const SizedBox(width: 12.0), // Отступ
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black)), // Все заглавные
                                Text(description.toUpperCase(), style: TextStyle(color: Colors.black87, fontSize: 12)), // Все заглавные
                                 if (isEarned) // Only show earned date if earned
                                   Text('ПОЛУЧЕНО: $earnedDate', style: TextStyle(color: Colors.black54, fontSize: 11)), // Все заглавные
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            if (_achievements.length > 2) // Show "Посмотреть все" button only if there are more than 2 achievements
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AchievementsScreen(userId: widget.userId, showEarnedOnly: true), // Передаем userId
                      ),
                );
              },
                  style: TextButton.styleFrom(foregroundColor: _primaryAccentColor, textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 0.5)), // Стилизуем кнопку
                  child: const Text('ПОСМОТРЕТЬ ВСЕ'), // Все заглавные
                ),
            ),
          ],
        ),
      ),
    )
  );
}

   // Widget to display friend request button or status
  Widget _buildFriendRequestButton() {
    if (_isLoading || _isBlockedByViewer || _viewerIsBlocked) { // Hide button if blocked
      return const SizedBox.shrink();
    }

    if (_errorMessage != null || _profileData == null) {
      return const SizedBox.shrink();
    }

    if (_friendshipStatus == 'self') {
      return const SizedBox.shrink();
    }

    String buttonText;
    IconData buttonIcon;
    VoidCallback? onPressed;
    Color buttonColor; // Changed to non-nullable

    switch (_friendshipStatus) {
      case 'not_friends':
        buttonText = 'ДОБАВИТЬ В ДРУЗЬЯ'; // Все заглавные
        buttonIcon = Icons.person_add;
        onPressed = _sendFriendRequest;
        buttonColor = _primaryAccentColor; // Акцентный цвет
        break;
      case 'pending_sent':
        buttonText = 'ОТМЕНИТЬ ЗАПРОС'; // Все заглавные
        buttonIcon = Icons.send;
        onPressed = _cancelSentFriendRequest;
        buttonColor = _secondaryAccentColor; // Оранжевый цвет
        break;
      case 'pending_received':
        buttonText = 'ПРИНЯТЬ ЗАПРОС ДРУЖБЫ'; // Все заглавные
        buttonIcon = Icons.person_add_alt_1;
        onPressed = _acceptFriendRequest;
        buttonColor = _primaryAccentColor; // Акцентный цвет
        break;
      case 'accepted':
        buttonText = 'В ДРУЗЬЯХ'; // Все заглавные
        buttonIcon = Icons.check;
        onPressed = _confirmRemoveFriend;
        buttonColor = Colors.grey; // Серый цвет
        break;
      case 'blocked':
        return const SizedBox.shrink();
      default:
        return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0), // Отступ для кнопки
      child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(buttonIcon, color: Colors.black), // Черная иконка
        label: Text(buttonText), // Текст кнопки
          style: ElevatedButton.styleFrom(
          backgroundColor: buttonColor, // Цвет кнопки
          foregroundColor: Colors.black, // Черный текст
            minimumSize: const Size(double.infinity, 50), // Делаем кнопку широкой и выше
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5),
            shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero, side: BorderSide(color: Colors.black, width: 2)), // Острые углы, черная обводка
            elevation: 0,
        ),
      ),
    );
  }

  Future<void> _confirmRemoveFriend() async {
    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'ПОДТВЕРЖДЕНИЕ',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 18), // Стилизуем заголовок
          ),
          content: const Text(
            'ВЫ УВЕРЕНЫ, ЧТО ХОТИТЕ УДАЛИТЬ ЭТОГО ПОЛЬЗОВАТЕЛЯ ИЗ ДРУЗЕЙ?',
            style: TextStyle(color: Colors.black87, fontSize: 14), // Стилизуем контент
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false), // Return false on cancel
              style: TextButton.styleFrom(foregroundColor: Colors.black), // Черный текст
              child: const Text('ОТМЕНА'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true), // Return true on confirm
              style: TextButton.styleFrom(foregroundColor: Colors.red[700]), // Красный текст для удаления
              child: const Text('УДАЛИТЬ'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      _removeFriend(); // Proceed with removal if confirmed
    }
  }

  Future<void> _removeFriend() async {
    if (!mounted || _friendshipId == null) return;
    try {
      await FriendService().removeFriend(_friendshipId!);
      setState(() {
        _friendshipStatus = 'not_friends';
        _friendshipId = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ПОЛЬЗОВАТЕЛЬ УДАЛЕН ИЗ ДРУЗЕЙ.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка удаления друга: $e')),
      );
    }
  }

  // New reusable button builder
  Widget _buildActionButton({
    required String text,
    required VoidCallback onPressed,
    required Color buttonColor,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: buttonColor, // Используем переданный цвет
        foregroundColor: Colors.black, // Черный текст
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15), // Унифицированный паддинг
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero, side: BorderSide(color: Colors.black, width: 2)), // Острые углы, черная обводка
        elevation: 0,
        minimumSize: const Size(double.infinity, 50), // Делаем кнопки широкими и выше
      ),
      child: Text(text),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F0), // Светло-серый фон как в profile_screen
      appBar: AppBar(
        title: Text(
          (_profileData?['username'] ?? 'ПРОФИЛЬ ПОЛЬЗОВАТЕЛЯ').toUpperCase(), // Все заглавные
          style: const TextStyle(
            fontWeight: FontWeight.w900, // Очень жирный
            fontSize: 22,
            letterSpacing: 1.5,
            color: Colors.black, // Черный текст
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent, // Прозрачный фон AppBar
        elevation: 0, // Убираем тень
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black), // Черная иконка назад
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: const Color(0xFFC0FF00)))
          : _errorMessage != null
              ? Center(child: Text(_errorMessage!, style: const TextStyle(color: Colors.red, fontSize: 16)))
              : SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildProfileSectionModern(context),
                      const SizedBox(height: 24.0),
                      if (_profileData?['profile_access_denied'] != true) ...[
                        _buildAchievementsSectionModern(context),
                        const SizedBox(height: 20.0),
                        _buildChallengesSectionModern(context),
                      ],
                      const SizedBox(height: 16.0),
                    ],
                  ),
                ),
    );
  }

  Widget _buildProfileSectionModern(BuildContext context) {
    if (_profileData == null) {
      return const SizedBox.shrink();
    }
    final username = _profileData!['username'] ?? 'N/A';
    final level = _profileData!['level'] ?? 0;
    final xp = _profileData!['experience_points'] ?? 0;
    final String? avatarUrl = _profileData!['avatar'];
    // Метрики
    final statistics = _profileData!['statistics'] ?? {};
    final double totalDistanceKm = (statistics['total_distance_km'] as num?)?.toDouble() ?? 0.0;
    final int totalRuns = (statistics['total_runs'] as num?)?.toInt() ?? 0;
    final double totalDurationHours = (statistics['total_duration_hours'] as num?)?.toDouble() ?? 0.0;
    final int completedRaces = (statistics['completed_challenges_count'] as num?)?.toInt() ?? 0;
    // XP прогрес
    final int currentLevel = (level is int) ? level : int.tryParse(level.toString()) ?? 1;
    final int currentXP = (xp is int) ? xp : int.tryParse(xp.toString()) ?? 0;
    final int xpForCurrentLevelStart = (currentLevel - 1) * 1000;
    final int xpProgressInCurrentLevel = currentXP - xpForCurrentLevelStart;
    const int xpNeededForNextLevel = 1000;
    final double xpProgress = (xpProgressInCurrentLevel / xpNeededForNextLevel).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // --- Карточка пользователя ---
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24.0),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              // Аватар и уровень
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: const Color(0xFFE0E0E0),
                    backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                        ? NetworkImage(avatarUrl) as ImageProvider
                        : null,
                    child: avatarUrl == null || avatarUrl.isEmpty
                        ? const Icon(Icons.person, size: 60, color: Colors.white)
                        : null,
                  ),
                  if (level != 'N/A' && currentLevel > 0)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: const Color(0xFFC0FF00),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: Center(
                          child: Text(
                            currentLevel.toString(),
                            style: const TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 20.0),
              // Имя
              const Text(
                'ИМЯ',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4.0),
              Text(
                username.toUpperCase(),
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 16.0),
              // Прогрессбар XP
              SizedBox(
                width: double.infinity,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: xpProgress,
                    backgroundColor: Colors.grey[200],
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFC0FF00)),
                    minHeight: 15,
                  ),
                ),
              ),
              const SizedBox(height: 8.0),
              Text(
                'XP: $xpProgressInCurrentLevel / $xpNeededForNextLevel',
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24.0),
        // --- Метрики ---
        Column(
          children: [
            Row(
              children: [
                _buildStatCardModern('ВСЕГО ПРОЙДЕНО', '${totalDistanceKm.toStringAsFixed(2)} км'),
                _buildStatCardModern('ТРЕНИРОВОК', totalRuns.toString()),
              ],
            ),
            Row(
              children: [
                _buildStatCardModern('ОБЩЕЕ ВРЕМЯ', (() {
                  final int hours = totalDurationHours.floor();
                  final int minutes = ((totalDurationHours - hours) * 60).round();
                  if (hours > 0 && minutes > 0) return '${hours}ч ${minutes}м';
                  if (hours > 0) return '${hours}ч';
                  if (minutes > 0) return '${minutes}м';
                  return '0м';
                })()),
                _buildStatCardModern('ГОНОК', completedRaces.toString()),
              ],
            ),
          ],
        ),
        const SizedBox(height: 24.0),
        // --- Кнопки действий (дружба, статистика, пригласить, блокировка) ---
        _buildActionButtonsModern(context),
      ],
    );
  }

  Widget _buildStatCardModern(String title, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        margin: const EdgeInsets.all(8.0),
        height: 100.0,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 8.0),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtonsModern(BuildContext context) {
    // ... существующая логика, только визуал
    // Используем Column с кнопками в стиле profile_screen.dart
    List<Widget> buttons = [];
    if (!_isBlockedByViewer && !_viewerIsBlocked && !profileAccessDenied) {
      if (_friendshipStatus != 'self') {
        buttons.add(_buildFriendRequestButtonModern());
      }
      buttons.add(const SizedBox(height: 8));
      buttons.add(_buildModernButton('ПОСМОТРЕТЬ СТАТИСТИКУ', () {
        if (_profileData != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => StatisticsScreen(profileData: _profileData),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Данные профиля недоступны для статистики.')),
          );
        }
      }));
      buttons.add(const SizedBox(height: 8));
      buttons.add(_buildModernButton('ПРИГЛАСИТЬ НА СОВМЕСТНУЮ ПРОБЕЖКУ', () {
        if (_profileData != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ScheduleJointRunScreen(
                invitedUserId: widget.userId,
                invitedUsername: _profileData!['username'],
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Данные профиля недоступны для приглашения.')),
          );
        }
      }));
    }
    // Кнопка блокировки/разблокировки
    if (!_isBlockedByViewer && !_viewerIsBlocked && !profileAccessDenied && _friendshipStatus != 'self') {
      buttons.add(const SizedBox(height: 8));
      buttons.add(_buildModernButton('ЗАБЛОКИРОВАТЬ', _blockUser, color: Colors.red));
    } else if (_isBlockedByViewer) {
      buttons.add(const SizedBox(height: 8));
      buttons.add(_buildModernButton('РАЗБЛОКИРОВАТЬ', _unblockUser, color: Colors.blueGrey));
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: buttons,
    );
  }

  Widget _buildFriendRequestButtonModern() {
    // ... существующая логика, только визуал
    String buttonText;
    IconData buttonIcon;
    VoidCallback? onPressed;
    Color buttonColor;
    switch (_friendshipStatus) {
      case 'not_friends':
        buttonText = 'ДОБАВИТЬ В ДРУЗЬЯ';
        buttonIcon = Icons.person_add;
        onPressed = _sendFriendRequest;
        buttonColor = Colors.white;
        break;
      case 'pending_sent':
        buttonText = 'ОТМЕНИТЬ ЗАПРОС';
        buttonIcon = Icons.send;
        onPressed = _cancelSentFriendRequest;
        buttonColor = Colors.white;
        break;
      case 'pending_received':
        buttonText = 'ПРИНЯТЬ ЗАПРОС ДРУЖБЫ';
        buttonIcon = Icons.person_add_alt_1;
        onPressed = _acceptFriendRequest;
        buttonColor = Colors.white;
        break;
      case 'accepted':
        buttonText = 'В ДРУЗЬЯХ';
        buttonIcon = Icons.check;
        onPressed = _confirmRemoveFriend;
        buttonColor = Colors.white;
        break;
      default:
        return const SizedBox.shrink();
    }
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4.0),
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(buttonIcon, color: const Color(0xFFC0FF00), size: 20),
        label: Text(
          buttonText,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w500,
            fontFamily: 'Satoshi',
            color: Colors.black,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: buttonColor,
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
          ),
          elevation: 5,
          shadowColor: Colors.black.withOpacity(0.05),
          padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
        ),
      ),
    );
  }

  Widget _buildModernButton(String text, VoidCallback onPressed, {Color color = Colors.white}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4.0),
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
          ),
          elevation: 5,
          shadowColor: Colors.black.withOpacity(0.05),
          padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
          textStyle: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w500,
            fontFamily: 'Satoshi',
          ),
        ),
        child: Text(text.toUpperCase()),
      ),
    );
  }

  // --- Современные секции достижений и челленджей ---
  Widget _buildAchievementsSectionModern(BuildContext context) {
    // ... существующая логика, только визуал
    final bool showAchievements = _profileData?['show_achievements'] ?? false;
    final bool isCurrentUserProfile = widget.userId == (_authService.currentUser?.id ?? -1);
    if (!showAchievements && !isCurrentUserProfile) {
      return const SizedBox.shrink();
    }
    if (_achievements.isEmpty) {
      return const SizedBox.shrink();
    }
    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'ДОСТИЖЕНИЯ',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 10),
            for (var i = 0; i < _achievements.length && i < 2; i++) ...[
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Color(0xFFACACAC), width: 0.5),
                ),
                margin: const EdgeInsets.only(bottom: 8.0),
                elevation: 1,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _getAchievementDetails(_achievements[i]['achievement'])?['name']?.toUpperCase() ?? 'N/A',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _getAchievementDetails(_achievements[i]['achievement'])?['description']?.toUpperCase() ?? 'N/A',
                        style: const TextStyle(fontSize: 12, color: Colors.black87),
                      ),
                      if (_achievements[i]['is_earned'] ?? false)
                        Text(
                          'ПОЛУЧЕНО: ' + (_achievements[i]['earned_date'] != null ? '${DateTime.parse(_achievements[i]['earned_date']).day.toString().padLeft(2, '0')}.${DateTime.parse(_achievements[i]['earned_date']).month.toString().padLeft(2, '0')}.${DateTime.parse(_achievements[i]['earned_date']).year}' : 'НЕИЗВЕСТНО'),
                          style: const TextStyle(color: Colors.black54, fontSize: 11),
                        ),
                    ],
                  ),
                ),
              ),
            ],
            if (_achievements.length > 2)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AchievementsScreen(userId: widget.userId, showEarnedOnly: true),
                      ),
                    );
                  },
                  child: const Text('ПОСМОТРЕТЬ ВСЕ'),
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFFC0FF00),
                    textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 0.5),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildChallengesSectionModern(BuildContext context) {
    final bool showChallenges = _profileData?['show_challenges'] ?? false;
    final bool isCurrentUserProfile = widget.userId == (_authService.currentUser?.id ?? -1);
    if (!showChallenges && !isCurrentUserProfile) {
      return const SizedBox.shrink();
    }
    if (_userChallenges.isEmpty) {
      return const SizedBox.shrink();
    }
    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'ВЫПОЛНЕННЫЕ ЧЕЛЛЕНДЖИ',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 10),
            for (var i = 0; i < _userChallenges.length && i < 2; i++) ...[
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Color(0xFFACACAC), width: 0.5),
                ),
                margin: const EdgeInsets.only(bottom: 8.0),
                elevation: 1,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _userChallenges[i].challenge.name.toUpperCase(),
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _userChallenges[i].challenge.description?.toUpperCase() ?? '',
                        style: const TextStyle(fontSize: 12, color: Colors.black87),
                      ),
                      if (_userChallenges[i].completionDate != null)
                        Text(
                          'ЗАВЕРШЕН: ${_userChallenges[i].completionDate!.day.toString().padLeft(2, '0')}.${_userChallenges[i].completionDate!.month.toString().padLeft(2, '0')}.${_userChallenges[i].completionDate!.year}',
                          style: const TextStyle(color: Colors.black54, fontSize: 11),
                        ),
                    ],
                  ),
                ),
              ),
            ],
            if (_userChallenges.length > 2)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChallengesScreen(userId: widget.userId, showCompletedOnly: true),
                      ),
                    );
                  },
                  child: const Text('ПОСМОТРЕТЬ ВСЕ'),
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFFC0FF00),
                    textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 0.5),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
} 