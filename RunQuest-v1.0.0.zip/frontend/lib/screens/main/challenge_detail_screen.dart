import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart';

class ChallengeDetailScreen extends StatefulWidget {
  final Map<String, dynamic> challenge;
  final int? userChallengeId; // Will be null if user is not participating

  const ChallengeDetailScreen({super.key, required this.challenge, this.userChallengeId});

  @override
  State<ChallengeDetailScreen> createState() => _ChallengeDetailScreenState();
}

class _ChallengeDetailScreenState extends State<ChallengeDetailScreen> {
  bool _isParticipating = false;
  int? _currentUserChallengeId;
  final AuthService _authService = AuthService();

  // Define accent colors and text colors for consistent styling
  final Color _primaryAccentColor = const Color(0xFFC0FF00); // Ярко-зеленый
  final Color _textColor = Colors.black;
  final Color _backgroundColor = Colors.white;
  final Color _borderColor = const Color(0xFFACACAC); // Серый для границ
  final Color _secondaryTextColor = Colors.black54;

  @override
  void initState() {
    super.initState();
    _isParticipating = widget.userChallengeId != null;
    _currentUserChallengeId = widget.userChallengeId;
  }

  Future<void> _toggleParticipation() async {
    if (_isParticipating) {
      // Cancel participation
      if (_currentUserChallengeId != null) {
        try {
          final response = await _authService.cancelUserChallenge(_currentUserChallengeId!);
          if (response.statusCode == 204) {
            setState(() {
              _isParticipating = false;
              _currentUserChallengeId = null;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Участие в челлендже отменено.')),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Ошибка при отмене участия: ${response.data}')),
            );
          }
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Ошибка сети при отмене участия: $e')),
          );
        }
      }
    } else {
      // Join challenge
      try {
        final response = await _authService.joinChallenge(widget.challenge['id']);
        if (response.statusCode == 201) {
          setState(() {
            _isParticipating = true;
            _currentUserChallengeId = response.data['id']; // Get the new userChallengeId
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Вы присоединились к челленджу!')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Ошибка при присоединении: ${response.data}')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка сети при присоединении: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _backgroundColor, // Белый фон
        elevation: 0, // Без тени
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'ДЕТАЛИ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: _textColor,
              ),
            ),
            Text(
              'ЧЕЛЛЕНДЖА',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: _textColor,
              ),
            ),
          ],
        ),
        centerTitle: true,
        iconTheme: IconThemeData(color: _textColor), // Черные иконки
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Challenge Name
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: _borderColor, width: 1.0),
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    spreadRadius: 1,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
              widget.challenge['name'] ?? 'Название челленджа',
                style: TextStyle(
                  fontFamily: 'Satoshi',
                  fontWeight: FontWeight.w700,
                  fontSize: 18, // Увеличенный размер шрифта
                  color: _textColor,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 10),
            // Challenge Description
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: _borderColor, width: 1.0),
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    spreadRadius: 1,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
              widget.challenge['description'] ?? 'Описание челленджа',
                style: TextStyle(
                  fontFamily: 'Satoshi',
                  fontWeight: FontWeight.w400,
                  fontSize: 14, // Немного увеличенный размер
                  color: _textColor,
                ),
              ),
            ),
            const SizedBox(height: 20),
            // XP Reward Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: _borderColor, width: 1.0),
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    spreadRadius: 1,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                'Награда XP: ${widget.challenge['xp_reward'] ?? 'N/A'}',
                style: TextStyle(
                  fontFamily: 'Satoshi',
                  fontWeight: FontWeight.w700,
                  fontSize: 16, // Увеличенный размер
                  color: _primaryAccentColor, // Ярко-зеленый цвет для награды XP
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
            // Button to join/cancel challenge
            SizedBox(
              width: double.infinity, // Make button full width
              child: ElevatedButton(
                onPressed: _toggleParticipation,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isParticipating ? Colors.red : _primaryAccentColor, // Красный для отмены, Ярко-зеленый для присоединения
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 15.0), // Отступы как у других кнопок
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                  ),
                  elevation: 5, // Тень
                  textStyle: const TextStyle(
                    fontSize: 16.0, // Размер шрифта
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: Text(_isParticipating ? 'ОТМЕНИТЬ УЧАСТИЕ' : 'ПРИСОЕДИНИТЬСЯ'), // Текст заглавными
              ),
            ),
          ],
        ),
      ),
    );
  }
} 