// ignore_for_file: unnecessary_null_comparison

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:frontend/services/auth_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:frontend/screens/main/leaderboard_screen.dart';
import 'package:frontend/screens/main/active_race_screen.dart';
import 'dart:async'; // Import for StreamSubscription
// Import for WidgetsBindingObserver
// Import for TickerMode

class RaceMapScreen extends StatefulWidget {
  const RaceMapScreen({
    super.key,
  });

  @override
  State<RaceMapScreen> createState() => _RaceMapScreenState();
}

class _RaceMapScreenState extends State<RaceMapScreen> with WidgetsBindingObserver, TickerProviderStateMixin {
  List<dynamic> _startPoints = []; // State variable to store start points
  List<dynamic> _raceTracks = []; // State variable to store full race track data
  // Add state variables for visibility filters
  bool _showStartPoints = true; // State variable to control visibility of start points
  bool _showRaceTracks = false; // State variable to control visibility of race tracks (routes)
  String? _selectedRaceTrackId; // State variable to store the ID of the selected track

  final MapController _mapController = MapController(); // Add MapController

  LatLng? _userLocation; // State variable to store user's current location
  List<Map<String, dynamic>> _nearestStartPoints = []; // State variable for nearest start points
  bool _showNearestPointsWindow = true; // State variable to control visibility of the nearest points window

  String _searchQuery = ''; // State variable for the search query
  List<dynamic> _filteredRaceTracks = []; // State variable for filtered race tracks
  // TODO: Add state variable to store fetched race track routes
  StreamSubscription<Position>? _positionStreamSubscription; // Add stream subscription for location updates

  // Добавим переменную для статуса геолокации
  String _locationStatus = 'Ожидание...';
  bool _locationError = false;

  // Add TextEditingController for the search field
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    print('RaceMapScreenState: initState'); // Debug print
    _fetchAllRaceTracks(); // Fetch all race tracks when the widget is initialized
    //_updateUserLocation(); // Remove the one-time location update call
    // _startLocationUpdates(); // Start listening to location updates - move to didChangeDependencies
    WidgetsBinding.instance.addObserver(this); // Add observer for lifecycle changes
  }

  @override
  void dispose() {
    print('RaceMapScreenState: dispose'); // Debug print
    // TODO: Stop location tracking and dispose resources
    _mapController.dispose();
    _positionStreamSubscription?.cancel(); // Cancel the position stream subscription
    _positionStreamSubscription = null; // Explicitly set to null
    print('RaceMapScreenState: location stream cancelled and set to null'); // Debug print
    // Dispose the TextEditingController
    _searchController.dispose();
    WidgetsBinding.instance.removeObserver(this); // Remove observer
    print('RaceMapScreenState: observer removed'); // Debug print
    super.dispose();
    print('RaceMapScreenState: super.dispose called'); // Debug print
  }

  // Add didChangeDependencies to start location updates when the screen becomes active
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final isCurrent = ModalRoute.of(context)?.isCurrent ?? false;
    final isTicking = TickerMode.of(context); // Check TickerMode
    print('RaceMapScreenState: didChangeDependencies. isCurrent: $isCurrent, isTicking: $isTicking'); // Debug print
    // Start location updates only when the screen is currently active AND ticking
    if (isCurrent && isTicking) {
      if (_positionStreamSubscription == null) {
        print('RaceMapScreenState: Screen is current AND ticking, subscription is null, starting updates.'); // Debug print
        _startLocationUpdates();
      } else {
        print('RaceMapScreenState: Screen is current AND ticking, but subscription is not null.'); // Debug print
      }
    } else {
      // If the screen is not active OR not ticking, cancel the subscription
      if (_positionStreamSubscription != null) {
        print('RaceMapScreenState: Screen is NOT current OR NOT ticking, and subscription is NOT null, cancelling.'); // Debug print
        _positionStreamSubscription?.cancel();
        _positionStreamSubscription = null;
      } else {
        print('RaceMapScreenState: Screen is NOT current OR NOT ticking, and subscription is already null.'); // Debug print
      }
    }
  }

  // Override didChangeAppLifecycleState to handle app background/foreground changes
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('RaceMapScreenState: didChangeAppLifecycleState: $state'); // Debug print
    // Handle location updates based on app state (optional, but good practice)
    // For example, you might want to stop updates when the app is paused
    if (state == AppLifecycleState.paused) {
      if (_positionStreamSubscription != null) {
        print('RaceMapScreenState: App paused, cancelling location updates.'); // Debug print
        _positionStreamSubscription?.cancel();
        _positionStreamSubscription = null;
      }
    } else if (state == AppLifecycleState.resumed) {
      print('RaceMapScreenState: App resumed.'); // Debug print
      // Restart location updates if the screen is currently active AND ticking
      if (ModalRoute.of(context)?.isCurrent ?? false && TickerMode.of(context)) {
        if (_positionStreamSubscription == null) {
          print('RaceMapScreenState: App resumed and screen is current AND ticking, restarting location updates.'); // Debug print
          _startLocationUpdates();
        }
      }
    }
  }

  // Method to start listening to location updates
  void _startLocationUpdates() async {
    print('RaceMapScreenState: _startLocationUpdates called.'); // Debug print
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      print('RaceMapScreenState: Permission denied, requesting.'); // Debug print
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        print('RaceMapScreenState: Permission denied after request.'); // Debug print
        setState(() {
          _locationStatus = 'Нет разрешения на геолокацию';
          _locationError = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Нет разрешения на геолокацию')),
        );
        print('RaceMapScreenState: Location permissions are denied'); // Debug print
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      print('RaceMapScreenState: Permission permanently denied.'); // Debug print
      setState(() {
        _locationStatus = 'Геолокация навсегда запрещена';
        _locationError = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Геолокация навсегда запрещена')),
      );
       print('RaceMapScreenState: Location permissions is permanently denied'); // Debug print
      return;
    }

    setState(() {
      _locationStatus = 'Геолокация активна';
      _locationError = false;
    });
    print('RaceMapScreenState: Permissions granted, starting getPositionStream.'); // Debug print

    _positionStreamSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 0,
      ),
    ).listen((Position position) {
      print('RaceMapScreenState: Received location update: [32m${position.latitude}, ${position.longitude}[0m');
      setState(() {
        _userLocation = LatLng(position.latitude, position.longitude);
        _locationStatus = 'Последнее обновление: ${position.latitude.toStringAsFixed(5)}, ${position.longitude.toStringAsFixed(5)}';
        _locationError = false;
        _mapController.move(_userLocation!, _mapController.zoom);
        _findNearestStartPoints();
      });
    }, onError: (e) {
      print('RaceMapScreenState: Location stream error: $e'); // Debug print
      setState(() {
        _locationStatus = 'Ошибка получения геолокации';
        _locationError = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка геолокации: $e')),
      );
      print('RaceMapScreenState: Ошибка геолокации: $e');
    });
  }

  // Method to update user location and find nearest points
  // ignore: unused_element
  Future<void> _updateUserLocation() async {
    // This method is now replaced by _startLocationUpdates and its listener
    // Keeping it here for now in case it's called elsewhere, but its logic is moved.
    try {
      Position position = await _determinePosition();
      setState(() {
        _userLocation = LatLng(position.latitude, position.longitude);
        _findNearestStartPoints(); // Find nearest points after getting location
      });
    } catch (e) {
      print('Error getting user location: $e');
      // TODO: Show an error message to the user or handle permission denial
       setState(() {
        _userLocation = null; // Set location to null if an error occurs
        _nearestStartPoints = []; // Clear nearest points
      });
    }
  }

  // Method to find nearest start points
  void _findNearestStartPoints() {
    print('Attempting to find nearest start points. User location: $_userLocation, Start points count: ${_startPoints.length}'); // Debug print
    if (_userLocation == null || _startPoints.isEmpty) {
      setState(() {
        _nearestStartPoints = [];
        print('Nearest start points list is empty (no location or no points). Current nearest count: ${_nearestStartPoints.length}'); // Debug print
      });
      return;
    }

     List<Map<String, dynamic>> pointsWithDistance = _startPoints.map<Map<String, dynamic>>((point) {
       final distance = const Distance().as(LengthUnit.Kilometer, _userLocation!, LatLng(point['latitude'], point['longitude']));
       return { ...point, 'distance': distance };
     }).toList();

     pointsWithDistance.sort((a, b) => a['distance'].compareTo(b['distance']));

    setState(() {
       // Take top 5 nearest points
      _nearestStartPoints = pointsWithDistance.take(5).toList();
      print('Found nearest start points. Count: ${_nearestStartPoints.length}'); // Debug print
    });
  }

  // Method to fetch all race tracks from the backend
  Future<void> _fetchAllRaceTracks() async {
    try {
      final response = await AuthService().getAllRaceTracks();
      if (response.statusCode == 200) {
        print('Race tracks API response data: ${response.data}'); // Debug print to inspect data structure
        setState(() {
          _raceTracks = response.data; // Update state with fetched full data
          print('Fetched race tracks. Count: ${_raceTracks.length}'); // Debug print
          // Extract start points from the full data
          _startPoints = _raceTracks.map<Map<String, dynamic>?>((track) {
            if (track['route_definition'] != null && track['route_definition']['coordinates'] != null && track['route_definition']['coordinates'].isNotEmpty) {
              // Assuming coordinates are [longitude, latitude, elevation?] and we need [latitude, longitude]
              final startCoord = track['route_definition']['coordinates'][0];
              return {
                'id': track['id'].toString(), // Convert ID to string here
                'latitude': startCoord[1],
                'longitude': startCoord[0],
                'name': track['name'],
                // The distance here is the distance from the user to the start point,
                // calculated later in _findNearestStartPoints.
                // Track length and record are available in the main _raceTracks list.
              };
            }
            return null; // Return null for tracks without route definition or coordinates
          }).where((point) => point != null).toList().cast<Map<String, dynamic>>(); // Filter out null values and cast

          // Initialize filtered tracks with all tracks
          _filteredRaceTracks = List.from(_raceTracks);
          print('Extracted start points. Count: ${_startPoints.length}'); // Debug print
        });
      } else {
        // TODO: Handle error fetching race tracks
        print('Failed to fetch race tracks: ${response.statusCode}');
      }
    } catch (e) {
      // TODO: Handle network or other errors
      print('Error fetching race tracks: $e');
    }
  }

  // Method to filter race tracks based on search query
  void _filterRaceTracks(String query) {
    print('Filtering race tracks with query: $query'); // Debug print
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _filteredRaceTracks = List.from(_raceTracks);
      } else {
        _filteredRaceTracks = _raceTracks.where((track) {
          final trackName = track['name']?.toLowerCase() ?? '';
          return trackName.contains(query.toLowerCase());
        }).toList();
      }
      print('Filtered race tracks count: ${_filteredRaceTracks.length}'); // Debug print
    });
  }

  // Method to get the selected race track data
  Map<String, dynamic>? _getSelectedRaceTrackData() {
    print('Getting selected track data for ID: $_selectedRaceTrackId'); // Debug print
    if (_selectedRaceTrackId == null) return null;
    try {
      return _raceTracks.firstWhere((track) => track['id'].toString() == _selectedRaceTrackId);
    } catch (e) {
      // Handle case where track is not found (shouldn't happen if IDs are consistent)
      print('Error finding selected track data: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    print('RaceMapScreenState: build method called.'); // Debug print
    final selectedTrackData = _getSelectedRaceTrackData();
    print('Selected track data is null: ${selectedTrackData == null}'); // Debug print

    // Determine which polylines to display
    List<Polyline> polylinesToDisplay = [];
    if (_selectedRaceTrackId != null && selectedTrackData != null) {
      // If a track is selected, show only its route
      if (selectedTrackData['route_definition'] != null && selectedTrackData['route_definition']['coordinates'] != null) {
         List<LatLng> points = selectedTrackData['route_definition']['coordinates'].map<LatLng>((coord) {
          return LatLng(coord[1], coord[0]); // Convert [lon, lat, ...] to LatLng(lat, lon)
        }).toList();
         polylinesToDisplay.add(Polyline(
          points: points,
          strokeWidth: 6.0, // Make selected route thicker
          color: const Color(0xFFD5FF2E), // Использовать ярко-неоновый зеленый для выбранного маршрута
        ));
      }
    } else if (_showRaceTracks) {
      // If no track is selected and the filter is on, show all routes
      polylinesToDisplay = _raceTracks.map((track) {
        if (track['route_definition'] != null && track['route_definition']['coordinates'] != null) {
          List<LatLng> points = track['route_definition']['coordinates'].map<LatLng>((coord) {
            return LatLng(coord[1], coord[0]); // Convert [lon, lat, ...] to LatLng(lat, lon)
          }).toList();
          return Polyline(
            points: points,
            strokeWidth: 4.0,
            color: const Color(0xFF00C6FF), // Использовать ярко-голубой для обычных маршрутов
            // TODO: Use different colors or styling for routes
          );
        }
        return null; // Return null for tracks without route definition
      }).where((polyline) => polyline != null).toList().cast<Polyline>();
    }

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight + 20.0), // Adjust height for rounded corners and padding
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white, // White background for AppBar
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)), // Rounded corners at the bottom
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1), // Subtle shadow
                spreadRadius: 1,
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
            child: AppBar(
              backgroundColor: Colors.transparent, // Make AppBar itself transparent as container provides color
              elevation: 0, // No shadow from AppBar itself
              title: const Text(
                'КАРТА',
                style: TextStyle(
                  fontFamily: 'Satoshi', // Игровой шрифт
                  fontWeight: FontWeight.w700,
                  fontSize: 18, // Adjusted font size
                  color: Colors.black, // Черный цвет текста
                  shadows: [
                    Shadow(
                      blurRadius: 3.0,
                      color: const Color.fromARGB(51, 0, 0, 0), // Changed to const Color.fromARGB
                      offset: const Offset(0.5, 0.5),
                    ),
                  ],
                ),
              ),
              centerTitle: true,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black), // Standard back arrow icon
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.filter_list, color: Colors.black), // Черная иконка фильтрации
                  onPressed: () async {
                    final result = await _showFilterOptions(context);
                    if (result != null) {
                      setState(() {
                        _showStartPoints = result['showStartPoints']!;
                        _showRaceTracks = result['showRaceTracks']!;
                      });
                    }
                  },
                  tooltip: 'Фильтр',
                ),
                IconButton(
                  icon: Icon(
                    _showNearestPointsWindow ? Icons.location_off : Icons.location_on,
                    color: Colors.black, // Черный цвет для иконки местоположения пользователя
                  ), // Иконка для показа/скрытия ближайших точек старта
                  onPressed: () {
                    setState(() {
                      _showNearestPointsWindow = !_showNearestPointsWindow;
                      print('Toggle nearest points window visibility: $_showNearestPointsWindow'); // Debug print
                    });
                  },
                  tooltip: _showNearestPointsWindow ? 'Скрыть ближайшие точки' : 'Показать ближайшие точки',
                ),
              ],
            ),
          ),
        ),
      ),
      body: Stack( // Use Stack to layer map and controls
        children: [
          FlutterMap(
            mapController: _mapController, // Assign the MapController
            options: const MapOptions(
              initialCenter: LatLng(56.012027, 92.867245), // Set initial center to Adam and Eve sculpture coordinates
              initialZoom: 14.0, // Set an appropriate initial zoom level
              // TODO: Configure map options like bounds, interaction, etc.
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.runquest.app', // Replace with your package name
                // TODO: Consider other tile providers or offline maps
              ),
              // Add markers for filtered start points
              if (_showStartPoints) // Conditionally display MarkerLayer
                MarkerLayer(
                  markers: _startPoints.map((point) => Marker(
                    point: LatLng(point['latitude'], point['longitude']),
                    width: 40.0, // Adjusted size to match icon
                    height: 40.0, // Adjusted size to match icon
                    child: GestureDetector(
                      onTap: () {
                        print('Marker tapped for point ID: ${point['id']}'); // Debug print
                        setState(() {
                          _selectedRaceTrackId = point['id']; // Set the selected track ID
                          print('Selected track ID set to: $_selectedRaceTrackId'); // Debug print
                        });
                        // Center map on the selected marker
                        _mapController.move(LatLng(point['latitude'], point['longitude']), _mapController.zoom);
                        print('Map centered on: ${point['latitude']}, ${point['longitude']}'); // Debug print
                      },
                      child: Image.asset(
                        _selectedRaceTrackId == point['id']
                            ? 'static/screens/map/active_race_icon.png' // Use active icon if selected
                            : 'static/screens/map/race_icon.png', // Use default icon otherwise
                        width: 40.0,
                        height: 40.0,
                      ), // Use Image.asset for custom icons
                    ), // Wrap the icon in GestureDetector
                    // TODO: Use a custom icon for start points
                  )).toList(),
                ),
               // Add user location marker
                if (_userLocation != null)
                  MarkerLayer(
                    markers: [
                      Marker(
                        point: LatLng(_userLocation!.latitude, _userLocation!.longitude),
                        width: 40.0,
                        height: 40.0,
                        child: Container(
                          child: const Icon(
                            Icons.my_location,
                            color: const Color.fromARGB(255, 255, 46, 46), // Изменяем цвет иконки на красный
                            size: 40.0,
                          ),
                        ),
                      ),
                    ],
                  ),
              // Use the determined list of polylines
              PolylineLayer(
                polylines: polylinesToDisplay,
              ),
            ],
          ),
          // Search Bar
          Positioned(
            top: 16.0,
            left: 16.0,
            right: 16.0,
            child: Card(
              elevation: 8.0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)), // Закругленные углы для карточки поиска
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0), // Отступы внутри карточки
                child: TextField(
              controller: _searchController, // Assign the controller
                  style: const TextStyle(
                    fontFamily: 'Satoshi', // Игровой шрифт для ввода
                    fontSize: 16, // Размер шрифта
                    color: Colors.black, // Цвет текста
                  ),
                  decoration: InputDecoration(
                hintText: 'Найти трассу...',
                    hintStyle: TextStyle(
                      fontFamily: 'Satoshi', // Игровой шрифт для подсказки
                      fontSize: 16, // Размер шрифта подсказки
                      color: Colors.black.withOpacity(0.6), // Цвет подсказки
                    ),
                    filled: true,
                    fillColor: Colors.white, // Белый фон
                    border: InputBorder.none, // Убрать стандартную границу TextField
                suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, color: Colors.black54), // Иконка очистки
                            onPressed: () {
                          _searchController.clear();
                          _filterRaceTracks('');
                            },
                          )
                    : null,
              ),
              onChanged: _filterRaceTracks,
                ),
              ),
            ),
          ),

          // Search Results List
          if (_searchQuery.isNotEmpty && _filteredRaceTracks.isNotEmpty)
            Positioned(
              top: 80.0, // Position below the search bar
              left: 10.0,
              right: 10.0,
              child: Card(
                elevation: 8.0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                child: ListView.builder(
                  shrinkWrap: true, // Use minimum space
                  physics: const NeverScrollableScrollPhysics(), // Disable scrolling within this list
                  itemCount: _filteredRaceTracks.length,
                  itemBuilder: (context, index) {
                    final track = _filteredRaceTracks[index];
                    return ListTile(
                      title: Text(track['name'] ?? 'Трек без названия'),
                      // TODO: Optionally display distance or other info
                      onTap: () {
                        print('Search result tapped for track ID: ${track['id']}'); // Debug print
                        setState(() {
                          _selectedRaceTrackId = track['id'].toString(); // Select the track and convert ID to string
                          _searchQuery = ''; // Clear search query and results
                           _filteredRaceTracks = []; // Clear search results list
                          print('Selected track ID set to: $_selectedRaceTrackId. Search cleared.'); // Debug print
                        });
                         // TODO: Center map on the selected track's start point
                         final startPoint = _startPoints.firstWhere((point) => point['id'] == track['id'].toString(), orElse: () => null); // Compare with string ID
                         if (startPoint != null) {
                            _mapController.move(LatLng(startPoint['latitude'], startPoint['longitude']), _mapController.zoom);
                            print('Map centered on search result start point: ${startPoint['latitude']}, ${startPoint['longitude']}'); // Debug print
                         } else {
                            print('Start point not found for search result track ID: ${track['id']}'); // Debug print
                         }
                      },
                    );
                  },
                ),
              ),
            ),

          // Map Controls Layer
          Positioned(
            bottom: 20.0,
            right: 20.0,
            child: Column(
              children: [
                Container(
                  width: 50, // Adjusted width for the pill shape
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30), // Pill shape
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 1,
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min, // Keep column compact
                    children: [
                      IconButton(
                        icon: const Icon(Icons.add, color: Colors.black),
                        onPressed: () {
                          _mapController.move(_mapController.center, _mapController.zoom + 1);
                        },
                      ),
                      Container(
                        height: 1, // Separator line
                        width: 40,
                        color: Colors.grey.withOpacity(0.5),
                      ),
                      IconButton(
                        icon: const Icon(Icons.remove, color: Colors.black),
                        onPressed: () {
                          _mapController.move(_mapController.center, _mapController.zoom - 1);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10), // Spacing between pill and location button
                FloatingActionButton(
                  mini: true,
                  onPressed: () {
                    print('Go to user location button pressed.');
                    _goToUserLocation();
                  },
                  heroTag: 'mapGoToUserLocationBtn',
                  backgroundColor: const Color(0xFFD5FF2E), // Neon green color from mockup
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
                  child: const Icon(Icons.my_location, color: Colors.black),
                ),
              ],
            ),
          ),

          // Info box for selected race track
          if (selectedTrackData != null)
            Positioned(
              bottom: 100.0, // Position above the map controls
              left: 20.0,
              right: 20.0,
              child: Card(
                elevation: 8.0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)), // Более закругленные углы
                child: Padding(
                  padding: const EdgeInsets.all(20.0), // Увеличенные отступы
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              selectedTrackData['name'] ?? 'Название трека',
                              style: TextStyle(
                                fontFamily: 'Satoshi', // Игровой шрифт
                                fontWeight: FontWeight.w700, // Жирный
                                fontSize: 20, // Увеличенный размер шрифта
                                color: Colors.black, // Черный текст
                                shadows: [
                                  Shadow(
                                    blurRadius: 5.0,
                                    color: Colors.black.withOpacity(0.3),
                                    offset: Offset(1.0, 1.0),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: Colors.black54), // Черная иконка закрытия
                            onPressed: () {
                              setState(() {
                                _selectedRaceTrackId = null; // Close the info box
                              });
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 12), // Увеличенный отступ
                      Text(
                        'Расстояние: ${selectedTrackData['length_meters']?.toStringAsFixed(2) ?? 'N/A'} м', // Display length in meters
                        style: TextStyle(
                          fontFamily: 'Satoshi', // Игровой шрифт
                          fontSize: 16,
                          color: Colors.black87,
                          shadows: [
                            Shadow(
                              blurRadius: 3.0,
                              color: Colors.black.withOpacity(0.2),
                              offset: Offset(0.5, 0.5),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        'Рекорд (сек): ${selectedTrackData['record_time_seconds'] ?? 'N/A'}', // Display record time in seconds
                        style: TextStyle(
                          fontFamily: 'Satoshi', // Игровой шрифт
                          fontSize: 16,
                          color: Colors.black87,
                          shadows: [
                            Shadow(
                              blurRadius: 3.0,
                              color: Colors.black.withOpacity(0.2),
                              offset: Offset(0.5, 0.5),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20), // Увеличенный отступ
                      SizedBox(
                        width: double.infinity, // Кнопка занимает всю доступную ширину
                        child: ElevatedButton(
                        onPressed: () {
                          // Navigate to Leaderboard screen
                          if (_selectedRaceTrackId != null) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => LeaderboardScreen(trackId: _selectedRaceTrackId!), // Navigate to LeaderboardScreen, passing track ID
                              ),
                            );
                          }
                        },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00C6FF), // Яркий голубой цвет
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Закругленные углы
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12), // Уменьшенный горизонтальный отступ
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center, // Центрирование содержимого
                            children: [
                              const Icon(Icons.leaderboard, color: Colors.black), // Иконка таблицы лидеров
                              const SizedBox(width: 8), // Отступ между иконкой и текстом
                              Expanded(
                                child: const Text(
                                  'Таблица лидеров',
                                  textAlign: TextAlign.center, // Центрирование текста
                                  maxLines: 1, // Ограничение одной строкой
                                  overflow: TextOverflow.ellipsis, // Многоточие при переполнении
                                  style: TextStyle(
                                    fontFamily: 'Satoshi', // Игровой шрифт
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.black, // Черный текст
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12), // Отступ между кнопками
                      SizedBox(
                        width: double.infinity, // Кнопка занимает всю доступную ширину
                        child: ElevatedButton(
                        onPressed: selectedTrackData != null ? () {
                          if (_selectedRaceTrackId != null) {
                            // Navigate to ActiveRaceScreen, passing the selected track ID
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ActiveRaceScreen(trackData: selectedTrackData), // Pass the entire track data
                              ),
                            );
                          }
                        } : null, // Button is disabled if no track is selected
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFD5FF2E), // Яркий неоновый цвет
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Закругленные углы
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12), // Уменьшенный горизонтальный отступ
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center, // Центрирование содержимого
                            children: [
                              const Icon(Icons.flag, color: Colors.black), // Иконка флага
                              const SizedBox(width: 8), // Отступ между иконкой и текстом
                              Expanded(
                                child: const Text(
                                  'Начать гонку',
                                  textAlign: TextAlign.center, // Центрирование текста
                                  style: TextStyle(
                                    fontFamily: 'Satoshi', // Игровой шрифт
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.black, // Черный текст
                  ),
                ),
              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

           // Nearest start points window
           if (_showNearestPointsWindow && _nearestStartPoints.isNotEmpty)
             Positioned(
               top: 20.0, // Position at the top
               left: 20.0,
               right: 20.0,
               bottom: 20.0, // Добавлено для ограничения высоты и предотвращения переполнения
               child: Card(
                 elevation: 8.0,
                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)), // Более закругленные углы
                 child: Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                      Padding(
                        padding: const EdgeInsets.all(20.0), // Увеличенные отступы
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible( // Или Expanded
                              flex: 1, // Если Flexible
                              child: Text(
                              'Ближайшие точки старта',
                                style: TextStyle(
                                  fontFamily: 'Satoshi', // Игровой шрифт
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Colors.black, // Черный текст
                                  // shadows: [
                                  //   Shadow(
                                  //     blurRadius: 5.0,
                                  //     color: Colors.black.withOpacity(0.3),
                                  //     offset: Offset(1.0, 1.0),
                                  //   ),
                                  // ],
                                ),
                              ),
                            ),
                             IconButton(
                               icon: const Icon(Icons.close, color: Colors.black54), // Черная иконка закрытия
                               onPressed: () {
                                 setState(() {
                                   _showNearestPointsWindow = false; // Close the window
                                 });
                               },
                             ),
                          ],
                        ),
                      ),
                     Expanded( // Изменено с Flexible на Expanded для лучшей адаптивности по вертикали
                       child: ListView.builder(
                       itemCount: _nearestStartPoints.length,
                       itemBuilder: (context, index) {
                         final point = _nearestStartPoints[index];
                         return ListTile(
                             title: Text(point['name'] ?? 'Точка старта',
                               style: TextStyle(
                                 fontFamily: 'Satoshi',
                                 fontSize: 16,
                                 color: Colors.black,
                                 shadows: [
                                   Shadow(
                                     blurRadius: 3.0,
                                     color: Colors.black.withOpacity(0.2),
                                     offset: Offset(0.5, 0.5),
                                   ),
                                 ],
                               ),
                             ),
                           // Display distance in appropriate units
                             subtitle: Text('До точки старта: ${point['distance']?.toStringAsFixed(2)} км',
                               style: TextStyle(
                                 fontFamily: 'Satoshi',
                                 fontSize: 14,
                                 color: Colors.black87,
                                 shadows: [
                                   Shadow(
                                     blurRadius: 2.0,
                                     color: Colors.black.withOpacity(0.1),
                                     offset: Offset(0.5, 0.5),
                                   ),
                                 ],
                               ),
                             ),
                           onTap: () {
                             // TODO: Navigate to or select this start point on the map
                             print('Нажата ближайшая точка: ${point['name']}');
                              setState(() {
                                _selectedRaceTrackId = point['id']; // Select the track when tapping the list item
                              });
                              // Center map on the selected nearest point
                              _mapController.move(LatLng(point['latitude'], point['longitude']), _mapController.zoom);
                              print('Map centered on nearest point: ${point['latitude']}, ${point['longitude']}');
                              // Optionally hide the nearest points window after selection
                              // setState(() {
                              //   _showNearestPointsWindow = false;
                              // });
                           },
                         );
                       },
                       ),
                     ),
                   ],
                 ),
               ),
             ),
        ],
      ),
    );
  }

  // Method to show filter options (e.g., in a dialog)
  Future<Map<String, bool>?> _showFilterOptions(BuildContext context) async {
    bool tempShowStartPoints = _showStartPoints; // Temporary state for the dialog
    bool tempShowRaceTracks = _showRaceTracks;   // Temporary state for the dialog

    return await showDialog<Map<String, bool>>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white, // Светлый фон
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)), // Закругленные углы
          title: Text(
            'Параметры отображения',
            style: TextStyle(
              fontFamily: 'Satoshi',
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: Colors.black,
              shadows: [
                Shadow(
                  blurRadius: 5.0,
                  color: Colors.black.withOpacity(0.3),
                  offset: Offset(1.0, 1.0),
                ),
              ],
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min, // Use minimum space for the column
            children: [
              CheckboxListTile(
                title: Text('Показать точки старта гонок',
                  style: TextStyle(
                    fontFamily: 'Satoshi',
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
                value: tempShowStartPoints,
                onChanged: (bool? newValue) {
                  setState(() {
                    tempShowStartPoints = newValue ?? true; // Update temporary state
                  });
                },
                activeColor: Color(0xFFD5FF2E), // Яркий неоновый цвет для активного состояния
                checkColor: Colors.black, // Черная галочка
              ),
              CheckboxListTile(
                title: Text('Показать маршруты гонок',
                  style: TextStyle(
                    fontFamily: 'Satoshi',
                    fontSize: 16,
                    color: Colors.black87,
                  ),
                ),
                value: tempShowRaceTracks,
                onChanged: (bool? newValue) {
                  setState(() {
                    tempShowRaceTracks = newValue ?? true; // Update temporary state
                  });
                },
                activeColor: Color(0xFF00C6FF), // Яркий голубой цвет для активного состояния
                checkColor: Colors.black, // Черная галочка
              ),
              // TODO: Add more filtering options here in the future
            ],
          ),
          actions: [
            TextButton(
              child: Text('Закрыть',
                style: TextStyle(
                  fontFamily: 'Satoshi',
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.black, // Черный текст
                
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop({'showStartPoints': tempShowStartPoints, 'showRaceTracks': tempShowRaceTracks}); // Return selected values
              },
              style: TextButton.styleFrom(
                backgroundColor: Color(0xFFD5FF2E), // Яркий оранжевый цвет
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Закругленные углы
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10), // Отступы
              ),
            ),
          ],
        );
      },
    );
  }

  // Method to go to user's current location
  Future<void> _goToUserLocation() async {
    try {
      // Request location permission and get current position
      Position position = await _determinePosition();
      setState(() {
        _userLocation = LatLng(position.latitude, position.longitude); // Update user location state
      });
      _mapController.move(LatLng(position.latitude, position.longitude), _mapController.zoom);
    } catch (e) {
      print('Error getting user location: $e');
      // TODO: Show an error message to the user
    }
  }

   // Determine the current position of the device.
  /// When the location services are not enabled or permissions
  /// are denied the `Future` will return an error.
  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the 
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale 
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever. Handle appropriately.
      return Future.error(
        'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    return await Geolocator.getCurrentPosition();
  }

  // Check if location services are enabled
  Future<bool> _checkLocationServices() async {
    bool isServiceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!isServiceEnabled) {
      // Location services are not enabled, show a message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Сервисы геолокации отключены. Пожалуйста, включите GPS.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return false;
    }
    return true;
  }

  // Find and show nearest race tracks
  Future<void> _findAndShowNearestRaceTracks() async {
    bool locationServicesEnabled = await _checkLocationServices();
    if (!locationServicesEnabled) {
      return; // Stop if location services are not enabled
    }

    if (_userLocation == null) {
      print('User location not available yet.');
      return;
    }

    // TODO: Implement logic to find nearest tracks
  }
} 