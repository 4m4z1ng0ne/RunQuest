import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart'; // Ensure SvgPicture is available
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:frontend/screens/main/challenge_detail_screen.dart'; // Import ChallengeDetailScreen
import 'package:collection/collection.dart'; // Import for firstWhereOrNull

class ChallengesScreen extends StatefulWidget {
  final int? userId;
  final bool showCompletedOnly;

  const ChallengesScreen({
    super.key,
    this.userId,
    this.showCompletedOnly = false, // Default to false
  });

  @override
  State<ChallengesScreen> createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends State<ChallengesScreen> with SingleTickerProviderStateMixin {
  // State variables for both lists of challenges
  List<dynamic> _allChallenges = [];
  List<dynamic> _userChallenges = []; // Active and completed challenges for the user
  bool _isLoading = true; // State variable for loading indicator

  late TabController _tabController; // Add TabController

  // Filter state for 'All Challenges' tab
  String _selectedFilter = 'Все'; // Default filter
  final List<String> _filters = ['Все', 'Доступные', 'Предстоящие', 'Завершенные'];

  String _formatProgressValue(dynamic value) {
    if (value == null) return '0.0';
    if (value is int) {
      return value.toDouble().toStringAsFixed(1);
    } else if (value is double) {
      return value.toStringAsFixed(1);
    }
    return value.toString(); // Fallback
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: widget.showCompletedOnly ? 1 : 2, vsync: this); // Initialize TabController
    if (widget.showCompletedOnly) {
      _tabController.animateTo(0); // Go to 'My Challenges' tab if showCompletedOnly is true
    }
    _fetchChallenges(); // Call the combined data fetching method
  }

  @override
  void dispose() {
    _tabController.dispose(); // Dispose TabController
    super.dispose();
  }

  // Combined method to fetch both lists
  Future<void> _fetchChallenges() async {
    setState(() {
      _isLoading = true; // Set loading to true at the start
    });
    try {
      print('Fetching all challenges and user challenges...'); // Debug print

      // Fetch all challenges
      try {
        final allChallengesResponse = await AuthService().getAllChallenges();
        print('Response status for all challenges: ${allChallengesResponse.statusCode}'); // Print status code
        if (allChallengesResponse.statusCode == 200) {
          _allChallenges = allChallengesResponse.data; // Assign the fetched data
          print('All challenges fetched successfully: ${_allChallenges.length} items');
          print('All challenges data preview: ${_allChallenges.take(5).toList()}'); // Print preview of data
        } else {
          print('Failed to fetch all challenges: ${allChallengesResponse.statusCode}');
          _allChallenges = [];
        }
      } catch (e) {
         print('Exception during fetching all challenges: $e'); // Print exception
         _allChallenges = []; // Ensure list is cleared on error
      }

      // Fetch user challenges based on userId prop
      final userChallengesResponse = await AuthService().getUserChallenges(userId: widget.userId);
      if (userChallengesResponse.statusCode == 200) {
        _userChallenges = userChallengesResponse.data; // Assign the fetched data
         print('User challenges fetched successfully: ${_userChallenges.length} items');
      } else {
         print('Failed to fetch user challenges: ${userChallengesResponse.statusCode}');
         _userChallenges = [];
      }

    } catch (e) {
      // Handle potential errors during fetching
      print('Error fetching challenges: $e');
      _allChallenges = [];
      _userChallenges = [];
    } finally {
      // Always set _isLoading to false after the fetch attempt
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

   // Method to handle joining a challenge
  Future<void> _joinChallenge(int challengeId) async {
    try {
      final joinResponse = await AuthService().joinChallenge(challengeId);
      if (joinResponse.statusCode == 201) {
        print('Successfully joined challenge $challengeId');
        // Refresh the lists after joining
        _fetchChallenges();
        // Optionally show a success message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Вы успешно присоединились к челленджу!'))
        );
      } else {
        print('Failed to join challenge $challengeId: ${joinResponse.statusCode}');
         // Optionally show an error message based on status code or response body
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не удалось присоединиться к челленджу: ${joinResponse.data?['detail'] ?? joinResponse.statusMessage}'))
        );
      }
    } catch (e) {
      print('Error joining challenge $challengeId: $e');
       ScaffoldMessenger.of(context).showSnackBar(
         SnackBar(content: Text('Произошла ошибка при присоединении к челленджу: $e'))
       );
    }
  }

  // Helper method to build challenge status chip
  Widget _buildChallengeStatusChip(Map<String, dynamic> challenge, DateTime now) {
    final DateTime? startTime = challenge['start_date'] != null ? DateTime.parse(challenge['start_date']) : null;
    final DateTime? endTime = challenge['end_date'] != null ? DateTime.parse(challenge['end_date']) : null;

    bool isUpcoming = startTime != null && now.isBefore(startTime);
    bool isEnded = endTime != null && now.isAfter(endTime);
    bool isCompleted = challenge['completed'] == true; // Check for completed status

    String statusText;
    Color statusBackgroundColor;
    Color statusTextColor;

    if (isCompleted) {
      statusText = 'Завершен';
      statusBackgroundColor = const Color(0xFFD5FF2E).withOpacity(0.5); // Light neon green background
      statusTextColor = const Color(0xFF000000); // Neon green text
    } else if (isUpcoming) {
      statusText = 'Предстоящий';
      statusBackgroundColor = const Color(0xFF00C6FF).withOpacity(0.2); // Light blue background
      statusTextColor = Colors.black; // Bright blue text
    } else if (isEnded) {
      statusText = 'Завершен'; // Already handled by isCompleted
      statusBackgroundColor = const Color(0xFFFF0000)!.withOpacity(0.5); // Grey background
      statusTextColor = Colors.grey[800]!; // Dark grey text
    } else {
      statusText = 'В процессе'; // Changed from Доступен
      statusBackgroundColor = const Color(0xFFFFFFFF).withOpacity(0.2); // Light pink background
      statusTextColor = const Color(0xFF000000); // Pink text
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0), // Increased padding
      decoration: BoxDecoration(
        color: statusBackgroundColor,
        borderRadius: BorderRadius.circular(20.0), // More rounded corners for the chip
        border: Border.all(color: statusTextColor.withOpacity(0.5), width: 1.0), // Border matching text color
      ),
      child: Text(
        statusText,
        style: TextStyle(
          fontSize: 11,
          color: statusTextColor,
          fontWeight: FontWeight.bold,
          fontFamily: 'Roboto',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Determine which challenges the user is already participating in
    final Set<int> userChallengeIds = _userChallenges.map<int?>((uc) => uc['challenge']?['id'] as int?).where((id) => id != null).cast<int>().toSet();
    
    final DateTime now = DateTime.now();

    // Добавьте эти определения здесь
    bool isUpcoming(dynamic challenge) {
      final DateTime? startTime = challenge['start_date'] != null ? DateTime.parse(challenge['start_date']) : null;
      return startTime != null && now.isBefore(startTime);
    }

    bool isEnded(dynamic challenge) {
      final DateTime? endTime = challenge['end_date'] != null ? DateTime.parse(challenge['end_date']) : null;
      return endTime != null && now.isAfter(endTime);
    }
    
    // Filter all challenges based on the selected filter and user's participation
    List<dynamic> challengesToShow = _allChallenges.where((challenge) {
      // First, exclude challenges the user has already joined from the 'Все челленджи' tab
      if (userChallengeIds.contains(challenge['id'])) {
        return false;
      }

      // Then apply the selected filter
      // Используйте новые функции isUpcoming и isEnded
      bool currentIsUpcoming = isUpcoming(challenge);
      bool currentIsEnded = isEnded(challenge);
      bool isAvailableNow = !currentIsUpcoming && !currentIsEnded;

      switch (_selectedFilter) {
        case 'Все':
          return true; // Show all non-joined challenges
        case 'Доступные':
          return isAvailableNow;
        case 'Предстоящие':
          return currentIsUpcoming; // Используйте новую переменную
        case 'Завершенные':
          return currentIsEnded; // Используйте новую переменную
        default:
          return true; // Default to showing all if filter is unknown
      }
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent, // Make AppBar transparent
        elevation: 0, // Remove shadow
        title: Text(
          'Челленджи',
          style: TextStyle(
            fontFamily: 'Satoshi', // Apply game-like font
            fontWeight: FontWeight.w700, // Make it bold
            fontSize: 24, // Increase font size
            color: Colors.black, // Dark text for contrast
          ),
        ),
        bottom: widget.showCompletedOnly
            ? null // Не показывать TabBar, если showCompletedOnly = true
            : TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFD5FF2E), // Neon green indicator
          labelColor: const Color(0xFFD5FF2E), // Neon green for selected tab
          unselectedLabelColor: Colors.grey[700], // Dark grey for unselected tab
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, fontFamily: 'Satoshi', color: Colors.black),
          unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, fontFamily: 'Satoshi', color: Colors.black),
          tabs: const [
            Tab(
              child: Center(
                child: Text(
                  'Мои \n челленджи',
                  textAlign: TextAlign.center,
                  
                ),
              ),
            ),
            Tab(
              child: Center(
                child: Text(
                  'Все \n челленджи',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator()) // Show loading indicator while fetching data
          : TabBarView(
              controller: _tabController,
              children: [
                // Tab 1: Мои челленджи
                _userChallenges.isEmpty
                    ? const Center(
                        child: Text(
                          'У вас нет активных или выполненных челленджей.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey, fontFamily: 'Roboto'), // Subtler text color
                        ),
                      )
              : ListView.builder(
                        padding: const EdgeInsets.all(16.0), // Add padding to the list
                        itemCount: _userChallenges.length,
                        itemBuilder: (context, index) {
                          final userChallenge = _userChallenges[index];
                          final challenge = userChallenge['challenge']; // Get challenge details from userChallenge object
                          final bool isCompleted = userChallenge['completed'] == true;
                          final DateTime now = DateTime.now();

                          return InkWell( // Wrap with InkWell for tap functionality
                            onTap: () async {
                              // Navigate to ChallengeDetailScreen for user's challenges
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ChallengeDetailScreen(
                                    challenge: challenge,
                                    userChallengeId: userChallenge['id'], // Pass userChallengeId
                                  ),
                                ),
                              );
                              _fetchChallenges(); // Refresh data after returning from detail screen
                            },
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 12.0), // Spacing between challenge cards
                              padding: const EdgeInsets.all(16.0),
                              decoration: BoxDecoration(
                                color: Theme.of(context).cardColor, // Background color for the card
                                borderRadius: BorderRadius.circular(15), // Rounded corners
                                border: Border.all(color: Colors.black.withOpacity(0.2), width: 1.0), // Subtle black border
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1), // Subtle shadow
                                    spreadRadius: 1,
                                    blurRadius: 3,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Flexible(
                                          child: Text(
                                          challenge['name'] ?? 'Название челленджа', // Challenge Name
                                          style: TextStyle(
                                            fontFamily: 'Roboto',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 16,
                                            color: Colors.black,
                                          ),
                                          maxLines: 3, // Limit to 3 lines
                                          overflow: TextOverflow.ellipsis, // Add ellipsis if overflow
                                        ),
                                      ),
                                      const SizedBox(width: 8), // Spacing
                                      _buildChallengeStatusChip(userChallenge, now), // Status chip
                                    ],
                                  ),
                                  const SizedBox(height: 8), // Spacing
                                  Text(
                                    challenge['description'] ?? 'Описание челленджа', // Challenge Description
                                            style: TextStyle(
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Colors.grey[700],
                                    ),
                                    maxLines: 4, // Limit description to 4 lines
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 8), // Spacing
                                  // Прогресс челленджа
                                  if (!isCompleted) // Показываем прогресс только для незавершенных челленджей
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8.0, bottom: 8.0), // Отступы для прогресс-бара
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center, // Выравнивание по центру по вертикали
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'ПРОГРЕСС:',
                                            style: TextStyle(
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 10, // Уменьшенный размер шрифта
                                              color: Colors.grey[700],
                                            ),
                                          ),
                                          const SizedBox(height: 4), // Небольшой отступ
                                          LinearProgressIndicator(
                                            value: (userChallenge['progress'] != null && challenge['target_value'] != null && challenge['target_value'] > 0)
                                                ? (userChallenge['progress'] / challenge['target_value']).clamp(0.0, 1.0)
                                                : 0.0, // Прогресс от 0.0 до 1.0
                                            backgroundColor: Colors.grey[300], // Фон прогресс-бара
                                            valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFC0FF00)), // Ярко-зеленый цвет прогресса
                                            minHeight: 8, // Высота прогресс-бара
                                            borderRadius: BorderRadius.circular(4), // Скругленные края
                                          ),
                                          const SizedBox(height: 4), // Небольшой отступ
                                          Text(
                                            (userChallenge['progress'] != null && challenge['target_value'] != null && challenge['target_value'] > 0)
                                                ? '${_formatProgressValue(userChallenge['progress'])}/${_formatProgressValue(challenge['target_value'])}'
                                                : '0.0/0.0',
                                            style: TextStyle(
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 10, // Уменьшенный размер шрифта
                                              color: Colors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  // Display completion details for completed challenges
                                  if (isCompleted && userChallenge['completion_date'] != null) // Only show if completed
                                    Text(
                                      'Выполнено: ${DateTime.parse(userChallenge['completion_date']).toLocal().toIso8601String().substring(0, 10)}', // Format date
                                      style: TextStyle(
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12,
                                        color: Colors.green[700], // Green for completion
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                // Tab 2: Все челленджи
                Column(
                        children: [
                    // Filter chips for 'Все челленджи'
                          Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          spacing: 12.0, // Space between chips
                          children: _filters.map((filter) {
                            return ChoiceChip(
                              label: Text(filter),
                              selected: _selectedFilter == filter,
                              selectedColor: const Color(0xFFD5FF2E), // Neon green for selected chip
                              onSelected: (selected) {
                                  setState(() {
                                  _selectedFilter = filter;
                                });
                              },
                              labelStyle: TextStyle(
                                fontFamily: 'Roboto',
                                fontWeight: _selectedFilter == filter ? FontWeight.bold : FontWeight.normal,
                                color: _selectedFilter == filter ? Colors.black : Colors.grey[700], // Black text on selected, grey on unselected
                              ),
                              backgroundColor: Colors.grey[200], // Light grey background for unselected chips
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20), // Rounded shape for chips
                                side: BorderSide(
                                  color: _selectedFilter == filter ? Colors.black : Colors.grey[400]!, // Border color
                                  width: 1.0,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                            ),
                          ),
                          Expanded(
                      child: challengesToShow.isEmpty
                          ? const Center(
                              child: Text(
                                'Нет челленджей, соответствующих выбранному фильтру.',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.grey, fontFamily: 'Roboto'), // Subtler text color
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16.0), // Horizontal padding for list
                              itemCount: challengesToShow.length,
                  itemBuilder: (context, index) {
                                final challenge = challengesToShow[index];
                                final DateTime now = DateTime.now();

                                return InkWell( // Wrap with InkWell for tap functionality
                                  onTap: () async {
                                    await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => ChallengeDetailScreen(
                                          challenge: challenge,
                                        ),
                                      ),
                                    );
                                    _fetchChallenges(); // Refresh data after returning from detail screen
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 12.0), // Spacing between challenge cards
                                    padding: const EdgeInsets.all(16.0),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).cardColor, // Background color for the card
                                      borderRadius: BorderRadius.circular(15), // Rounded corners
                                      border: Border.all(color: Colors.black.withOpacity(0.2), width: 1.0), // Subtle black border
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.1), // Subtle shadow
                                          spreadRadius: 1,
                                          blurRadius: 3,
                                          offset: const Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Flexible(
                                                child: Text(
                                                challenge['name'] ?? 'Название челленджа', // Challenge Name
                                                  style: TextStyle(
                                                  fontFamily: 'Roboto',
                                                  fontWeight: FontWeight.w700,
                                                    fontSize: 16,
                                                  color: Colors.black,
                                                ),
                                                maxLines: 3,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            const SizedBox(width: 8), // Spacing
                                            _buildChallengeStatusChip(challenge, now), // Status chip
                                          ],
                                        ),
                                        const SizedBox(height: 8), // Spacing
                                        Text(
                                          challenge['description'] ?? 'Описание челленджа', // Challenge Description
                                          style: TextStyle(
                                            fontFamily: 'Roboto',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 13,
                                            color: Colors.grey[700],
                                          ),
                                          maxLines: 4,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 8), // Spacing
                                        // Join button for available challenges
                                        if (!userChallengeIds.contains(challenge['id']) && !isUpcoming(challenge) && !isEnded(challenge)) // Only show if not joined and available
                                          Align(
                                            alignment: Alignment.bottomRight,
                                            child: ElevatedButton(
                                              onPressed: () => _joinChallenge(challenge['id']),
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: const Color(0xFFD5FF2E), // Neon green button
                                                foregroundColor: Colors.black, // Black text
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(10), // Slightly rounded corners
                                                ),
                                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                              ),
                                              child: const Text(
                                                'Присоединиться',
                                                  style: TextStyle(
                                                  fontFamily: 'Roboto',
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
              ],
                ),
    );
  }
} 

// Keep the existing TrainingStatus enum if it's used elsewhere
// enum TrainingStatus { notStarted, active, paused, finished }