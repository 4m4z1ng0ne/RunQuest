import 'package:flutter/material.dart';
import 'package:frontend/services/activity_feed_service.dart';
import 'package:dio/dio.dart';

class ActivityFeedScreen extends StatefulWidget {
  const ActivityFeedScreen({super.key});

  @override
  State<ActivityFeedScreen> createState() => _ActivityFeedScreenState();
}

class _ActivityFeedScreenState extends State<ActivityFeedScreen> {
  final ActivityFeedService _activityFeedService = ActivityFeedService();
  List<dynamic> _feedItems = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchFeed();
  }

  Future<void> _fetchFeed() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      Response response = await _activityFeedService.getActivityFeed();
      if (response.statusCode == 200) {
        setState(() {
          _feedItems = response.data is List
              ? response.data
              : (response.data['results'] ?? []);
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Ошибка загрузки: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Ошибка: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(child: Text(_error!, style: const TextStyle(color: Colors.red)));
    }
    if (_feedItems.isEmpty) {
      return const Center(child: Text('Нет событий в ленте.'));
    }
    return RefreshIndicator(
      onRefresh: _fetchFeed,
      child: ListView.builder(
        itemCount: _feedItems.length,
        itemBuilder: (context, index) {
          final item = _feedItems[index];
          return ListTile(
            title: Text(item['type'] ?? 'Событие'),
            subtitle: Text(item['description'] ?? ''),
            trailing: Text(item['created_at'] != null ? item['created_at'].toString().substring(0, 16) : ''),
          );
        },
      ),
    );
  }
} 