import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart';

class LeaderboardScreen extends StatefulWidget {
  final String trackId;

  const LeaderboardScreen({super.key, required this.trackId});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  List<dynamic> _leaders = [];
  bool _isLoading = true;
  String? _error;

  // Define accent colors and text colors for consistent styling
  final Color _primaryAccentColor = const Color(0xFFC0FF00); // Ярко-зеленый
  final Color _textColor = Colors.black;
  final Color _backgroundColor = Colors.white;
  final Color _borderColor = const Color(0xFFACACAC); // Серый для границ
  final Color _secondaryTextColor = Colors.black54;

  @override
  void initState() {
    super.initState();
    _fetchLeaderboard();
  }

  Future<void> _fetchLeaderboard() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final response = await AuthService().getLeaderboard(widget.trackId);
      if (response.statusCode == 200) {
        setState(() {
          _leaders = response.data is List ? response.data : (response.data['results'] ?? []);
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Ошибка загрузки: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Ошибка: $e';
        _isLoading = false;
      });
    }
  }

  String _formatTime(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final sec = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$sec';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _backgroundColor, // Белый фон
        elevation: 0, // Без тени
        title: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'ТАБЛИЦА',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: _textColor,
              ),
            ),
            Text(
              'ЛИДЕРОВ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w700,
                fontSize: 20,
                color: _textColor,
              ),
            ),
          ],
        ),
        centerTitle: true,
        iconTheme: IconThemeData(color: _textColor), // Черные иконки
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : _leaders.isEmpty
                  ? const Center(child: Text('Нет данных для этого трека'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(16.0), // Добавим padding к списку
                      itemCount: _leaders.length,
                      itemBuilder: (context, i) {
                        final leader = _leaders[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12.0), // Отступ между карточками
                          padding: const EdgeInsets.all(16.0), // Padding внутри карточки
                          decoration: BoxDecoration(
                            color: _backgroundColor, // Белый фон карточки
                            borderRadius: BorderRadius.circular(10.0), // Скругленные углы
                            border: Border.all(color: _borderColor, width: 1.0), // Серая обводка
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05), // Легкая тень
                                blurRadius: 5,
                                spreadRadius: 1,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              // Rank
                              SizedBox(
                                width: 40, // Фиксированная ширина для номера
                                child: Text(
                                  '#${i + 1}',
                                  style: TextStyle(
                                    fontFamily: 'Satoshi',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                    color: _textColor,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10), // Отступ
                              // Username and Time
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      leader['username'] ?? 'Без имени',
                                      style: TextStyle(
                                        fontFamily: 'Satoshi',
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        color: _textColor,
                                      ),
                                    ),
                                    Text(
                                      'Время: ${_formatTime(leader['duration_seconds'] ?? 0)}',
                                      style: TextStyle(
                                        fontFamily: 'Satoshi',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12,
                                        color: _secondaryTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // XP
                              Text(
                                '${leader['xp_earned'] ?? 0} XP',
                                style: TextStyle(
                                  fontFamily: 'Satoshi',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: _primaryAccentColor, // Ярко-зеленый цвет для XP
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
    );
  }
} 