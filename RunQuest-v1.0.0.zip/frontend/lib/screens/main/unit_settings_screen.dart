import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

// Constants for colors
const Color _kAccentColor = Color(0xFFC0FF00); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон, как в дизайне

class UnitSettingsScreen extends StatefulWidget {
  const UnitSettingsScreen({super.key});

  @override
  State<UnitSettingsScreen> createState() => _UnitSettingsScreenState();
}

class _UnitSettingsScreenState extends State<UnitSettingsScreen> {
  String _selectedUnit = 'km'; // Default to kilometers

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ЕДИНИЦЫ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
            Text(
              'ИЗМЕРЕНИЯ',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(color: Colors.black, width: 1.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      'ДИСТАНЦИЯ И СКОРОСТЬ',
                      style: TextStyle(
                        fontFamily: 'Satoshi',
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: Colors.grey[700],
                      ),
                    ),
                  ),
                  const Divider(color: Colors.black, height: 1.0),
                  _buildUnitOption(
                    label: 'километры (км)',
                    value: 'km',
                    groupValue: _selectedUnit,
                    onChanged: (String? value) {
                      setState(() {
                        _selectedUnit = value!;
                      });
                    },
                  ),
                  const Divider(color: Colors.black, height: 1.0),
                  _buildUnitOption(
                    label: 'мили (ми)',
                    value: 'miles',
                    groupValue: _selectedUnit,
                    onChanged: (String? value) {
                      setState(() {
                        _selectedUnit = value!;
                      });
                    },
                  ),
                ],
              ),
            ),
            // Placeholder for other settings sections
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildUnitOption({
    required String label,
    required String value,
    required String groupValue,
    required ValueChanged<String?> onChanged,
  }) {
    return InkWell(
      onTap: () => onChanged(value),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 12.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Text(
                label,
                style: const TextStyle(
                  fontFamily: 'Satoshi',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ),
            Radio<String>(
              value: value,
              groupValue: groupValue,
              onChanged: onChanged,
              activeColor: _kAccentColor, // Green color for active radio
            ),
          ],
        ),
      ),
    );
  }
} 