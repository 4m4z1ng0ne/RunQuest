import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:frontend/screens/auth/login_screen.dart'; // Import LoginScreen for navigation
// Import RunDetailScreen
import 'package:frontend/screens/main/edit_profile_screen.dart'; // Import EditProfileScreen
import 'package:frontend/screens/main/achievements_screen.dart'; // Import AchievementsScreen
import 'package:frontend/services/activity_feed_service.dart'; // Import ActivityFeedService
import 'package:frontend/screens/main/statistics_screen.dart';
// Import StatisticsScreen
import 'package:frontend/screens/main/color_scheme_screen.dart'; // Import ColorSchemeScreen
import 'package:frontend/screens/main/settings_screen.dart'; // Import SettingsScreen

class ProfileScreen extends StatefulWidget {
  final int? userId; // Make userId optional
  const ProfileScreen({super.key, this.userId});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final AuthService _authService = AuthService();
  Map<String, dynamic>? _profileData;
  List<dynamic> _achievements = [];
  List<dynamic> _runs = [];
  List<dynamic> _allAchievements = [];
  int _raceAttemptsCount = 0; // Добавлено для подсчета гонок
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    // Fetch initial data
    _fetchInitialData();
  }

  Future<void> _fetchInitialData() async {
    // Set loading to true at the start
    if (mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      await Future.wait([
        _fetchProfileData(widget.userId),
        _fetchUserAchievements(widget.userId),
        _fetchUserRuns(widget.userId),
        _fetchAllAchievements(),
        _fetchUserRaceAttempts(widget.userId),
      ]);
    } catch (e) {
      // Handle any errors during initial data fetching
      print('Error fetching initial profile data: $e');
      // Optionally show an error message to the user
    } finally {
      // Set loading to false after all initial fetches are attempted
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Refresh data when returning from EditProfileScreen
    // Only refresh if the widget is still mounted.
    if (mounted) { // Check if mounted
      // We can call the individual fetch methods here if needed, 
      // but _fetchInitialData handles the loading state.
      // For now, let's rely on _fetchInitialData to be called once in initState.
      // If you need to refresh data specifically when returning, 
      // you might want to call _fetchInitialData here or individual fetch methods.
      // However, calling _fetchInitialData here might reset the loading state unnecessarily.
      // Let's keep the refresh logic in .then() on the Navigator.push calls instead.
      // _fetchProfileData();
      // _fetchUserAchievements(); // Refresh achievements
      // _fetchUserRuns(); // Refresh runs
      // _fetchAllAchievements(); // Refresh all achievements
    }
  }

  Future<void> _fetchProfileData([int? userId]) async {
    // No need to set loading here, it's handled in _fetchInitialData
    // if (_profileData == null && mounted) { // Check if mounted before setState
    //    setState(() {
    //      _isLoading = true;
    //    });
    // }
    try {
      print('Fetching profile data...'); // Debug print
      final response = userId == null 
          ? await _authService.getProfile() 
          : await _authService.getProfile(userId: userId); // Pass userId to getProfile
      if (response.statusCode == 200) {
        if(mounted) { // Check if mounted before setState
          setState(() {
            _profileData = response.data;
             print('Profile data fetched successfully: $_profileData'); // Debug print
             print('Full Profile Data: $_profileData'); // Добавлено для отладки
          });
        }
      } else {
        print('Failed to load profile: ${response.statusCode}');
        // Handle error, maybe show a message
      }
    } catch (e) {
      print('Error fetching profile: $e');
      // Handle error, maybe show a message
    } finally {
      // No need to set loading here
      //  if (_profileData != null && mounted) { 
      //     setState(() {
      //       _isLoading = false;
      //     });
      //  }
    }
  }

   Future<void> _fetchUserAchievements([int? userId]) async {
     // No need to set loading here
    // if (_achievements.isEmpty && _profileData == null && mounted) { 
    //    setState(() {
    //      _isLoading = true;
    //    });
    // }
    try {
      print('Fetching user achievements...'); // Debug print
      final response = await _authService.getUserAchievements(userId: userId); // Pass userId
      if (response.statusCode == 200) {
        if(mounted) { // Check if mounted before setState
          setState(() {
             // Check if response.data is directly a List
            if (response.data is List) {
              _achievements = response.data;
            } else if (response.data is Map && response.data.containsKey('results') && response.data['results'] is List) {
               // Assuming the API response is paginated: {count: ..., results: [...], ...}
                _achievements = response.data['results'];
            } else {
                print('Warning: Unexpected format for user achievements API response. Data: ${response.data}');
                _achievements = []; // Default to empty list
            }
             print('User achievements fetched: ${_achievements.length} items'); // Debug print
          });
        }
      } else {
        print('Failed to load user achievements: ${response.statusCode}');
         // Handle error
      }
    } catch (e) {
      print('Error fetching user achievements: $e');
       // Handle error
    } finally {
       // No need to set loading here
        // if (_profileData != null && mounted) { 
        //   setState(() {
        //     _isLoading = false;
        //   });
        // }
    }
  }

   Future<void> _fetchUserRuns([int? userId]) async {
     // No need to set loading here
     // if (_runs.isEmpty && _profileData == null && mounted) { 
     //   setState(() {
     //     _isLoading = true;
     //   });
    // }
    try {
      print('Fetching user runs...'); // Debug print
      final response = await _authService.getUserRuns(userId: userId); // Pass userId
      if (response.statusCode == 200) {
        if(mounted) { // Check if mounted before setState
          setState(() {
            // Check if response.data is directly a List
            if (response.data is List) {
              _runs = response.data;
            } else if (response.data is Map && response.data.containsKey('results') && response.data['results'] is List) {
               // Assuming the API response is paginated: {count: ..., results: [...], ...}
                _runs = response.data['results'];
            } else if (response.data is Map && response.data.containsKey('results') && response.data['results'] is Map && response.data['results'].containsKey('features') && response.data['results']['features'] is List) {
              // Assuming the API response is a GeoJSON FeatureCollection: {..., results: {..., features: [...]}}
               _runs = response.data['results']['features'];
            } else {
                print('Warning: Unexpected format for runs API response. Data: ${response.data}');
                _runs = []; // Default to empty list
            }
            print('User runs fetched: ${_runs.length} items'); // Debug print
          });
        }
      } else {
        print('Failed to load runs: ${response.statusCode}');
        // Handle error
      }
    } catch (e) {
      print('Error fetching runs: $e');
      // Handle error
    } finally {
      // No need to set loading here
      // if (_profileData != null && mounted) { 
      //     setState(() {
      //       _isLoading = false;
      //     });
      //  }
    }
  }

  Future<void> _fetchAllAchievements() async {
    // No need to set loading here
    try {
      print('Fetching all achievements...'); // Debug print
      final response = await ActivityFeedService().getAllAchievements();
      if (response.statusCode == 200) {
        if(mounted) { // Check if mounted
          setState(() {
            _allAchievements = response.data is List
                ? response.data
                : (response.data?['results'] ?? []);
             print('All achievements fetched: ${_allAchievements.length} items'); // Debug print
          });
        }
      } else {
        print('Failed to load all achievements: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching all achievements: $e');
    }
  }

  Future<void> _fetchUserRaceAttempts([int? userId]) async {
    try {
      print('Fetching user race attempts...'); // Debug print
      final response = await _authService.getUserRaceAttempts(userId: userId); // Pass userId
      if (response.statusCode == 200) {
        if (mounted) {
          setState(() {
            List<dynamic> rawRaceAttemptsData = [];
            if (response.data is Map && response.data.containsKey('results')) {
              rawRaceAttemptsData = response.data['results'] as List;
            } else if (response.data is List) {
              rawRaceAttemptsData = response.data as List;
            } else {
              print('Warning: Unexpected format for race attempt API response. Data: ${response.data}');
              rawRaceAttemptsData = [];
            }
            _raceAttemptsCount = rawRaceAttemptsData.length; // Получаем количество гонок
            print('User race attempts fetched: $_raceAttemptsCount items'); // Debug print
          });
        }
      } else {
        print('Failed to load user race attempts: ${response.statusCode}');
        // Handle error
      }
    } catch (e) {
      print('Error fetching user race attempts: $e');
      // Handle error
    }
  }

  // Helper function to format duration
  String _formatDuration(int seconds) {
    if (seconds == 0 || seconds < 0) return 'N/A';
    final int minutes = (seconds / 60).floor();
    final int remainingSeconds = seconds % 60;
    return '$minutesм $remainingSecondsс';
  }

  // Helper function to format distance
  String _formatDistance(double meters) {
     if (meters == 0 || meters < 0) return 'N/A';
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} м';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} км';
    }
  }

  Widget _buildStatCard(String title, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16.0),
        margin: const EdgeInsets.all(8.0), // Отступы между карточками
        height: 100.0, // Установлена фиксированная высота для единообразия блоков
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFACACAC), width: 1.0), // Обводка из Figma
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Выравнивание текста по началу
          mainAxisAlignment: MainAxisAlignment.center, // Выравнивание содержимого по центру вертикально
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 11, // Уменьшено в 1.5 раза (было 14)
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 8.0),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14, // Уменьшено в 1.5 раза (было 28)
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Ensure _profileData is not null before accessing its keys
    final String username = _profileData?['username'] ?? 'Имя пользователя (N/A)';
    final String email = _profileData?['email'] ?? 'Email (N/A)';
    final String level = _profileData?['level']?.toString() ?? 'N/A'; // Convert number to string
    final String xp = _profileData?['experience_points']?.toString() ?? 'N/A'; // Convert number to string
    final String bio = _profileData?['bio'] ?? '';
    final String dateOfBirth = _profileData?['date_of_birth'] ?? '';
    final String? avatarUrl = _profileData?['avatar'];
    final int completedRacesCount = (_profileData?['statistics']?['completed_challenges_count'] as num?)?.toInt() ?? 0;

    // Debug print before navigating to AchievementsScreen
     print('Navigating to AchievementsScreen with  ${_allAchievements.length} all achievements and  ${_achievements.length} user achievements');

    final int achievementsCount = _achievements.where((a) => a is Map && a['achievement_name'] != null).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Профиль',
          style: TextStyle(
            fontSize: 22, // Увеличенный размер шрифта для заголовка
            fontWeight: FontWeight.bold,
            color: Colors.black, // Или другой контрастный цвет
          ),
        ),
        centerTitle: true, // Выравнивание заголовка по центру
        backgroundColor: const Color(0xFFFFFFFF), // Светлый фон AppBar
        elevation: 0, // Убрать тень AppBar
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFC0FF00)), // Акцентный цвет для индикатора загрузки
            )
          : SingleChildScrollView( // Use SingleChildScrollView for potential overflow
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  // User Info Section
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24.0),
                    margin: const EdgeInsets.only(bottom: 24.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFACACAC), width: 1.0), // Добавлена обводка                      
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      children: <Widget>[
                        // Аватар и уровень
                        Stack(
                          alignment: Alignment.bottomRight,
                          children: [
                            CircleAvatar(
                              radius: 60,
                              backgroundColor: const Color(0xFFE0E0E0),
                      backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                          ? NetworkImage(avatarUrl) as ImageProvider
                          : null,
                      child: avatarUrl == null || avatarUrl.isEmpty
                                  ? const Icon(Icons.person, size: 60, color: Colors.white)
                          : null,
                    ),
                            if (level != 'N/A' && int.tryParse(level) != null)
                              Positioned(
                                right: 0,
                                bottom: 0,
                        child: Container(
                                  width: 30,
                                  height: 30,
                          decoration: BoxDecoration(
                                    color: const Color(0xFFC0FF00),
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.white, width: 2),
                          ),
                                  child: Center(
                                    child: Text(
                                level,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                          ),
                        ),
                      ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        // Надпись "ИМЯ"
                        const Text(
                          'ИМЯ',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4.0),
                        // Имя пользователя
                        Text(
                          username.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        const SizedBox(height: 16.0),
                        // Полоса прогресса XP
                        SizedBox(
                          width: double.infinity,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Builder(
                              builder: (context) {
                                final int? currentLevel = int.tryParse(level);
                                final int? currentXP = int.tryParse(xp);
                                if (currentLevel == null || currentXP == null || currentLevel <= 0) {
                                  return LinearProgressIndicator(
                                    value: 0.0,
                                    backgroundColor: Colors.grey[200],
                                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFC0FF00)),
                                    minHeight: 15,
                                  );
                                }
                                final int xpForCurrentLevelStart = (currentLevel - 1) * 1000;
                                final int xpProgressInCurrentLevel = currentXP - xpForCurrentLevelStart;
                                const int xpNeededForNextLevel = 1000;
                                final double progress = (xpProgressInCurrentLevel / xpNeededForNextLevel).clamp(0.0, 1.0);
                                return LinearProgressIndicator(
                                  value: progress,
                                  backgroundColor: Colors.grey[200],
                                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFC0FF00)),
                                  minHeight: 15,
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 8.0),
                        // Текст XP
                        Builder(
                          builder: (context) {
                            final int? currentLevel = int.tryParse(level);
                            final int? currentXP = int.tryParse(xp);
                            if (currentLevel == null || currentXP == null || currentLevel <= 0) {
                              return const Text(
                                'XP: N/A',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              );
                            }
                            final int xpForCurrentLevelStart = (currentLevel - 1) * 1000;
                            final int xpProgressInCurrentLevel = currentXP - xpForCurrentLevelStart;
                            const int xpNeededForNextLevel = 1000;
                            return Text(
                              'XP: $xpProgressInCurrentLevel / $xpNeededForNextLevel',
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black,
                                fontWeight: FontWeight.w500,
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                   const SizedBox(height: 24.0),

                  // Edit Profile Button
                  _buildActionButton(
                    context,
                    'РЕДАКТИРОВАТЬ ПРОФИЛЬ',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const EditProfileScreen(),
                        ),
                      ).then((_) {
                         if (mounted) {
                            _fetchInitialData();
                         }
                       });
                    },
                  ),
                  const SizedBox(height: 24.0),

                  // Metrics Section
                  Column(
                    children: [
                      Row(
                        children: [
                          _buildStatCard(
                            'ВСЕГО ПРОЙДЕНО',
                            _formatDistance(((_profileData?['statistics']?['total_distance_km'] as num?)?.toDouble() ?? 0.0) * 1000),
                          ),
                          _buildStatCard(
                            'ТРЕНИРОВОК',
                            (_profileData?['statistics']?['total_runs']?.toString() ?? 'N/A'),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          _buildStatCard(
                            'ОБЩЕЕ ВРЕМЯ',
                            (() {
                              final double? totalHours = (_profileData?['statistics']?['total_duration_hours'] as num?)?.toDouble();
                              if (totalHours == null || totalHours.isNaN) return 'N/A';
                              final int hours = totalHours.floor();
                              final int minutes = ((totalHours - hours) * 60).round();
                              if (hours > 0 && minutes > 0) return '${hours}ч ${minutes}м';
                              if (hours > 0) return '${hours}ч';
                              if (minutes > 0) return '${minutes}м';
                              return '0м';
                            })(),
                          ),
                          _buildStatCard(
                            'ГОНОК', // Изменено с 'Выполнено челленджей'
                            _raceAttemptsCount.toString(),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24.0),

                  // Grid of action buttons
                  Column(
                    children: [
                      Row(
                        children: [
                          _buildGridActionButton(
                            context,
                            Icons.emoji_events, // Иконка для достижений
                            'достижения',
                            () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => AchievementsScreen(
                                    allAchievements: _allAchievements,
                                    userAchievements: _achievements,
                                  ),
                                ),
                              ).then((_) {
                                _fetchInitialData();
                              });
                            },
                          ),
                          _buildGridActionButton(
                    context,
                            Icons.palette, // Иконка для темы
                            'тема',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ColorSchemeScreen(),
                        ),
                      );
                    },
                  ),
                        ],
                      ),
                      Row(
                        children: [
                          _buildGridActionButton(
                            context,
                            Icons.settings, // Иконка для настроек
                            'настройки',
                            () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const SettingsScreen(),
                                ),
                              );
                            },
                          ),
                          _buildGridActionButton(
                    context,
                            Icons.bar_chart, // Иконка для статистики
                            'статистика',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => StatisticsScreen(profileData: _profileData),
                        ),
                      );
                    },
                  ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24.0),
                  // Logout Button
                  _buildActionButton(
                    context,
                    'ВЫЙТИ',
                    () async {
                      await AuthService().logout();
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (context) => const LoginScreen()),
                        (Route<dynamic> route) => false,
                      );
                    },
                    isAccent: false, // Not accent, but will be red
                  ),
                ],
              ),
            ),
      ),
    );
  }

  Widget _buildActionButton(BuildContext context, String text, VoidCallback onPressed, {bool isAccent = false}) {
    return Container(
      margin: const EdgeInsets.all(4.0), // Изменены отступы, чтобы соответствовать кнопкам сетки
      width: double.infinity, // Растягиваем кнопку на всю ширину контейнера
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 20), // Скорректирован горизонтальный паддинг
          textStyle: const TextStyle(
            fontSize: 9, // Уменьшен шрифт, чтобы соответствовать кнопкам сетки
            fontWeight: FontWeight.w500, // Изменен вес шрифта
            fontFamily: 'Satoshi', // Установка шрифта Satoshi. Убедитесь, что он добавлен в pubspec.yaml
          ),
          backgroundColor: text == 'ВЫЙТИ' ? const Color.fromARGB(255, 255, 0, 0) : Colors.white, // Белый фон для обычных кнопок, красный для "Выйти"
          foregroundColor: Colors.black, // Черный цвет текста
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20), // Скругленные углы
            side: text == 'ВЫЙТИ' ? BorderSide.none : const BorderSide(color: Color(0xFFACACAC), width: 1.0), // Обводка только для обычных кнопок
          ),
          elevation: 5,
          shadowColor: Colors.black.withOpacity(0.05), // Тень
        ),
        child: Text(text.toUpperCase()), // Текст в верхнем регистре
      ),
    );
  }

  Widget _buildGridActionButton(BuildContext context, IconData icon, String text, VoidCallback onPressed) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.all(4.0), // Уменьшены отступы для растяжения кнопок
        child: ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white, // Белый фон
            foregroundColor: Colors.black, // Черный текст (останется черным, иконка будет серой)
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20), // Скругленные углы как у карточек
              side: const BorderSide(color: Color(0xFFACACAC), width: 1.0), // Обводка
            ),
            elevation: 5, // Тень
            shadowColor: Colors.black.withOpacity(0.05),
            padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0), // Сохраняем горизонтальный паддинг
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start, // Выравнивание содержимого по левому краю
            children: [
              Icon(icon, size: 20, color: const Color(0xFFC0FF00)), // Уменьшенный размер иконки
              const SizedBox(width: 8), // Отступ между иконкой и текстом
              Expanded(
      child: Text(
                  text.toUpperCase(), // Переводим текст в верхний регистр
        style: const TextStyle(
                    fontSize: 9, // Ещё уменьшенный размер шрифта для гарантии одной строки
                    fontWeight: FontWeight.w500,
                    color: Colors.black, // Убедимся, что текст черный
                  ),
                  textAlign: TextAlign.start, // Выравнивание текста внутри Expanded
                  maxLines: 1, // Убеждаемся, что текст в одну строку
                  overflow: TextOverflow.ellipsis, // Изменяем overflow на ellipsis
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Add extension methods for date/time formatting if they don't exist
extension on DateTime {

}