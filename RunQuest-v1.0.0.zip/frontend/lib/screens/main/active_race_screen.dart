import 'package:flutter/material.dart';
// TODO: Add necessary imports for map and location tracking
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async'; // Import for Timer and StreamSubscription
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:frontend/screens/main/race_results_screen.dart'; // Import RaceResultsScreen

class ActiveRaceScreen extends StatefulWidget {
  final Map<String, dynamic> trackData; // Pass the full track data

  const ActiveRaceScreen({super.key, required this.trackData});

  @override
  State<ActiveRaceScreen> createState() => _ActiveRaceScreenState();
}

class _ActiveRaceScreenState extends State<ActiveRaceScreen> {
  // TODO: Add state variables for race data (time, distance, etc.)
  Position? _currentUserPosition; // User's current location
  final List<LatLng> _routePoints = []; // List of points the user has traveled
    double _distanceCoveredMeters = 0.0; // Исправлено: Накопление расстояния в МЕТРАх
  String _raceTime = '00:00:00'; // Placeholder
  String _currentPace = '0:00'; // Placeholder
    double _distanceLeftKm = 0.0; // Исправлено: Осталось расстояния в КМ для отображения

  Timer? _timer; // Timer for race duration
  int _secondsElapsed = 0; // Race duration in seconds
  StreamSubscription<Position>? _positionStreamSubscription; // Subscription for location updates

  final MapController _mapController = MapController(); // Map controller for the race map

  Map<String, dynamic>? _raceTrackDetails; // State variable to store track details
  List<LatLng> _trackRouteCoordinates = []; // Coordinates of the full track route

  String _recordComparison = ''; // State variable for comparison with track record

  bool _showStartLocationError = false; // State variable to show/hide start location error

  // Добавим переменные для статуса геолокации
  String _locationStatus = 'Ожидание...';
  bool _locationError = false;

  @override
  void initState() {
    super.initState();
    // TODO: Initialize race state and start tracking
    print('ActiveRaceScreen initialized for track ID: ${widget.trackData['id']}'); // Use trackData ID for logging
    // Track details are already available via widget.trackData
    _raceTrackDetails = widget.trackData; // Assign the passed track data

    // Extract track route coordinates
    if (_raceTrackDetails?['route_definition'] != null && _raceTrackDetails!['route_definition']['coordinates'] != null) {
      _trackRouteCoordinates = _raceTrackDetails!['route_definition']['coordinates'].map<LatLng>((coord) {
        return LatLng(coord[1], coord[0]); // Convert [lon, lat, ...] to LatLng(lat, lon)
      }).toList();
    }

    _startLocationUpdates(); // Start listening to location updates immediately
    // _startRace(); // The actual race start logic will now be triggered by location check
  }

  @override
  void dispose() {
    // TODO: Stop location tracking and dispose resources
    _timer?.cancel(); // Cancel the timer
    _positionStreamSubscription?.cancel(); // Cancel the position stream subscription
    _mapController.dispose();
    super.dispose();
  }

  // Method to start the race (logic that runs ONCE when at start point)
  void _startRaceLogic() async {

    // Get track record time
    final int? recordTimeSeconds = _raceTrackDetails?['record_time_seconds'];

    // Start the timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _secondsElapsed++;
        _raceTime = _formatTime(_secondsElapsed);
        _calculateCurrentPace();

        // Calculate and update comparison with record
        if (recordTimeSeconds != null) {
          final int timeDifference = _secondsElapsed - recordTimeSeconds;
          if (timeDifference > 0) {
            _recordComparison = '+${_formatTimeDifference(timeDifference)}';
          } else if (timeDifference < 0) {
            _recordComparison = _formatTimeDifference(timeDifference);
          } else {
            _recordComparison = '0:00';
          }
        }
      });
    });

    // From now on, location updates will accumulate distance and check for finish
  }

  // Method to start listening to location updates immediately
  void _startLocationUpdates() async {
     LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          _locationStatus = 'Нет разрешения на геолокацию';
          _locationError = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Нет разрешения на геолокацию')),
        );
        print('Location permissions are denied');
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() {
        _locationStatus = 'Геолокация навсегда запрещена';
        _locationError = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Геолокация навсегда запрещена')),
      );
       print('Location permissions is permanently denied');
      return;
    }

    setState(() {
      _locationStatus = 'Геолокация активна';
      _locationError = false;
    });

    _positionStreamSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 0,
      ),
    ).listen((Position position) {
      print('Received location update: \u001b[32m[32m${position.latitude}, ${position.longitude}\u001b[0m');
      setState(() {
        _currentUserPosition = position;

        // Check if race has started (timer is active)
        if (_timer != null && _timer!.isActive) {
          // Race is in progress, record route and calculate distance
          _routePoints.add(LatLng(position.latitude, position.longitude));
          if (_routePoints.length > 1) {
            final double distanceBetweenPoints = const Distance().as(LengthUnit.Meter, _routePoints[_routePoints.length - 2], _routePoints.last);
            _distanceCoveredMeters += distanceBetweenPoints; // Накапливаем в метрах
            print('Distance added: $distanceBetweenPoints meters. Total covered: $_distanceCoveredMeters meters'); // Debug print
            // Calculate remaining distance (convert total covered to km for subtraction)
            _distanceLeftKm = ((_raceTrackDetails?['length_meters'] ?? 0) - _distanceCoveredMeters) / 1000.0; // Расчет оставшегося расстояния в КМ
            if (_distanceLeftKm < 0) _distanceLeftKm = 0; // Ensure distance left is not negative
             print('Distance left: $_distanceLeftKm km'); // Debug print
          }

          // Check for race finish (within 2 meters of finish point)
          if (_raceTrackDetails != null && _raceTrackDetails!['route_definition'] != null && _raceTrackDetails!['route_definition']['coordinates'] != null && _raceTrackDetails!['route_definition']['coordinates'].isNotEmpty) {
            final finishPointCoords = _raceTrackDetails!['route_definition']['coordinates'].last;
            final finishPoint = LatLng(finishPointCoords[1], finishPointCoords[0]);
            final double distanceToFinish = const Distance()(LatLng(position.latitude, position.longitude), finishPoint); // Distance in meters
            if (distanceToFinish <= 2.0) {
              print('User reached the finish line! Distance to finish: $distanceToFinish meters.');
              _finishRace();
            }
          }

        } else {
          // Race not yet started, check if user is at start point
          if (_raceTrackDetails != null && _raceTrackDetails!['route_definition'] != null && _raceTrackDetails!['route_definition']['coordinates'] != null && _raceTrackDetails!['route_definition']['coordinates'].isNotEmpty) {
             final startPointCoords = _raceTrackDetails!['route_definition']['coordinates'][0];
             final startPoint = LatLng(startPointCoords[1], startPointCoords[0]);
             final double distanceToStart = const Distance()(LatLng(position.latitude, position.longitude), startPoint);

             if (distanceToStart <= 2.0) {
                print('User is at the start point! Distance: $distanceToStart meters. Starting race logic.');
                setState(() {
                  _showStartLocationError = false; // Hide error if previously shown
                });
                _startRaceLogic(); // Start the actual race logic
             } else {
                // User is not at start point, show error if not already shown
                 if (!_showStartLocationError) {
                    setState(() {
                      _showStartLocationError = true;
                      print('User is not at the start point. Distance: $distanceToStart meters. Showing error.'); // Debug print
                    });
                 }
             }
          }
        }

        // Always center map on user's current location
        _mapController.move(LatLng(position.latitude, position.longitude), _mapController.zoom);
      });
    }, onError: (e) {
      setState(() {
        _locationStatus = 'Ошибка получения геолокации';
        _locationError = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка геолокации: $e')),
      );
      print('Ошибка геолокации: $e');
    });
  }

  // Method to format time from seconds into HH:MM:SS
  String _formatTime(int seconds) {
    final hours = (seconds ~/ 3600).toString().padLeft(2, '0');
    final minutes = ((seconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final remainingSeconds = (seconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$remainingSeconds';
  }

  // Method to calculate current pace (minutes per kilometer)
  void _calculateCurrentPace() {
    if (_distanceCoveredMeters > 0 && _secondsElapsed > 0) { // Используем метры для расчета
      final double kilometers = _distanceCoveredMeters / 1000.0; // Переводим в километры
       final double hours = _secondsElapsed / 3600.0;
       final double pace = hours / kilometers * 60; // Pace in minutes per kilometer
       final int paceMinutes = pace.floor();
       final int paceSeconds = ((pace - paceMinutes) * 60).round();
        _currentPace = '$paceMinutes:${paceSeconds.toString().padLeft(2, '0')}';
     } else {
       _currentPace = '0:00'; // Default pace
     }
  }

  // Method to format time difference (remove hours if zero, handle negative)
  String _formatTimeDifference(int seconds) {
    final bool isNegative = seconds < 0;
    final int absSeconds = seconds.abs();

    final hours = (absSeconds ~/ 3600);
    final minutes = ((absSeconds % 3600) ~/ 60);
    final remainingSeconds = (absSeconds % 60);

    String formattedTime = '';
    if (hours > 0) {
       formattedTime += '$hoursч ';
    }
    formattedTime += '${minutes.toString().padLeft(1, '0')}мин ';
    formattedTime += '${remainingSeconds.toString().padLeft(2, '0')}сек';

    return isNegative ? '-$formattedTime' : formattedTime;
  }

  // Method to abort the race
  void _abortRace() {
    _timer?.cancel(); // Cancel the timer
    _positionStreamSubscription?.cancel(); // Cancel location tracking
    // TODO: Add any other necessary cleanup or data saving logic here
    Navigator.pop(context); // Navigate back to the previous screen
  }

  // Method to finish the race and send results
  void _finishRace() async {
    print('Race finished! Track ID: ${widget.trackData['id']}, Duration: $_secondsElapsed seconds, Distance: ${_distanceCoveredMeters / 1000.0} km');
    _timer?.cancel(); // Stop the timer
    _positionStreamSubscription?.cancel(); // Stop location updates

    // TODO: Send race results to backend
    final int trackId = widget.trackData['id']; // Get track ID from widget data
    final int durationSeconds = _secondsElapsed;
    final double distanceCoveredKm = _distanceCoveredMeters / 1000.0; // Distance in KM
    final List<LatLng> recordedRoute = List.from(_routePoints); // Get the recorded route points

    print('Sending race results to backend:'); // Debug print
    print('  Track ID: $trackId');
    print('  Duration (seconds): $durationSeconds');
    print('  Distance (km): $distanceCoveredKm');
    print('  Recorded Route Points Count: ${recordedRoute.length}');

    // Call the AuthService method to send results and get the response data
    final raceAttemptData = await AuthService().sendRaceResults(
        trackId,
        durationSeconds,
        distanceCoveredKm,
        recordedRoute,
      );

    if (raceAttemptData != null) {
        print('Race results sent successfully!');
        print('Full raceAttemptData: $raceAttemptData'); // Debug the response

      final int createdAttemptId = raceAttemptData['attemptId'] as int;

      // --- Новый блок: Получаем свежие детали попытки гонки ---
      Map<String, dynamic>? attemptDetails;
      if (createdAttemptId != null) {
        attemptDetails = await AuthService().fetchRaceAttemptDetails(createdAttemptId);
      }
      // После получения деталей обновим профиль пользователя
      await AuthService().refreshCurrentUser();

      // --- Извлекаем данные для экрана результата ---
      int? xpEarned;
      List<dynamic>? achievementsEarned;
      List<dynamic>? challengesCompleted;
      bool? isRecordBroken;
      if (attemptDetails != null) {
        xpEarned = attemptDetails['xp_earned'] as int?;
        achievementsEarned = attemptDetails['earned_achievements'] as List<dynamic>?;
        challengesCompleted = attemptDetails['completed_challenges'] as List<dynamic>?;
        isRecordBroken = (attemptDetails['is_record_broken'] ?? attemptDetails['isRecordBroken']) as bool?;
      } else {
        xpEarned = raceAttemptData['xpEarned'] as int?;
        achievementsEarned = raceAttemptData['achievementsEarned'] as List<dynamic>?;
        challengesCompleted = raceAttemptData['challengesCompleted'] as List<dynamic>?;
        isRecordBroken = (raceAttemptData['is_record_broken'] ?? raceAttemptData['isRecordBroken']) as bool?;
      }

      // Navigate to RaceResultsScreen with the relevant data, including the attempt ID
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => RaceResultsScreen(
              trackName: widget.trackData['name'],
              durationSeconds: durationSeconds,
              distanceCoveredKm: distanceCoveredKm,
              recordedRoute: recordedRoute,
              trackId: trackId,
              attemptId: createdAttemptId,
              xpEarned: xpEarned,
              achievementsEarned: achievementsEarned,
              challengesCompleted: challengesCompleted,
              isRecordBroken: isRecordBroken,
              currentUser: AuthService().currentUser,
            ),
          ),
        );
      }

      } else {
      print('Failed to send race results.');
      // TODO: Show error message to user and decide on navigation
      // For now, maybe navigate back or show an error dialog
      if (mounted) { // Check if the widget is still mounted
         ScaffoldMessenger.of(context).showSnackBar(
           const SnackBar(content: Text('Не удалось сохранить результаты гонки.')),
         );
         Navigator.pop(context); // Navigate back to the map screen on failure
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Активная гонка'),
        // TODO: Add actions like pause/stop button
      ),
      body: Stack(
        children: [
          // Map Layer
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: LatLng(_raceTrackDetails?['route_definition']?['coordinates']?[0][1] ?? 56.012027, _raceTrackDetails?['route_definition']?['coordinates']?[0][0] ?? 92.867245), // Center on track start or placeholder
              initialZoom: 14.0, // Placeholder zoom
              // TODO: Configure map options for active race (disable interaction?)
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.runquest.app', // Replace with your package name
              ),
              // User location marker
              if (_currentUserPosition != null)
                MarkerLayer(
                  markers: [
                    Marker(
                      width: 80.0,
                      height: 80.0,
                      point: LatLng(_currentUserPosition!.latitude, _currentUserPosition!.longitude),
                      child: const Icon(
                        Icons.my_location,
                        color: Colors.blueAccent,
                        size: 40.0,
                      ),
                    ),
                  ],
                ),
              // Track route polyline
              if (_trackRouteCoordinates.isNotEmpty)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _trackRouteCoordinates,
                      strokeWidth: 4.0,
                      color: Colors.red, // Color for the track route
                    ),
                  ],
                ),

              // Add Finish line marker
              if (_raceTrackDetails != null && _raceTrackDetails!['route_definition'] != null && _raceTrackDetails!['route_definition']['coordinates'] != null && _raceTrackDetails!['route_definition']['coordinates'].isNotEmpty)
                MarkerLayer(
                  markers: [
                    Marker(
                      width: 50.0, // Adjust size as needed
                      height: 50.0, // Adjust size as needed
                      point: LatLng(_raceTrackDetails!['route_definition']['coordinates'].last[1], _raceTrackDetails!['route_definition']['coordinates'].last[0]), // Use finish point coordinates
                      child: Image.asset('static/screens/active race/finish.png'), // Use the finish icon asset
                    ),
                  ],
                ),

            ],
          ),

          // Top Info Panel
          Positioned(
            top: 10.0,
            left: 10.0,
            right: 10.0,
            child: Card(
              elevation: 4.0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('ГОНКА:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                        Text(_raceTrackDetails?['name'] ?? 'Загрузка...', style: const TextStyle(fontSize: 16)), // Display track name
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('${_distanceLeftKm.toStringAsFixed(1)} КМ', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), // Исправлено: Отображаем оставшееся расстояние в КМ
                        const Text('ОСТАЛОСЬ', style: TextStyle(fontSize: 12)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Zoom Controls (similar to map screen)
           Positioned(
             bottom: 350.0, // Move controls higher
             right: 20.0,
             child: Column(
               children: [
                 FloatingActionButton(
                   mini: true,
                   onPressed: () {
                     _mapController.move(_mapController.center, _mapController.zoom + 1);
                   },
                   heroTag: 'zoomInBtn', // Unique tag
                   child: const Icon(Icons.add),
                 ),
                 const SizedBox(height: 10),
                 FloatingActionButton(
                   mini: true,
                   onPressed: () {
                     _mapController.move(_mapController.center, _mapController.zoom - 1);
                   },
                   heroTag: 'zoomOutBtn', // Unique tag
                   child: const Icon(Icons.remove),
                 ),
                 // Button to center map on user
                 const SizedBox(height: 10), // Add spacing
                 // Button to center map on user
                 FloatingActionButton(
                   mini: true,
                   onPressed: () {
                     if (_currentUserPosition != null) {
                       _mapController.move(LatLng(_currentUserPosition!.latitude, _currentUserPosition!.longitude), _mapController.zoom);
                     }
                   },
                   heroTag: 'activeRaceGoToUserLocationBtn', // Unique tag
                   child: const Icon(Icons.my_location), // Use my_location icon
                 ),
               ],
             ),
           ),

          // Bottom Stats Panel and Abort Button
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Card(
              elevation: 8.0,
               shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0))),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.only(bottom: 24.0), // Add bottom padding
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Race Time
                      Text(
                        _raceTime, // Display real-time race time
                        style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
                      ),
                      const Text('ВРЕМЯ ГОНКИ', style: TextStyle(fontSize: 12)),
                      const SizedBox(height: 20),

                      // Distance and Pace Row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded( // Wrap in Expanded
                            child: Column(
                              children: [
                                Text(
                                  '${(_distanceCoveredMeters / 1000.0).toStringAsFixed(2)} КМ', // Исправлено: Отображаем в КМ
                                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), // Reduced font size
                                ),
                                const Text('ПРОЙДЕНО', style: TextStyle(fontSize: 12)),
                              ],
                            ),
                          ),
                          Expanded( // Wrap in Expanded
                            child: Column(
                              children: [
                                Text(
                                  _currentPace, // Display real-time pace
                                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold), // Reduced font size
                                ),
                                const Text('ТЕКУЩИЙ ТЕМП', style: TextStyle(fontSize: 12)),
                              ],
                            ),
                          ),
                          // TODO: Add comparison to track record here
                          // Comparison to track record
                          if (_raceTrackDetails?['record_time_seconds'] != null) // Only show if record exists
                            Expanded( // Wrap in Expanded
                              child: Column(
                                children: [
                                  Text(
                                    _recordComparison, // Display comparison
                                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _recordComparison.startsWith('-') ? Colors.green : Colors.red), // Reduced font size
                                  ),
                                  const Text('С РЕКОРДОМ', style: TextStyle(fontSize: 12)),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Abort Button
                      ElevatedButton(
                        onPressed: () async {
                           print('Abort Race button pressed'); // Debug print
                           // Show confirmation dialog
                           bool confirmAbort = await showDialog(
                             context: context,
                             builder: (BuildContext context) {
                               return AlertDialog(
                                 title: const Text('Прервать гонку?'),
                                 content: const Text('Вы уверены, что хотите прервать текущую гонку?'),
                                 actions: <Widget>[
                                   TextButton(
                                     child: const Text('Отмена'),
                                     onPressed: () {
                                       Navigator.of(context).pop(false); // Return false on cancel
                                     },
                                   ),
                                   TextButton(
                                     child: const Text('Да'),
                                     onPressed: () {
                                       Navigator.of(context).pop(true); // Return true on confirm
                                     },
                                   ),
                                 ],
                               );
                             },
                           ) ?? false; // Default to false if dialog is dismissed

                           if (confirmAbort) {
                             _abortRace(); // Abort the race if confirmed
                           }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red, // Red color for abort button
                          minimumSize: const Size(double.infinity, 50), // Full width button
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        child: const Text('ПРЕРВАТЬ ГОНКУ', style: TextStyle(fontSize: 18)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Start Location Error Message
          if (_showStartLocationError)
            Positioned.fill(
              child: Container(
                color: Colors.black54, // Semi-transparent background
                child: Center(
                  child: Card(
                    margin: const EdgeInsets.all(24.0),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            'Подойдите к точке старта, чтобы начать гонку.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 16.0),
                          ElevatedButton(
                            onPressed: () {
                              _startLocationUpdates(); // Retry starting the race
                            },
                            child: const Text('Повторить'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

          // Индикатор статуса геолокации
          Positioned(
            bottom: 70.0,
            left: 10.0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _locationError ? Colors.redAccent : Colors.green,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _locationStatus,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ),
            ),
        ],
      ),
    );
  }
}