import 'package:flutter/material.dart';
import 'package:frontend/screens/main/terms_of_use_screen.dart'; // Import TermsOfUseScreen
import 'package:frontend/screens/main/privacy_policy_screen.dart'; // Import PrivacyPolicyScreen

// Constants for colors
const Color _kAccentColor = Color.fromARGB(255, 0, 126, 243); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон

class AboutAppScreen extends StatelessWidget {
  const AboutAppScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'О ПРИЛОЖЕНИИ',
          style: TextStyle(
            fontFamily: 'Satoshi',
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, // Center content horizontally
          children: [
            const SizedBox(height: 50), // Spacing from app bar
            Image.asset(
              'static/RunQuest logo.png',
              height: 100,
            ),
            const SizedBox(height: 10),
            Image.asset(
              'static/RunQuest_logo_sign.png',
              height: 20,
            ),
            const SizedBox(height: 20),
            const Text(
              'Версия: 1.0.0',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                'RunQuest - это мобильное приложение для бега с элементами геймификации, которое делает пробежки более увлекательными и мотивирующими. Отслеживайте свои пробежки, участвуйте в гонках, соревнуйтесь с друзьями и достигайте новых спортивных вершин!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[700],
                ),
              ),
            ),
            const SizedBox(height: 100), // More spacing before copyright
            const Text(
              '© 2025 RunQuest. Все права защищены.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: _buildLinkText(
                    'Пользовательское \n соглашение',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const TermsOfUseScreen()),
                      );
                    },
                    textAlign: TextAlign.left,
                  ),
                ),
                Expanded(
                  child: _buildLinkText(
                    'Политика \n конфиденциальности',
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const PrivacyPolicyScreen()),
                      );
                    },
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildLinkText(String text, VoidCallback onTap, {TextAlign? textAlign}) {
    return InkWell(
      onTap: onTap,
      child: Text(
        text,
        textAlign: textAlign,
        style: TextStyle(
          fontFamily: 'Roboto',
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: _kAccentColor, // Green color for links
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }
}
