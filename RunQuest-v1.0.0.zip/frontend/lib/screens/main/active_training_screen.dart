import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart'; // Import geolocator
import 'package:latlong2/latlong.dart'; // Import latlong2 for LatLng
import 'dart:async'; // Import for Timer and StreamSubscription
import 'package:flutter_map/flutter_map.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:frontend/screens/main/training_results_screen.dart'; // Import TrainingResultsScreen
import 'package:frontend/models/user.dart'; // Import User model


class ActiveTrainingScreen extends StatefulWidget {
  const ActiveTrainingScreen({super.key});

  @override
  State<ActiveTrainingScreen> createState() => _ActiveTrainingScreenState();
}

class _ActiveTrainingScreenState extends State<ActiveTrainingScreen> {
  Position? _currentUserPosition; // User's current location
  final List<LatLng> _routePoints = []; // List of points the user has traveled
  double _distanceCoveredMeters = 0.0; // Accumulated distance in meters
  String _trainingTime = '00:00:00'; // Training duration formatted
  String _currentPace = '0:00'; // Current pace formatted

  Timer? _timer; // Timer for training duration
  int _secondsElapsed = 0; // Training duration in seconds
  StreamSubscription<Position>? _positionStreamSubscription; // Subscription for location updates

  // State variable for training status (not started, active, paused, finished)
  TrainingStatus _trainingStatus = TrainingStatus.notStarted;

  final MapController _mapController = MapController(); // Add MapController
  bool _isMapReady = false; // Add a flag to check if the map is ready

  @override
  void initState() {
    super.initState();
    _startLocationUpdates(); // Start listening to location updates
    // Initialize map center to a default location or user's initial location if available
    // _mapController.move(const LatLng(56.012027, 92.867245), 14.0); // Remove this line as centering will be handled after map is ready
  }

  @override
  void dispose() {
    _timer?.cancel(); // Cancel the timer
    _positionStreamSubscription?.cancel(); // Cancel the position stream subscription
    _mapController.dispose(); // Dispose the MapController
    super.dispose();
  }

  // Method to start listening to location updates
  void _startLocationUpdates() async {
     LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // TODO: Handle denied permission
        print('Location permissions are denied');
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // TODO: Handle permanently denied permission
       print('Location permissions is permanently denied');
      return;
    }

    _positionStreamSubscription = Geolocator.getPositionStream( // Use getPositionStream for continuous updates
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high, // High accuracy for better route tracking
        distanceFilter: 0, // Receive updates even for small movements
      ),
    ).listen((Position position) {
      print('Received location update: ${position.latitude}, ${position.longitude}');
      setState(() {
        _currentUserPosition = position;

        // Always center map on user's current location ONLY if map is ready
        if (_isMapReady) { // Check if the map is ready before moving
          _mapController.move(LatLng(position.latitude, position.longitude), _mapController.zoom); // Center map on user
        }

        // Only update stats if training is active
        if (_trainingStatus == TrainingStatus.active) {
           final newPoint = LatLng(position.latitude, position.longitude);
           if (_routePoints.isNotEmpty) {
             final double distanceBetweenPoints = const Distance().as(LengthUnit.Meter, _routePoints.last, newPoint);
             _distanceCoveredMeters += distanceBetweenPoints; // Accumulate distance
             _calculateCurrentPace(); // Update pace
           }
           _routePoints.add(newPoint); // Add new point to route
        }
      });
    }, onError: (e) {
      // TODO: Handle location update errors
      print('Location update error: $e');
    });
  }

  // Method to start the training timer
  void _startTimer() {
     _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _secondsElapsed++;
        _trainingTime = _formatTime(_secondsElapsed); // Update formatted time
        _calculateCurrentPace(); // Update pace based on new time/distance
      });
    });
  }

   // Method to pause the timer and location updates
  void _pauseTraining() {
    _timer?.cancel(); // Pause the timer
    _positionStreamSubscription?.pause(); // Pause location updates
    setState(() {
      _trainingStatus = TrainingStatus.paused; // Update status
    });
    print('Training paused.'); // Debug print
  }

  // Method to resume the timer and location updates
  void _resumeTraining() {
    _startTimer(); // Resume the timer
    _positionStreamSubscription?.resume(); // Resume location updates
     setState(() {
      _trainingStatus = TrainingStatus.active; // Update status
    });
    print('Training resumed.'); // Debug print
  }

  // Method to stop the timer and location updates and finish training
  void _finishTraining() async { // Made method async to await service call
    print('Training finished! Duration: $_secondsElapsed seconds, Distance: $_distanceCoveredMeters meters'); // Use meters for accuracy in print
    _timer?.cancel(); // Stop the timer
    _positionStreamSubscription?.cancel(); // Stop location updates
     setState(() {
      _trainingStatus = TrainingStatus.finished; // Update status
    });

    // Collect final data
    final int durationSeconds = _secondsElapsed;
    final double distanceCoveredMeters = _distanceCoveredMeters; // Use meters
    final List<LatLng> recordedRoute = List.from(_routePoints); // Get the recorded route points

    // Send results to backend
    print('Sending training results to backend:'); // Debug print
    print('  Duration (seconds): $durationSeconds');
    print('  Distance (meters): $distanceCoveredMeters');
    print('  Recorded Route Points Count: ${recordedRoute.length}');

    final Map<String, dynamic>? result = await AuthService().sendTrainingResults(
      durationSeconds,
      distanceCoveredMeters,
      recordedRoute,
    );

    print('DEBUG: Result from sendTrainingResults: $result'); // Add this debug print

    int? savedRunId; // Variable to hold the saved Run ID
    int? xpEarned;
    List<dynamic>? achievementsEarned;
    List<dynamic>? challengesCompleted;

    if (result != null) {
      savedRunId = result['runId'];
      if (savedRunId != null) {
        final runDetails = await AuthService().fetchRunDetails(savedRunId);
        if (runDetails != null) {
          xpEarned = runDetails['xp_earned'];
          achievementsEarned = runDetails['earned_achievements'];
          challengesCompleted = runDetails['completed_challenges'];
        }
        // После получения runDetails обновим профиль пользователя
        await AuthService().refreshCurrentUser();
      }
      print('Training results saved with ID: $savedRunId');
    } else {
      print('Failed to get saved Run ID from backend response.');
      // TODO: Handle case where saving fails or ID is not returned
    }


    // Navigate to results screen
    Navigator.pushReplacement( // Use pushReplacement to replace the current screen
      context,
      MaterialPageRoute( 
        builder: (context) => TrainingResultsScreen(
          durationSeconds: durationSeconds,
          distanceMeters: distanceCoveredMeters,
          recordedRoute: recordedRoute,
          runId: savedRunId, // Pass the saved Run ID
          xpEarned: xpEarned, // Pass XP earned
          achievementsEarned: achievementsEarned, // Pass achievements earned
          challengesCompleted: challengesCompleted, // Pass completed challenges
          currentUser: AuthService().currentUser, // Pass current user
        ),
      ),
    );
  }

  // Method to format time from seconds into HH:MM:SS
  String _formatTime(int seconds) {
    final hours = (seconds ~/ 3600).toString().padLeft(2, '0');
    final minutes = ((seconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final remainingSeconds = (seconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$remainingSeconds';
  }

   // Method to calculate current pace (minutes per kilometer)
  void _calculateCurrentPace() {
    if (_distanceCoveredMeters > 0 && _secondsElapsed > 0) {
      final double kilometers = _distanceCoveredMeters / 1000.0;
       final double hours = _secondsElapsed / 3600.0;
       // Avoid division by zero if hours is 0
       final double pace = hours / kilometers * 60; // Pace in minutes per kilometer
       final int paceMinutes = pace.floor();
       final int paceSeconds = ((pace - paceMinutes) * 60).round();
        _currentPace = '$paceMinutes:${paceSeconds.toString().padLeft(2, '0')}';
     } else {
       _currentPace = '0:00'; // Default pace
     }
  }


  @override
  Widget build(BuildContext context) {
    // Get current date and time for AppBar subtitle
    final now = DateTime.now();
    // Format date as "Day of the week. Day" (e.g., "Пн. 5")
    final weekday = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'][now.weekday - 1];
    final dayOfMonth = now.day.toString();
    final date = '$weekday. $dayOfMonth';

    final time = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight + 40.0), // Increased height for subtitle
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white, // White background for AppBar
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)), // Rounded corners at the bottom
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1), // Subtle shadow
                spreadRadius: 1,
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
            child: AppBar(
              backgroundColor: Colors.transparent, // Make AppBar itself transparent as container provides color
              elevation: 0, // No shadow from AppBar itself
              title: Column(
                mainAxisSize: MainAxisSize.min, // To make column take minimum space
                children: [
                  const Text(
                    'СВОБОДНЫЙ РЕЖИМ',
                    style: TextStyle(
                      fontFamily: 'Satoshi',
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                      color: Colors.black,
                      shadows: [
                        Shadow(
                          blurRadius: 3.0,
                          color: Color.fromARGB(51, 0, 0, 0),
                          offset: Offset(0.5, 0.5),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4), // Spacing
                  Text(
                    '${date} | ${time}', // Date and time subtitle
                    style: const TextStyle(
                      fontFamily: 'Satoshi',
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
              centerTitle: true,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black), // Black back arrow
                onPressed: () => Navigator.of(context).pop(),
              ),
              actions: [ // Placeholder for actions if needed in mockup
                // Removed settings and question mark icons as per mockup
              ],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
           // Map Layer
           FlutterMap(
             mapController: _mapController, // Assign controller
             options: MapOptions(
               initialCenter: _currentUserPosition != null ? LatLng(_currentUserPosition!.latitude, _currentUserPosition!.longitude) : const LatLng(56.012027, 92.867245), // Initial center
               initialZoom: 14.0, // Initial zoom
               interactiveFlags: InteractiveFlag.all, // Enable all map interactions
               onMapReady: () { // Add onMapReady callback
                 setState(() {
                   _isMapReady = true; // Set the flag when the map is ready
                   // Optionally, center the map on the initial user position if available
                   if (_currentUserPosition != null) {
                     _mapController.move(LatLng(_currentUserPosition!.latitude, _currentUserPosition!.longitude), _mapController.zoom);
                   }
                 });
                 print('Map is ready.'); // Debug print
               },
             ),
             children: [
               TileLayer(
                 urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                 userAgentPackageName: 'com.runquest.app', // Replace with your package name
               ),
               // Recorded route polyline
               if (_routePoints.isNotEmpty)
                 PolylineLayer(
                   polylines: [
                     Polyline(
                       points: _routePoints, // Use recorded route points
                       strokeWidth: 4.0,
                       color: Colors.blue, // Color for the training route
                     ),
                   ],
                 ),
               // User location marker
               if (_currentUserPosition != null)
                 MarkerLayer(
                   markers: [
                     Marker(
                       width: 80.0,
                       height: 80.0,
                       point: LatLng(_currentUserPosition!.latitude, _currentUserPosition!.longitude), // User's current location
                       child: const Icon(
                         Icons.my_location,
                         color: Colors.red, // Change color to red
                         size: 40.0,
                       ),
                     ),
                   ],
                 ),
             ],
           ),

            // UI for stats (time, distance, pace) and controls
           Positioned( // Use Positioned to place UI on top of the map
             bottom: 0,
             left: 0,
             right: 0,
             child: Card(
               elevation: 8.0,
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0))),
               child: Padding(
                 padding: const EdgeInsets.all(4.0),
                 child: Column(
                   mainAxisSize: MainAxisSize.min,
                   children: [
                      // Training Stats
                       Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                             Expanded(
                                child: Card(
                                  color: Colors.white, // White background for card
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Rounded corners
                                  elevation: 4.0, // Subtle shadow
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 8.0), // Adjusted padding
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                         Text(
                                           '${(_distanceCoveredMeters / 1000.0).toStringAsFixed(2)}',
                                           style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                                         ),
                                         const SizedBox(height: 4),
                                         const Text('дистанция', style: TextStyle(fontSize: 8, color: Colors.black)),
                                      ],
                                    ),
                                  ),
                                ),
                             ),
                             const SizedBox(width: 12), // Spacing between cards
                             Expanded(
                                child: Card(
                                  color: const Color(0xFFD5FF2E), // Neon green background for pace
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Rounded corners
                                  elevation: 4.0, // Subtle shadow
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0), // Adjusted padding
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                         Text(
                                            '${_currentPace}',
                                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                                         ),
                                         const SizedBox(height: 4),
                                         const Text('темп', style: TextStyle(fontSize: 8, color: Colors.black)),
                                      ],
                                    ),
                                  ),
                                ),
                             ),
                             const SizedBox(width: 12), // Spacing between cards
                             Expanded(
                                child: Card(
                                  color: Colors.white, // White background for card
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Rounded corners
                                  elevation: 4.0, // Subtle shadow
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 10.0), // Adjusted padding
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                         Text(
                                           '${_trainingTime.substring(3, 8)}', // Display MM:SS only
                                           style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                                         ),
                                         const SizedBox(height: 4),
                                         const Text('время', style: TextStyle(fontSize: 8, color: Colors.black)),
                                      ],
                                    ),
                                  ),
                                ),
                             ),
                         ],
                      ),
                      const SizedBox(height: 20),


                     // Control Buttons (Start/Pause/Resume/Finish)
                     _buildControlButtons(),
                     const SizedBox(height: 22), // Add 12px bottom padding
                   ],
                 ),
               ),
             ),
           ),

        ],
      ),
    );
  }

  // Helper method to build control buttons based on training status
  Widget _buildControlButtons() {
    switch (_trainingStatus) {
      case TrainingStatus.notStarted:
        return SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              setState(() {
                _trainingStatus = TrainingStatus.active;
              });
              _startTimer();
              print('Training started.'); // Debug print
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD5FF2E), // Neon green
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)), // More rounded corners
              padding: const EdgeInsets.symmetric(vertical: 18), // Larger padding
            ),
            child: const Text(
              'НАЧАТЬ ТРЕНИРОВКУ',
              style: TextStyle(
                fontSize: 18, // Larger font size
                fontWeight: FontWeight.bold,
                color: Colors.black, // Black text
              ),
            ),
          ),
        );
      case TrainingStatus.active:
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _pauseTraining,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD5FF2E), // Neon green
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                ),
                child: const Icon(Icons.pause, color: Colors.black, size: 30), // Pause icon
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: ElevatedButton(
                onPressed: _finishTraining,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 255, 0, 0), // Red
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                ),
                child: const Icon(Icons.stop, color: Colors.black, size: 30), // Stop icon
              ),
            ),
          ],
        );
      case TrainingStatus.paused:
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _resumeTraining,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD5FF2E), // Neon green
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                ),
                child: const Icon(Icons.play_arrow, color: Colors.black, size: 30), // Play icon
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: ElevatedButton(
                onPressed: _finishTraining,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFEA1E63), // Red
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                ),
                child: const Icon(Icons.stop, color: Colors.black, size: 30), // Stop icon
              ),
            ),
          ],
        );
      case TrainingStatus.finished: // Once finished, possibly show a disabled button or navigate away
        return SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: null, // Disabled
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.grey, // Grey for disabled
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
              padding: const EdgeInsets.symmetric(vertical: 18),
            ),
            child: const Text(
              'ТРЕНИРОВКА ЗАВЕРШЕНА',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        );
    }
  }
}

enum TrainingStatus { notStarted, active, paused, finished } // Define TrainingStatus enum 