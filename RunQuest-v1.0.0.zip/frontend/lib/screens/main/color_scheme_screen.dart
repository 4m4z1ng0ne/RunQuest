import 'package:flutter/material.dart';

// Constants for colors
const Color _kAccentColor = Color(0xFFC0FF00); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон

class ThemeOption {
  final String name;
  final List<Color> colors;
  final String status;
  final IconData? unlockIcon;
  final int? unlockValue;
  final String? unlockCondition;

  ThemeOption({
    required this.name,
    required this.colors,
    required this.status,
    this.unlockIcon,
    this.unlockValue,
    this.unlockCondition,
  });
}

class ColorSchemeScreen extends StatefulWidget {
  const ColorSchemeScreen({super.key});

  @override
  State<ColorSchemeScreen> createState() => _ColorSchemeScreenState();
}

class _ColorSchemeScreenState extends State<ColorSchemeScreen> {
  // Dummy theme data
  List<ThemeOption> themes = [
    ThemeOption(
      name: 'стандартная',
      colors: [Colors.white, const Color(0xFFC0FF00), Colors.black, const Color(0xFFC0FF00), Colors.white],
      status: 'активна',
    ),
    ThemeOption(
      name: 'природа',
      colors: [Colors.black, const Color(0xFF455A64), Colors.white, const Color(0xFFC0FF00), const Color(0xFF00C853)],
      status: 'доступна',
    ),
    ThemeOption(
      name: 'неон',
      colors: [Colors.white, const Color(0xFF26A69A), const Color(0xFF26A69A), const Color(0xFFFDD835), Colors.white],
      status: 'заблокирована',
      unlockIcon: Icons.lock,
      unlockValue: 10,
      unlockCondition: 'тренировок',
    ),
    ThemeOption(
      name: 'огонь',
      colors: [Colors.grey, Colors.redAccent, Colors.orange, Colors.amber, Colors.white],
      status: 'заблокирована',
      unlockIcon: Icons.lock,
      unlockValue: 10,
      unlockCondition: 'челленджей',
    ),
  ];

  // Currently active theme
  int _activeThemeIndex = 0; // Default to the first theme

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'ТЕМА',
          style: TextStyle(
            fontFamily: 'Satoshi',
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 4.0),
              child: Text(
                'ЦВЕТОВЫЕ ТЕМЫ',
                style: TextStyle(
                  fontFamily: 'Satoshi',
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  color: Colors.black.withOpacity(0.7),
                ),
              ),
            ),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
                childAspectRatio: 0.85, // Adjust as needed to fit content
              ),
              itemCount: themes.length,
              itemBuilder: (context, index) {
                return _buildThemeCard(themes[index], index == _activeThemeIndex);
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildThemeCard(ThemeOption theme, bool isActive) {
    final bool isLocked = theme.status == 'заблокирована';
    return InkWell(
      onTap: isLocked
          ? null
          : () {
              setState(() {
                _activeThemeIndex = themes.indexOf(theme);
              });
              // TODO: Apply theme changes
            },
      borderRadius: BorderRadius.circular(10.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
          border: Border.all(
            color: isActive ? _kAccentColor : _kBorderColor,
            width: isActive ? 2.0 : 1.0,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: theme.colors.map((color) => _buildColorCircle(color)).toList(),
                  ),
                ),
                const Divider(color: Colors.black, height: 1.0),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        theme.name.toUpperCase(),
                        style: const TextStyle(
                          fontFamily: 'Satoshi',
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 5),
                      if (isLocked) ...[
                        Row(
                          children: [
                            Text(
                              '${theme.unlockValue}',
                              style: TextStyle(
                                fontFamily: 'Satoshi',
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[700],
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              theme.unlockCondition ?? '',
                              style: TextStyle(
                                fontFamily: 'Satoshi',
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[700],
                              ),
                            ),
                          ],
                        ),
                      ] else ...[
                        Text(
                          theme.status.toUpperCase(),
                          style: TextStyle(
                            fontFamily: 'Satoshi',
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            color: isActive ? _kAccentColor : Colors.grey[700],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
            if (isLocked)
              Positioned.fill(
                child: Opacity(
                  opacity: 0.5,
                  child: Center(
                    child: Icon(theme.unlockIcon, size: 80, color: Colors.black),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorCircle(Color color) {
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.black, width: 1.0),
      ),
    );
  }
} 