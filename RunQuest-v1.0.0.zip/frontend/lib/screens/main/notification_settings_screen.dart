import 'package:flutter/material.dart';

// Constants for colors
const Color _kAccentColor = Color(0xFFC0FF00); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool _allowAllNotifications = true;
  bool _trainingReminders = true;
  bool _newAchievements = true;
  bool _goalProgress = false;
  bool _raceEvents = true;
  bool _newsUpdates = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'УВЕДОМЛЕНИЯ',
          style: TextStyle(
            fontFamily: 'Satoshi',
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionContainer(
              children: [
                _buildSwitchOption(
                  label: 'РАЗРЕШИТЬ ВСЕ УВЕДОМЛЕНИЯ',
                  value: _allowAllNotifications,
                  onChanged: (bool value) {
                    setState(() {
                      _allowAllNotifications = value;
                      _trainingReminders = value;
                      _newAchievements = value;
                      _goalProgress = value;
                      _raceEvents = value;
                      _newsUpdates = value;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
            _buildSectionContainer(
              children: [
                _buildSwitchOption(
                  label: 'НАПОМИНАНИЯ О ТРЕНИРОВКАХ',
                  description: 'Получать напоминания, если вы давно не тренировались или о плановых забегах.',
                  value: _trainingReminders,
                  onChanged: (bool value) {
                    setState(() {
                      _trainingReminders = value;
                      if (!value) _allowAllNotifications = false;
                    });
                  },
                ),
                const Divider(color: Colors.black, height: 1.0),
                _buildSwitchOption(
                  label: 'НОВЫЕ ДОСТИЖЕНИЯ',
                  description: 'Уведомлять о получении новых бейджей и наград.',
                  value: _newAchievements,
                  onChanged: (bool value) {
                    setState(() {
                      _newAchievements = value;
                      if (!value) _allowAllNotifications = false;
                    });
                  },
                ),
                const Divider(color: Colors.black, height: 1.0),
                _buildSwitchOption(
                  label: 'ПРОГРЕСС ПО ЦЕЛЯМ И СТРИКАМ',
                  description: 'Сообщать о достижении целей и продолжении серий тренировок.',
                  value: _goalProgress,
                  onChanged: (bool value) {
                    setState(() {
                      _goalProgress = value;
                      if (!value) _allowAllNotifications = false;
                    });
                  },
                ),
                const Divider(color: Colors.black, height: 1.0),
                _buildSwitchOption(
                  label: 'СОБЫТИЯ ГОНОК НА ВРЕМЯ',
                  description: 'Напоминания о предстоящих гонках или если ваш рекорд побит.',
                  value: _raceEvents,
                  onChanged: (bool value) {
                    setState(() {
                      _raceEvents = value;
                      if (!value) _allowAllNotifications = false;
                    });
                  },
                ),
                const Divider(color: Colors.black, height: 1.0),
                _buildSwitchOption(
                  label: 'НОВОСТИ И ОБНОВЛЕНИЯ',
                  description: 'Получать информацию о новых функциях и событиях приложения.',
                  value: _newsUpdates,
                  onChanged: (bool value) {
                    setState(() {
                      _newsUpdates = value;
                      if (!value) _allowAllNotifications = false;
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionContainer({
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.0),
        border: Border.all(color: Colors.black, width: 1.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _buildSwitchOption({
    required String label,
    String? description,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 12.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontFamily: 'Satoshi',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.black,
                  ),
                ),
                if (description != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(
                      fontFamily: 'Satoshi',
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[700],
                    ),
                  ),
                ],
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: _kAccentColor,
            inactiveThumbColor: Colors.grey,
            inactiveTrackColor: Colors.grey.shade300,
          ),
        ],
      ),
    );
  }
} 