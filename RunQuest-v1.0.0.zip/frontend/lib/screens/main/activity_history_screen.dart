// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:intl/intl.dart'; // Import for date formatting
import 'package:frontend/screens/main/race_results_screen.dart'; // Import RaceResultsScreen
import 'package:frontend/screens/main/training_results_screen.dart'; // Import TrainingResultsScreen
import 'package:latlong2/latlong.dart'; // Import LatLng

class ActivityHistoryScreen extends StatefulWidget {
  const ActivityHistoryScreen({super.key});

  @override
  State<ActivityHistoryScreen> createState() => _ActivityHistoryScreenState();
}

class _ActivityHistoryScreenState extends State<ActivityHistoryScreen> {
  List<dynamic> _activityList = [];
  bool _isLoading = true;
  String _selectedFilter = 'Все'; // New state variable for selected filter

  // Define accent colors for the game-like aesthetic
  final Color _primaryAccentColor = const Color.fromARGB(255, 72, 255, 0); // Неоново-зеленый
  final Color _secondaryAccentColor = const Color.fromARGB(255, 59, 183, 255); // Ярко-оранжевый/желтый

  @override
  void initState() {
    super.initState();
    _fetchActivityHistory();
  }

  Future<void> _fetchActivityHistory() async {
    setState(() {
      _isLoading = true;
    });
    try {
      List<dynamic> combinedList = [];

      if (_selectedFilter == 'Все' || _selectedFilter == 'Пробежки') {
        // Fetch runs (trainings)
        final runsResponse = await AuthService().getUserRuns();
        List<dynamic> runs = [];
        if (runsResponse.statusCode == 200) {
          List<dynamic> rawRunsFeatures = [];
          if (runsResponse.data is Map && runsResponse.data.containsKey('results') && runsResponse.data['results'] is Map && runsResponse.data['results'].containsKey('features') && runsResponse.data['results']['features'] is List) {
            rawRunsFeatures = runsResponse.data['results']['features'] as List;
          } else {
            print('Unexpected run data format (not a FeatureCollection): ${runsResponse.data.runtimeType}');
          }

          runs = rawRunsFeatures.map((runFeature) {
            print('DEBUG: Processing runFeature: $runFeature'); // Добавляем отладочный вывод
            final runProperties = runFeature['properties'] ?? {};
            final runGeometry = runFeature['geometry'] ?? {};

            return {
              'type': 'Тренировка',
              'date': (() {
                final String startTimeString = runProperties['start_time']?.toString() ?? DateTime.now().toIso8601String();
                print('Run Start Time String: $startTimeString, Type: ${startTimeString.runtimeType}');
                return DateTime.parse(startTimeString);
              })(),
              'duration_seconds': runProperties['duration_seconds'] ?? 0,
              'distance_meters': runProperties['distance_meters'] ?? 0.0,
              'id': runFeature['id'] ?? 0,
              'recorded_route': (() {
                final dynamic routeCoordinates = runGeometry['coordinates'];
                if (routeCoordinates is List) {
                  return routeCoordinates.map((coord) => LatLng(coord[1] as double, coord[0] as double)).toList();
                } else {
                  return <LatLng>[];
                }
              })(),
              'xp_earned': runProperties['xp_earned'] ?? 0,
              'achievements_earned': runProperties['earned_achievements'] ?? [],
              'challenges_completed': runProperties['completed_challenges'] ?? [],
            };
          }).toList();
        }
        combinedList.addAll(runs);
      }

      if (_selectedFilter == 'Все' || _selectedFilter == 'Гонки') {
        // Fetch race attempts
        final raceAttemptsResponse = await AuthService().getUserRaceAttempts();
        List<dynamic> raceAttempts = [];
        if (raceAttemptsResponse.statusCode == 200) {
          List<dynamic> rawRaceAttemptsData = [];
          if (raceAttemptsResponse.data is Map && raceAttemptsResponse.data.containsKey('results')) {
            rawRaceAttemptsData = raceAttemptsResponse.data['results'] as List;
          } else if (raceAttemptsResponse.data is List) {
            rawRaceAttemptsData = raceAttemptsResponse.data as List;
          } else {
            print('Unexpected race attempt data format: ${raceAttemptsResponse.data.runtimeType}');
          }

          raceAttempts = rawRaceAttemptsData.map((attempt) {
            return {
              'type': 'Гонка',
              'date': (() {
                final String startTimeString = attempt['start_time']?.toString() ?? DateTime.now().toIso8601String();
                print('Race Attempt Start Time String: $startTimeString, Type: ${startTimeString.runtimeType}');
                return DateTime.parse(startTimeString);
              })(),
              'duration_seconds': attempt['duration_seconds'] ?? 0,
              'distance_meters': (attempt['actual_distance_meters'] ?? 0.0) * 1000,
              'track_name': attempt['race_track_name'] ?? 'Без названия',
              'id': attempt['id'] ?? 0,
              'track': attempt['track'],
              'recorded_route': (() {
                final dynamic routeCoordinates = attempt['actual_route_data']?['coordinates'];
                if (routeCoordinates is List) {
                  return routeCoordinates.map((coord) => LatLng(coord[1] as double, coord[0] as double)).toList();
                } else {
                  return <LatLng>[];
                }
              })(),
              'xp_earned': attempt['xp_earned'] ?? 0,
              'achievements_earned': attempt['earned_achievements'] ?? [],
              'challenges_completed': attempt['completed_challenges'] ?? [],
            };
          }).toList();
        }
        combinedList.addAll(raceAttempts);
      }

      // Combine and sort activity by date (most recent first)
      combinedList.sort((a, b) => b['date'].compareTo(a['date']));

      setState(() {
        _activityList = combinedList;
      });

    } catch (e) {
      print('Error fetching activity history: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка загрузки истории активности: $e'))
        );
      }
      setState(() {
        _activityList = []; // Clear list on error
      });
    } finally {
      // Ensure loading is always set to false
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Helper to format duration
  String _formatDuration(int seconds) {
    final int hours = seconds ~/ 3600;
    final int minutes = (seconds % 3600) ~/ 60;
    final int remainingSeconds = seconds % 60;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  // Helper to format distance
  String _formatDistance(double meters) {
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} м';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} км';
    }
  }

  // Helper to format pace (minutes per kilometer)
  String _formatPace(double distanceMeters, int durationSeconds) {
    if (distanceMeters == 0 || durationSeconds == 0) {
      return '00:00 мин/км';
    }
    final double distanceKm = distanceMeters / 1000;
    final double paceSecondsPerKm = durationSeconds / distanceKm;
    final int minutes = paceSecondsPerKm ~/ 60;
    final int seconds = (paceSecondsPerKm % 60).round();
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')} мин/км';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F0), // Светло-серый фон
      appBar: AppBar(
        backgroundColor: Colors.white, // Белый фон AppBar
        foregroundColor: Colors.black, // Черный цвет для заголовка и иконок
        elevation: 2, // Небольшая тень
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30), // Закругленные нижние углы
          ),
        ),
        shadowColor: Colors.black.withOpacity(0.2), // Более выраженная тень
        title: Column(
          mainAxisSize: MainAxisSize.min, // Чтобы колонка занимала минимум места
          children: const [
            Text(
              'ИСТОРИЯ',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 22,
                letterSpacing: 1.5,
                color: Colors.black,
              ),
            ),
            Text(
              'АКТИВНОСТИ',
          style: TextStyle(
                fontWeight: FontWeight.w900,
            fontSize: 22,
                letterSpacing: 1.5,
                color: Colors.black,
          ),
            ),
          ],
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70.0), // Увеличиваем высоту для кнопок фильтра
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8.0), // Меньшие горизонтальные отступы
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildFilterButton('Все'),
                _buildFilterButton('Гонки'),
                _buildFilterButton('Пробежки'),
              ],
            ),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF6BFF00))) // Акцентный цвет для индикатора загрузки
          : _activityList.isEmpty
              ? const Center(
                  child: Text(
                    'Нет записей об активности.',
                    style: TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16.0), // Отступы для списка
                  itemCount: _activityList.length,
                  itemBuilder: (context, index) {
                    final activity = _activityList[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 16.0), // Отступы между карточками
                      decoration: BoxDecoration(
                        color: Colors.white, // Белый фон карточки
                        borderRadius: BorderRadius.circular(20.0), // Закругленные углы
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3), // Более выраженная тень
                            spreadRadius: 0,
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                        border: Border.all(
                          color: _primaryAccentColor, // Акцентный цвет для рамки
                          width: 2.0, // Более толстая рамка
                        ),
                      ),
                      child: Material( // Используем Material для эффекта InkWell
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            if (activity['type'] == 'Гонка') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => RaceResultsScreen(
                                    attemptId: activity['id'],
                                    trackName: activity['track_name'],
                                  ),
                                ),
                              );
                            } else if (activity['type'] == 'Тренировка') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => TrainingResultsScreen(
                                    durationSeconds: activity['duration_seconds'],
                                    distanceMeters: activity['distance_meters'],
                                    recordedRoute: activity['recorded_route'],
                                    runId: activity['id'],
                                    xpEarned: activity['xp_earned'],
                                    achievementsEarned: activity['achievements_earned'],
                                    challengesCompleted: activity['challenges_completed'],
                                  ),
                                ),
                              );
                            }
                          },
                          // borderRadius: BorderRadius.circular(12.0), // Убираем скругление
                          child: Padding(
                            padding: const EdgeInsets.all(20.0), // Увеличиваем паддинг внутри карточки
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        activity['type'] == 'Гонка'
                                            ? activity['track_name']?.toUpperCase() ?? 'БЕЗ НАЗВАНИЯ'
                                            : 'ТРЕНИРОВКА', // Все заглавные
                                        style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          fontSize: 20, // Еще больше
                                          color: Colors.black,
                                          letterSpacing: 1.5, // Больше межбуквенный интервал
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Icon(
                                      activity['type'] == 'Гонка' ? Icons.flag : Icons.directions_run,
                                      color: _primaryAccentColor,
                                      size: 35, // Еще больше
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10), // Увеличиваем отступ
                                Text(
                                  '${DateFormat('dd.MM.yyyy HH:mm').format(activity['date'])}', // Формат даты
                                  style: TextStyle(color: Colors.grey[800], fontSize: 14, fontWeight: FontWeight.w600), // Темнее и жирнее
                                ),
                                const SizedBox(height: 18), // Увеличиваем отступ
                                Wrap( // Используем Wrap для предотвращения переполнения
                                  spacing: 12.0, // Горизонтальный отступ
                                  runSpacing: 12.0, // Вертикальный отступ
                                  children: [
                                    _buildMetricChip(
                                      'Дистанция',
                                      _formatDistance(activity['distance_meters']),
                                      Icons.straighten,
                                      _primaryAccentColor,
                                    ),
                                    _buildMetricChip(
                                      'Время',
                                      _formatDuration(activity['duration_seconds']),
                                      Icons.timer,
                                      _secondaryAccentColor,
                                    ),
                                    if (activity['type'] == 'Тренировка')
                                      _buildMetricChip(
                                        'Темп',
                                        _formatPace(activity['distance_meters'], activity['duration_seconds']),
                                        Icons.speed,
                                        _primaryAccentColor,
                                      ),
                                  ],
                                ),
                                if (activity['xp_earned'] != null && activity['xp_earned'] > 0)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 20.0), // Больше отступ
                                    child: Row(
                                      children: [
                                        Icon(Icons.star, color: _secondaryAccentColor, size: 25), // Увеличенная звезда
                                        const SizedBox(width: 10), // Больше отступ
                                        Expanded( // Оборачиваем текст в Expanded
                                          child: Text(
                                            'XP ЗАРАБОТАНО: ${activity['xp_earned']}', // Все заглавные
                                            style: TextStyle(
                                              color: _secondaryAccentColor,
                                              fontWeight: FontWeight.w900, // Очень жирный
                                              fontSize: 16,
                                              letterSpacing: 0.5,
                                            ),
                                            overflow: TextOverflow.ellipsis, // Добавляем обрезание текста
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                if (activity['achievements_earned'] != null && activity['achievements_earned']!.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 15.0), // Больше отступ
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'ДОСТИЖЕНИЯ:', // Все заглавные
                                          style: TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 16,
                                            color: Colors.black,
                                            letterSpacing: 0.7,
                                          ),
                                        ),
                                        const SizedBox(height: 8), // Отступ
                                        Wrap( // Используем Wrap
                                          spacing: 10.0,
                                          runSpacing: 10.0,
                                          children: activity['achievements_earned']!.map<Widget>((achievement) =>
                                            _buildAchievementChallengeChip(
                                              achievement['name'] ?? 'НЕИЗВЕСТНОЕ ДОСТИЖЕНИЕ', // Все заглавные
                                              _primaryAccentColor,
                                              Icons.emoji_events,
                                            )
                                          ).toList(),
                                        ),
                                      ],
                                    ),
                                  ),
                                if (activity['challenges_completed'] != null && activity['challenges_completed']!.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 15.0), // Больше отступ
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'ВЫПОЛНЕННЫЕ ЧЕЛЛЕНДЖИ:', // Все заглавные
                                          style: TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 16,
                                            color: Colors.black,
                                            letterSpacing: 0.7,
                                          ),
                                        ),
                                        const SizedBox(height: 8), // Отступ
                                        Wrap( // Используем Wrap
                                          spacing: 10.0,
                                          runSpacing: 10.0,
                                          children: activity['challenges_completed']!.map<Widget>((challenge) =>
                                            _buildAchievementChallengeChip(
                                              '${challenge['name'] ?? 'НЕИЗВЕСТНЫЙ ЧЕЛЛЕНДЖ'} (XP: ${challenge['xp_reward'] ?? 0})', // Все заглавные
                                              _secondaryAccentColor,
                                              Icons.flag_outlined,
                                            )
                                          ).toList(),
                                        ),
                                      ],
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }

  Widget _buildFilterButton(String text) { // Убираем Color accentColor из параметров, используем поля класса
    final bool isSelected = _selectedFilter == text;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedFilter = text;
            _fetchActivityHistory();
          });
        },
        child: Container(
          height: 45, // Увеличиваем высоту кнопки
          margin: const EdgeInsets.symmetric(horizontal: 5.0), // Немного больший отступ
          decoration: BoxDecoration(
            color: isSelected ? _primaryAccentColor : const Color.fromARGB(255, 205, 209, 211), // Акцентный цвет для выбранной, светло-серый для остальных
            borderRadius: BorderRadius.circular(15.0), // Закругленные углы для кнопок
            border: isSelected ? Border.all(color: Colors.white, width: 2.5) : null, // Белая рамка для выбранной кнопки
            boxShadow: [
              if (isSelected) // Тень только для выбранной кнопки
                BoxShadow(
                  color: _primaryAccentColor.withOpacity(0.6), // Более выраженная тень
                  blurRadius: 12,
                  spreadRadius: 3,
                ),
            ],
          ),
          child: Center(
            child: Text(
              text.toUpperCase(), // Все заглавные
              style: TextStyle(
                color: isSelected ? Colors.black : Colors.black, // Черный текст на акцентном и на светлом
                fontWeight: isSelected ? FontWeight.w900 : FontWeight.bold, // Очень жирный для выбранной
                fontSize: 11, // Уменьшаем размер текста
                letterSpacing: 1.0, // Межбуквенный интервал
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMetricChip(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), // Увеличиваем паддинг
      decoration: BoxDecoration(
        color: color.withOpacity(0.2), // Более выраженный оттенок
        borderRadius: BorderRadius.circular(10.0), // Закругленные углы
        border: Border.all(color: color, width: 1.5), // Более толстая рамка
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20, color: color), // Увеличенная иконка
          const SizedBox(width: 8), // Увеличенный отступ
          Flexible( // Добавлено Flexible
            child: Text(
              '$label: $value',
              style: TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.w700), // Черный, очень жирный текст
              overflow: TextOverflow.ellipsis, // Добавлено обрезание текста
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementChallengeChip(String text, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), // Увеличиваем паддинг
      decoration: BoxDecoration(
        color: color.withOpacity(0.2), // Более выраженный оттенок
        borderRadius: BorderRadius.circular(10.0), // Закругленные углы
        border: Border.all(color: color, width: 1.5), // Более толстая рамка
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: color), // Увеличенная иконка
          const SizedBox(width: 8), // Увеличенный отступ
          Flexible( // Используем Flexible
            child: Text(
              text,
              style: TextStyle(color: Colors.black, fontSize: 13, fontWeight: FontWeight.w700), // Черный, очень жирный текст
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
} 