import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For date formatting
import 'package:frontend/services/friend_service.dart'; // Assuming friend service handles invitations

class ScheduleJointRunScreen extends StatefulWidget {
  final int invitedUserId;
  final String invitedUsername;

  const ScheduleJointRunScreen({
    super.key,
    required this.invitedUserId,
    required this.invitedUsername,
  });

  @override
  State<ScheduleJointRunScreen> createState() => _ScheduleJointRunScreenState();
}

class _ScheduleJointRunScreenState extends State<ScheduleJointRunScreen> {
  final FriendService _friendService = FriendService(); // Or a dedicated JointRunService
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _commentsController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  bool _isLoading = false;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Roboto'),
            primaryTextTheme: Theme.of(context).primaryTextTheme.apply(fontFamily: 'Roboto'),
            dialogTheme: Theme.of(context).dialogTheme.copyWith(
              contentTextStyle: const TextStyle(fontFamily: 'Roboto'),
              titleTextStyle: const TextStyle(fontFamily: 'Roboto', fontSize: 20, fontWeight: FontWeight.bold),
            ),
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: const Color(0xFFC0FF00),
              onPrimary: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            textTheme: Theme.of(context).textTheme.apply(fontFamily: 'Roboto'),
            primaryTextTheme: Theme.of(context).primaryTextTheme.apply(fontFamily: 'Roboto'),
            dialogTheme: Theme.of(context).dialogTheme.copyWith(
              contentTextStyle: const TextStyle(fontFamily: 'Roboto'),
              titleTextStyle: const TextStyle(fontFamily: 'Roboto', fontSize: 20, fontWeight: FontWeight.bold),
            ),
            colorScheme: Theme.of(context).colorScheme.copyWith(
              primary: const Color(0xFFC0FF00),
              onPrimary: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _sendInvitation() async {
    if (_selectedDate == null || _selectedTime == null || _locationController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Пожалуйста, заполните дату, время и место встречи.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Combine date and time
      final DateTime scheduledAt = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        _selectedTime!.hour,
        _selectedTime!.minute,
      );

      // TODO: Call an API to send the joint run invitation
      await _friendService.sendJointRunInvitation(
        invitedUserId: widget.invitedUserId,
        scheduledAt: scheduledAt,
        location: _locationController.text,
        comments: _commentsController.text.isNotEmpty ? _commentsController.text : null,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Приглашение отправлено!')),
      );
      Navigator.of(context).pop(); // Go back to the previous screen
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка при отправке приглашения: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _locationController.dispose();
    _commentsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F0F0),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ПРИГЛАСИТЬ',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 20,
                fontFamily: 'Satoshi',
              ),
            ),
            Text(
              'НА ПРОБЕЖКУ',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 20,
                fontFamily: 'Satoshi',
              ),
            ),
          ],
        ),
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFC0FF00)))
          : SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // --- Карточка выбора даты ---
                  Container(
                    margin: const EdgeInsets.only(bottom: 16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      leading: const Icon(Icons.calendar_today, color: Colors.black),
                      title: Text(
                        _selectedDate == null
                            ? 'Выберите дату пробежки'
                            : 'Дата пробежки: ${DateFormat('dd.MM.yyyy').format(_selectedDate!)}',
                        style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Satoshi',
                        ),
                      ),
                      onTap: () => _selectDate(context),
                    ),
                  ),
                  // --- Карточка выбора времени ---
                  Container(
                    margin: const EdgeInsets.only(bottom: 16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      leading: const Icon(Icons.access_time, color: Colors.black),
                      title: Text(
                        _selectedTime == null
                            ? 'Выберите время пробежки'
                            : 'Время пробежки: ${_selectedTime!.format(context)}',
                        style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Satoshi',
                        ),
                      ),
                      onTap: () => _selectTime(context),
                    ),
                  ),
                  // --- Поле ввода места ---
                  Container(
                    margin: const EdgeInsets.only(bottom: 16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _locationController,
                      style: const TextStyle(fontFamily: 'Satoshi', color: Colors.black),
                      decoration: const InputDecoration(
                        labelText: 'Место встречи',
                        labelStyle: TextStyle(fontFamily: 'Satoshi', color: Colors.black54),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                      ),
                    ),
                  ),
                  // --- Поле ввода комментариев ---
                  Container(
                    margin: const EdgeInsets.only(bottom: 32.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFACACAC), width: 1.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _commentsController,
                      style: const TextStyle(fontFamily: 'Satoshi', color: Colors.black),
                      decoration: const InputDecoration(
                        labelText: 'Дополнительные комментарии (необязательно)',
                        labelStyle: TextStyle(fontFamily: 'Satoshi', color: Colors.black54),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                        alignLabelWithHint: true,
                      ),
                      maxLines: 3,
                    ),
                  ),
                  // --- Кнопка отправить ---
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _sendInvitation,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFC0FF00),
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
                        ),
                        elevation: 5,
                        shadowColor: Colors.black.withOpacity(0.05),
                        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
                        textStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Satoshi',
                        ),
                      ),
                      child: const Text('ОТПРАВИТЬ ПРИГЛАШЕНИЕ'),
                    ),
                  ),
                  const SizedBox(height: 16.0),
                  // --- Кнопка отмена ---
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: const BorderSide(color: Color(0xFFACACAC), width: 1.0),
                        ),
                        elevation: 5,
                        shadowColor: Colors.black.withOpacity(0.05),
                        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 15.0),
                        textStyle: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Satoshi',
                        ),
                      ),
                      child: const Text('ОТМЕНА'),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
} 