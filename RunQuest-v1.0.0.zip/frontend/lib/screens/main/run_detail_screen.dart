import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:flutter_map/flutter_map.dart'; // Import FlutterMap
import 'package:latlong2/latlong.dart'; // Import LatLng

class RunDetailScreen extends StatefulWidget {
  final Map<String, dynamic> run;

  const RunDetailScreen({super.key, required this.run});

  @override
  State<RunDetailScreen> createState() => _RunDetailScreenState();
}

class _RunDetailScreenState extends State<RunDetailScreen> {
  final AuthService _authService = AuthService();
  Map<String, dynamic>? _runDetail;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchRunDetail();
  }

  Future<void> _fetchRunDetail() async {
    try {
      final int? runId = widget.run['id'] as int?;
      if (runId == null) {
         setState(() {
          _error = 'Неверный ID забега';
          _isLoading = false;
        });
        return;
      }

      final response = await _authService.getRunDetail(runId);
      if (response.statusCode == 200) {
        setState(() {
          _runDetail = response.data;
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Не удалось загрузить детали забега: ${response.statusCode}';
          _isLoading = false;
        });
        print('Failed to load run detail: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _error = 'Ошибка при загрузке деталей забега: $e';
        _isLoading = false;
      });
      print('Error fetching run detail: $e');
    }
  }

   // Helper function to format duration (copied from ProfileScreen for now)
  String _formatDuration(int seconds) {
    if (seconds == 0 || seconds < 0) return 'N/A';
    final int minutes = (seconds / 60).floor();
    final int remainingSeconds = seconds % 60;
    return '$minutesм $remainingSecondsс';
  }

  // Helper function to format distance (copied from ProfileScreen for now)
  String _formatDistance(double meters) {
     if (meters == 0 || meters < 0) return 'N/A';
    if (meters < 1000) {
      return '${meters.toStringAsFixed(0)} м';
    } else {
      return '${(meters / 1000).toStringAsFixed(2)} км';
    }
  }

   // Helper function to parse GeoJSON LineString to List<LatLng>
  List<LatLng> _parseRouteData(Map<String, dynamic>? geojson) {
    if (geojson == null || geojson['type'] != 'LineString' || geojson['coordinates'] == null) {
      return [];
    }
    // GeoJSON coordinates are typically [longitude, latitude]
    return (geojson['coordinates'] as List).map((coord) => LatLng(coord[1].toDouble(), coord[0].toDouble())).toList();
  }

  @override
  Widget build(BuildContext context) {
    // Extract route data and parse it
    final List<LatLng> routePoints = _parseRouteData(_runDetail?['route_data']);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Детали забега'),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(), // Show loading indicator
            )
          : _error != null
              ? Center(
                  child: Text(_error!), // Show error message
                )
              : _runDetail == null
                  ? const Center(
                      child: Text('Данные забега не загружены.'), // Handle case where data is null after loading
                    )
                  : Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ID забега: ${_runDetail!['id']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8.0),
                          Text('Дистанция: ${_formatDistance((_runDetail!['distance_meters'] as num?)?.toDouble() ?? 0.0)}'),
                          Text('Время: ${_formatDuration((_runDetail!['duration_seconds'] as num?)?.toInt() ?? 0)}'),
                          Text('Начало: ${_runDetail!['start_time'] ?? 'N/A'}'),
                          const SizedBox(height: 16.0),
                          Expanded(
                            child: FlutterMap(
                              options: MapOptions(
                                // Set initial center and zoom. Use the first point of the route if available, otherwise a default location.
                                center: routePoints.isNotEmpty ? routePoints.first : const LatLng(0, 0), // TODO: Use a more appropriate default or calculate center
                                zoom: routePoints.isNotEmpty ? 15.0 : 2.0, // Adjust zoom level
                                interactiveFlags: InteractiveFlag.all - InteractiveFlag.rotate, // Disable rotation
                              ),
                              children: [
                                TileLayer(
                                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                  userAgentPackageName: 'com.example.runquest', // Replace with your package name
                                ),
                                if (routePoints.isNotEmpty)
                                  PolylineLayer(
                                    polylines: [
                                      Polyline(
                                        points: routePoints,
                                        color: Colors.blueAccent,
                                        strokeWidth: 4.0,
                                      ),
                                    ],
                                  ),
                                 if (routePoints.isNotEmpty) // Add markers only if route data is available
                                  MarkerLayer(
                                    markers: [
                                      // Start marker
                                      Marker(
                                        point: routePoints.first,
                                        width: 40, // Adjust size as needed
                                        height: 40, // Adjust size as needed
                                        alignment: Alignment.bottomCenter, // Use alignment instead of anchorPos
                                        child: const Icon(Icons.flag, size: 40, color: Colors.green), // Start icon
                                      ),
                                      // End marker
                                      Marker(
                                        point: routePoints.last,
                                        width: 40, // Adjust size as needed
                                        height: 40, // Adjust size as needed
                                        alignment: Alignment.bottomCenter, // Use alignment instead of anchorPos
                                        child: const Icon(Icons.flag, size: 40, color: Colors.red), // End icon
                                      ),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                           // TODO: Add more run details if needed below the map
                        ],
                      ),
                    ),
    );
  }
}
