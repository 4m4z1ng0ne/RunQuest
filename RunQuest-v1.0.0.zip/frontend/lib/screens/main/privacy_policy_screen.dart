import 'package:flutter/material.dart';

// Constants for colors
const Color _kAccentColor = Color(0xFFC0FF00); // Ярко-зеленый
const Color _kBorderColor = Color(0xFFACACAC); // Серый
const Color _kBackgroundColor = Color(0xFFF7F8FC); // Светлый фон

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Приватность',
              style: TextStyle(
                fontFamily: 'Satoshi',
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection(
              '1. Сбор и использование информации',
              'Мы собираем информацию, которую вы предоставляете нам напрямую, например, когда вы регистрируетесь, используете наши услуги или связываетесь с нами. Эта информация может включать ваше имя, адрес электронной почты, данные о местоположении (с вашего разрешения) и информацию о вашей активности в приложении.',
            ),
            _buildSection(
              '2. Цели использования',
              'Собранная информация используется для предоставления, поддержания и улучшения наших услуг, для персонализации вашего опыта, для анализа использования приложения, для связи с вами и для обеспечения безопасности. Мы также можем использовать данные для маркетинговых и рекламных целей, но только с вашего явного согласия.',
            ),
            _buildSection(
              '3. Передача информации третьим лицам',
              'Мы не продаем, не обмениваем и не передаем вашу личную информацию третьим лицам без вашего согласия, за исключением случаев, когда это необходимо для предоставления услуг (например, сторонние поставщики услуг) или требуется по закону. Мы можем делиться агрегированными или обезличенными данными, которые не идентифицируют вас лично.',
            ),
            _buildSection(
              '4. Безопасность данных',
              'Мы принимаем разумные меры для защиты вашей личной информации от несанкционированного доступа, использования или раскрытия. Однако ни один метод передачи данных через Интернет или метод электронного хранения не является 100% безопасным.',
            ),
            _buildSection(
              '5. Ваши права',
              'Вы имеете право на доступ, изменение или удаление своей личной информации. Вы также можете отозвать свое согласие на обработку данных или возразить против определенных видов обработки. Для осуществления этих прав, пожалуйста, свяжитесь с нами.',
            ),
            _buildSection(
              '6. Изменения в политике конфиденциальности',
              'Мы можем время от времени обновлять нашу политику конфиденциальности. Любые изменения будут опубликованы на этой странице. Мы рекомендуем вам регулярно просматривать эту политику для получения актуальной информации.',
            ),
            const SizedBox(height: 20),
            Text(
              'Дата последнего обновления: 10 мая 2025 г.',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Colors.black.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontFamily: 'Roboto',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            content,
            style: TextStyle(
              fontFamily: 'Roboto',
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }
} 