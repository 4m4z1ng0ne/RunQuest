import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Corrected Import AuthService
import 'registration_screen.dart'; // Import RegistrationScreen
import 'package:frontend/screens/main/main_screen.dart'; // Import your main screen file

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthService _authService = AuthService(); // Create an instance of AuthService

  void _login() async { // Make the method async
    String username = _usernameController.text.trim(); // Добавьте .trim() для удаления пробелов
    String password = _passwordController.text.trim(); // Добавьте .trim() для удаления пробелов

    if (username.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Пожалуйста, введите логин')),
      );
      return; // Прекращаем выполнение функции, если логин пуст
    }

    if (password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Пожалуйста, введите пароль')),
      );
      return; // Прекращаем выполнение функции, если пароль пуст
    }

    // Use AuthService to login
    String? errorMessage = await _authService.login(username, password); // Измените на получение String?

    if (errorMessage == null) { // Проверяем, что errorMessage равен null (успех)
      print('Login successful!');
       Navigator.pushReplacement(
         context,
         MaterialPageRoute(builder: (context) => const MainScreen()), // Navigate to your main screen
       );
    } else {
      print('Login failed: $errorMessage'); // Логируем конкретную ошибку
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)), // Отображаем конкретное сообщение об ошибке
      );
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Вход'),
      ),
      body: Theme(
        data: Theme.of(context).copyWith(
          textTheme: Theme.of(context).textTheme.apply(
            fontFamily: 'Roboto',
          ),
        ),
        child: SingleChildScrollView( // Add SingleChildScrollView
          child: Column(
            children: <Widget>[
              // Top illustration from SVG
              Image.asset(
                'static/RunQuest logo.png', // Placeholder image
                height: 150, // Adjust height as per SVG layout
              ),
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch, // Stretch children to fill width
                  children: <Widget>[
                    const Text(
                      'Добро пожаловать в RunQuest',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.black, // Adjust color if needed
                        fontFamily: 'Roboto',                      
                      ),
                    ),
                    // const SizedBox(height: 16.0),
                    // const Text(
                    //   'Вход',
                    //   textAlign: TextAlign.center,
                    //   style: TextStyle(
                    //     fontSize: 18,
                    //     fontWeight: FontWeight.w500,
                    //     color: Colors.grey, // Adjust color if needed

                    //   ),
                    // ),
                    const SizedBox(height: 48.0), // More space before inputs

                    TextField(
                      controller: _usernameController,
                      decoration: InputDecoration(
                        labelText: 'Логин',
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0), // Rounded corners
                          borderSide: BorderSide.none, // No border
                        ),
                        enabledBorder: OutlineInputBorder( // Also apply for enabled state
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder( // Apply for focused state
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(color: Colors.blue, width: 2.0), // Highlight on focus
                        ),
                      ),
                    ),
                    const SizedBox(height: 12.0),
                    TextField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                        labelText: 'Пароль',
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide.none,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(color: Colors.blue, width: 2.0),
                        ),
                      ),
                      obscureText: true,
                    ),
                    const SizedBox(height: 24.0),
                    ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 204, 255, 0), // Button background color
                        foregroundColor: Colors.black, // Text color
                        padding: const EdgeInsets.symmetric(vertical: 16.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0), // Rounded corners for button
                        ),
                      ),
                      
                      child: const Text(
                        'Войти',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Roboto', // Устанавливаем шрифт Roboto
                        ),
                      ),
                    ),
                    const SizedBox(height: 12.0),
                    const SizedBox(height: 12.0),
                    // Placeholder for social login buttons/icons if needed, based on SVG
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.center,
                    //   children: [
                    //     IconButton(onPressed: () {}, icon: Icon(Icons.apple)),
                    //     IconButton(onPressed: () {}, icon: Icon(Icons.facebook)),
                    //     IconButton(onPressed: () {}, icon: Icon(Icons.g_mobiledata)),
                    //   ],
                    // ),
                    const SizedBox(height: 24.0), // More space before registration link

                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RegistrationScreen(),
                          ),
                        );
                      },
                      child: const Text(
                        'У вас нет аккаунта?',
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ),

                    const SizedBox(height: 12.0), // More space before registration link

                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RegistrationScreen(),
                          ),
                        );
                      },
                      child: const Text(
                        'Зарегистрироваться',
                        style: TextStyle(
                          color: Colors.blue,
                          fontFamily: 'Roboto',
                        ), // Adjust link color 
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}