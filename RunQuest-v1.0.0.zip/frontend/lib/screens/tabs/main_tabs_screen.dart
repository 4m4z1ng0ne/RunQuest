import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:frontend/screens/main/home_content_screen.dart';

class MainTabsScreen extends StatefulWidget {
  final Map<String, dynamic>? profileData;
  final List<dynamic>? activeChallengesData;
  final VoidCallback? onStartRacePressed;

  const MainTabsScreen({
    Key? key,
    this.profileData,
    this.activeChallengesData,
    this.onStartRacePressed,
  }) : super(key: key);

  @override
  State<MainTabsScreen> createState() => _MainTabsScreenState();
}

class _MainTabsScreenState extends State<MainTabsScreen> {
  int _selectedIndex = 0; // Current selected tab index

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    // List of widgets to display for each tab
    final List<Widget> _widgetOptions = <Widget>[
      HomeContentScreen(
        profileData: widget.profileData,
        activeChallengesData: widget.activeChallengesData,
        onStartRacePressed: widget.onStartRacePressed,
      ),
      const Center(child: Text('Map Screen Placeholder')),
      const Center(child: Text('History Screen Placeholder')),
      const Center(child: Text('Settings Screen Placeholder')),
      const Center(child: Text('Profile Screen Placeholder')),
    ];

    return Scaffold(
      extendBody: true, // Allows the body to extend behind the bottom navigation bar
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.transparent, // Make background transparent
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)), // Rounded corners on top
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 0,
              blurRadius: 10,
              offset: const Offset(0, -5), // Shadow for depth
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          child: BottomNavigationBar(
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), // Adjust padding for the highlight
                  decoration: _selectedIndex == 0
                      ? BoxDecoration(
                          borderRadius: BorderRadius.circular(16), // Rounded corners for highlight
                          border: Border.all(color: const Color(0xFFD5FF2E), width: 2), // Neon green border
                        )
                      : null, // No decoration if not selected
                  child: SvgPicture.asset(
                    'static/icons/home_icon.svg',
                    colorFilter: ColorFilter.mode(
                        _selectedIndex == 0 ? const Color(0xFFD5FF2E) : Colors.grey, // Neon green if selected, grey otherwise
                        BlendMode.srcIn),
                    height: 24,
                  ),
                ),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: _selectedIndex == 1
                      ? BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD5FF2E), width: 2),
                        )
                      : null,
                  child: SvgPicture.asset(
                    'static/icons/map_icon.svg',
                    colorFilter: ColorFilter.mode(
                        _selectedIndex == 1 ? const Color(0xFFD5FF2E) : Colors.grey,
                        BlendMode.srcIn),
                    height: 24,
                  ),
                ),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: _selectedIndex == 2
                      ? BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD5FF2E), width: 2),
                        )
                      : null,
                  child: SvgPicture.asset(
                    'static/icons/history_icon.svg',
                    colorFilter: ColorFilter.mode(
                        _selectedIndex == 2 ? const Color(0xFFD5FF2E) : Colors.grey,
                        BlendMode.srcIn),
                    height: 24,
                  ),
                ),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: _selectedIndex == 3
                      ? BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD5FF2E), width: 2),
                        )
                      : null,
                  child: SvgPicture.asset(
                    'static/icons/settings_icon.svg',
                    colorFilter: ColorFilter.mode(
                        _selectedIndex == 3 ? const Color(0xFFD5FF2E) : Colors.grey,
                        BlendMode.srcIn),
                    height: 24,
                  ),
                ),
                label: '',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: _selectedIndex == 4
                      ? BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFD5FF2E), width: 2),
                        )
                      : null,
                  child: SvgPicture.asset(
                    'static/icons/profile_icon.svg',
                    colorFilter: ColorFilter.mode(
                        _selectedIndex == 4 ? const Color(0xFFD5FF2E) : Colors.grey,
                        BlendMode.srcIn),
                    height: 24,
                  ),
                ),
                label: '',
              ),
            ],
            currentIndex: _selectedIndex,
            selectedItemColor: Colors.transparent, // Hide default selected color
            unselectedItemColor: Colors.transparent, // Hide default unselected color
            onTap: _onItemTapped,
            backgroundColor: Colors.white, // White background for the bar itself
            elevation: 0, // No shadow
            type: BottomNavigationBarType.fixed, // Fixed type for more than 3 items
            showSelectedLabels: false, // Hide labels
            showUnselectedLabels: false, // Hide labels
          ),
        ),
      ),
    );
  }
} 