class SuggestedRoute {
  final String name;
  final String description;
  final List<List<double>> routePoints; // [[lat, lng], ...]
  final String? link;

  SuggestedRoute({
    required this.name,
    required this.description,
    required this.routePoints,
    this.link,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'route_points': routePoints,
      'link': link,
    };
  }
} 