import 'package:frontend/models/challenge.dart';
import 'package:flutter/material.dart'; // Import for @required and other annotations

class UserChallenge {
  final int id;
  final int userId;
  final Challenge challenge; // Nested Challenge object
  final double progress;
  final bool completed;
  final DateTime? updatedAt;
  final DateTime? completionDate;

  UserChallenge({
    required this.id,
    required this.userId,
    required this.challenge,
    required this.progress,
    required this.completed,
    this.updatedAt,
    this.completionDate,
  });

  factory UserChallenge.fromJson(Map<String, dynamic> json) {
    return UserChallenge(
      id: json['id'],
      userId: json['user'], // Assuming 'user' is the user ID
      challenge: Challenge.fromJson(json['challenge']), // Parse nested challenge
      progress: json['progress']?.toDouble() ?? 0.0,
      completed: json['completed'] ?? false,
      updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
      completionDate: json['completion_date'] != null ? DateTime.parse(json['completion_date']) : null,
    );
  }
} 