import 'package:frontend/models/user.dart';
import 'package:intl/intl.dart'; // For date formatting

class JointRunInvitationDisplayItem {
  final int id;
  final User sender;
  final User recipient;
  final String status;
  final DateTime? suggestedTime;
  final String? meetingLocation;
  final String? comments;
  final DateTime createdAt;
  final DateTime updatedAt;

  JointRunInvitationDisplayItem({
    required this.id,
    required this.sender,
    required this.recipient,
    required this.status,
    this.suggestedTime,
    this.meetingLocation,
    this.comments,
    required this.createdAt,
    required this.updatedAt,
  });

  factory JointRunInvitationDisplayItem.fromJson(Map<String, dynamic> json) {
    return JointRunInvitationDisplayItem(
      id: json['id'] as int,
      sender: User.fromJson(json['sender']),
      recipient: User.fromJson(json['recipient']),
      status: json['status'] as String,
      suggestedTime: json['suggested_time'] != null
          ? DateTime.parse(json['suggested_time'] as String).toLocal()
          : null,
      meetingLocation: json['meeting_location'] as String?,
      comments: json['comments'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String).toLocal(),
      updatedAt: DateTime.parse(json['updated_at'] as String).toLocal(),
    );
  }

  String get formattedSuggestedTime {
    if (suggestedTime == null) return 'Не указано';
    return DateFormat('dd.MM.yyyy HH:mm').format(suggestedTime!); // Format example: 01.01.2023 15:30
  }
} 