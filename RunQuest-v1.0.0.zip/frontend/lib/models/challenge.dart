import 'package:flutter/material.dart';

class Challenge {
  final int id;
  final String name;
  final String? description;
  final String challengeType;
  final double? targetValue;
  final String? unit;
  final DateTime? startDate;
  final DateTime? endDate;
  final bool isCompetitive;
  final int? relatedRacetrack; // Assuming int for ForeignKey ID
  final int xpReward;
  final bool isActive;

  Challenge({
    required this.id,
    required this.name,
    this.description,
    required this.challengeType,
    this.targetValue,
    this.unit,
    this.startDate,
    this.endDate,
    required this.isCompetitive,
    this.relatedRacetrack,
    required this.xpReward,
    required this.isActive,
  });

  factory Challenge.fromJson(Map<String, dynamic> json) {
    return Challenge(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      challengeType: json['challenge_type'],
      targetValue: json['target_value']?.toDouble(),
      unit: json['unit'],
      startDate: json['start_date'] != null ? DateTime.parse(json['start_date']) : null,
      endDate: json['end_date'] != null ? DateTime.parse(json['end_date']) : null,
      isCompetitive: json['is_competitive'],
      relatedRacetrack: json['related_racetrack'],
      xpReward: json['xp_reward'],
      isActive: json['is_active'],
    );
  }
} 