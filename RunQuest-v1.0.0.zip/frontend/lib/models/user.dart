class User {
  final int id;
  final String username;
  final int level;
  final int experience_points;
  final bool is_public;
  final bool show_runs;
  final bool show_achievements;

  User({
    required this.id,
    required this.username,
    required this.level,
    required this.experience_points,
    required this.is_public,
    required this.show_runs,
    required this.show_achievements,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    final profileJson = json['profile'] as Map<String, dynamic>?;

    return User(
      id: json['user_id'] ?? json['id'],
      username: json['username'] as String? ?? 'UNKNOWN_USER',
      level: profileJson?['level'] ?? json['level'] ?? 0,
      experience_points: profileJson?['experience_points'] ?? json['experience_points'] ?? 0,
      is_public: profileJson?['is_public'] ?? json['is_public'] ?? false,
      show_runs: profileJson?['show_runs'] ?? json['show_runs'] ?? false,
      show_achievements: profileJson?['show_achievements'] ?? json['show_achievements'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
        'level': level,
        'experience_points': experience_points,
        'is_public': is_public,
        'show_runs': show_runs,
        'show_achievements': show_achievements,
    };
  }
} 