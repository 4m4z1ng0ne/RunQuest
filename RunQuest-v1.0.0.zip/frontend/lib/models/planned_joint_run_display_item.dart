import 'package:frontend/models/user.dart';
import 'package:intl/intl.dart';

class PlannedJointRunDisplayItem {
  final int id;
  final List<String> participants;
  final DateTime? suggestedTime;
  final String? suggestedRacetrackName;
  final String? meetingLocation;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? actualStartTime;

  PlannedJointRunDisplayItem({
    required this.id,
    required this.participants,
    this.suggestedTime,
    this.suggestedRacetrackName,
    this.meetingLocation,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.actualStartTime,
  });

  factory PlannedJointRunDisplayItem.fromJson(Map<String, dynamic> json) {
    return PlannedJointRunDisplayItem(
      id: json['id'] as int,
      participants: List<String>.from(json['participants']),
      suggestedTime: json['suggested_time'] != null
          ? DateTime.parse(json['suggested_time'] as String).toLocal()
          : null,
      suggestedRacetrackName: json['suggested_racetrack_name'] as String?,
      meetingLocation: json['meeting_location'] as String?,
      status: json['status'] as String,
      createdAt: DateTime.parse(json['created_at'] as String).toLocal(),
      updatedAt: DateTime.parse(json['updated_at'] as String).toLocal(),
      actualStartTime: json['actual_start_time'] != null
          ? DateTime.parse(json['actual_start_time'] as String).toLocal()
          : null,
    );
  }

  String get formattedSuggestedTime {
    if (suggestedTime == null) return 'Не указано';
    return DateFormat('dd.MM.yyyy HH:mm').format(suggestedTime!); 
  }

  String get participantsText {
    if (participants.isEmpty) return 'Нет участников';
    return participants.join(', ');
  }
} 