import 'package:frontend/models/user.dart';

class FriendRequestDisplayItem {
  final int id; // ID объекта Friend (запроса на дружбу)
  final User user; // Информация о пользователе (отправитель или получатель)
 
  FriendRequestDisplayItem({required this.id, required this.user});
} 