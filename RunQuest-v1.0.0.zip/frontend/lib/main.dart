import 'package:flutter/material.dart';
import 'package:frontend/services/auth_service.dart'; // Import AuthService
import 'package:frontend/screens/auth/login_screen.dart'; // Import LoginScreen
import 'package:frontend/screens/main/main_screen.dart'; // Import MainScreen
import 'package:frontend/screens/auth/welcome_screen.dart'; // Import WelcomeScreen
// import 'package:frontend/screens/main/home_screen.dart'; // Import actual HomeScreen

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Use the singleton instance of AuthService
  final AuthService _authService = AuthService();
  // bool _isAuthenticated = false; // No longer directly used for initial check
  // bool _isLoading = true; // Handled by FutureBuilder

  // Removed initState and _checkAuthStatus method as FutureBuilder handles initial check

  @override
  void dispose() {
    // Dispose of the map controller if it's still being held onto (though likely disposed by screens)
    // _mapController.dispose(); // No longer have _mapController here
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('MyApp build called.');

    // MaterialApp should be the root widget to provide necessary context like Directionality
    return MaterialApp(
      title: 'RunQuest',
      theme: ThemeData(
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.green,
          accentColor: Colors.limeAccent[700],
          backgroundColor: Colors.white,
          cardColor: Colors.grey[50],
        ).copyWith(
          secondary: Colors.limeAccent[700],
          onPrimary: Colors.black,
          onSecondary: Colors.black,
          onBackground: Colors.black,
          onSurface: Colors.black,
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          displayMedium: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          displaySmall: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          headlineLarge: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          headlineMedium: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          headlineSmall: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          titleLarge: TextStyle(color: Colors.black, fontFamily: 'Satoshi', fontWeight: FontWeight.bold),
          titleMedium: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          titleSmall: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          bodyLarge: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          bodyMedium: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          bodySmall: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          labelLarge: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          labelMedium: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
          labelSmall: TextStyle(color: Colors.black, fontFamily: 'Satoshi'),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'Satoshi',
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.limeAccent[700],
            foregroundColor: Colors.black,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            textStyle: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: 'Satoshi',
            ),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.green[700],
            textStyle: const TextStyle(
              fontSize: 16,
              fontFamily: 'Satoshi',
            ),
          ),
        ),
        scaffoldBackgroundColor: Colors.white,
      ),
      // Always show WelcomeScreen as the initial screen
      home: const WelcomeScreen(),
    );
  }
}

// Removed the placeholder HomeScreen widget.

// Define your screen widgets
// Make sure these screens are correctly implemented and handle their dependencies
// appropriately (e.g., accessing AuthService singleton).

// Example of how a screen might use AuthService:
// final AuthService _authService = AuthService();
// User? currentUser = _authService.currentUser;
