import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ActivityFeedService {
  final Dio _dio = Dio();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final String baseUrl = 'http://192.168.0.123:8000/api'; // TODO: заменить на актуальный URL

  Future<Response> getActivityFeed() async {
    final token = await _storage.read(key: 'access_token');
    return await _dio.get(
      '$baseUrl/activity-feed/',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );
  }

  Future<Response> getAllAchievements() async {
    final token = await _storage.read(key: 'access_token');
    return await _dio.get(
      '$baseUrl/achievements/',
      options: Options(
        headers: {'Authorization': 'Bearer $token'},
      ),
    );
  }
} 