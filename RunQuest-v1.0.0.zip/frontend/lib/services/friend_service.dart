import 'package:frontend/models/user.dart';
import 'package:frontend/services/auth_service.dart'; // For getting the token
import 'package:dio/dio.dart'; // Import Dio
import 'package:frontend/models/friend_request_display_item.dart';
import 'package:frontend/models/joint_run_invitation_display_item.dart'; // Import new model
import 'package:frontend/models/planned_joint_run_display_item.dart'; // Import new model for planned joint runs
import 'package:flutter/material.dart';

class FriendService {
  final String _baseUrl = 'http://192.168.0.123:8000/api'; // Добавляем порт :8000

  Future<List<User>> fetchFriends() async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/friends/').toString(),
      );

      if (response.statusCode == 200) {
        final currentUserId = AuthService().currentUser?.id; // Получаем ID текущего пользователя

        if (currentUserId == null) {
          throw Exception('Current user ID not available.');
        }

        if (response.data is Map && response.data.containsKey('results')) {
          List jsonResponse = response.data['results'];
          return jsonResponse.map((friendship) {
            // Определяем, кто из from_user или to_user является другом для текущего пользователя
            if (friendship['from_user']['id'] == currentUserId) {
              return User.fromJson(friendship['to_user']);
            } else {
              return User.fromJson(friendship['from_user']);
            }
          }).toList();
        } else {
          List jsonResponse = response.data;
          return jsonResponse.map((friendship) {
            // Определяем, кто из from_user или to_user является другом для текущего пользователя
            if (friendship['from_user']['id'] == currentUserId) {
              return User.fromJson(friendship['to_user']);
            } else {
              return User.fromJson(friendship['from_user']);
            }
          }).toList();
        }
      } else {
        throw Exception('Failed to load friends: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to load friends: ${e.message}');
    }
  }

  Future<List<User>> searchUsers(String query) async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/users/search/?q=$query').toString(),
      );

      if (response.statusCode == 200) {
        // Обрабатываем пагинированный ответ
        // Проверяем, является ли ответ Map и содержит ли ключ 'results'
        if (response.data is Map && response.data.containsKey('results')) {
          List jsonResponse = response.data['results'];
          return jsonResponse.map((user) => User.fromJson(user)).toList();
        } else {
          // Если ответ не соответствует ожидаемой структуре пагинации, обрабатываем как обычный список
          List jsonResponse = response.data; // Предполагаем, что это уже список
          return jsonResponse.map((user) => User.fromJson(user)).toList();
        }
      } else {
        throw Exception('Failed to search users: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to search users: ${e.message}');
    }
  }

  Future<void> sendFriendRequest(int userId) async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/friends/').toString(), // Изменяем URL на /api/friends/
        data: {'to_user': userId}, // Dio автоматически кодирует Map в JSON
      );

      if (response.statusCode != 201) {
        throw Exception('Failed to send friend request: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.response != null && e.response!.statusCode == 400) {
        // Проверяем, есть ли в ответе сообщение об ошибке
        if (e.response!.data != null && e.response!.data is Map && e.response!.data.containsKey('detail')) {
          throw Exception('Failed to send friend request: ${e.response!.data['detail']}');
        } else {
          throw Exception('Failed to send friend request: Bad Request (400)');
        }
      } else {
        throw Exception('Failed to send friend request: ${e.message}');
      }
    }
  }

  Future<List<FriendRequestDisplayItem>> fetchPendingFriendRequests() async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/friends/pending_requests/').toString(),
      );

      print('DEBUG: fetchPendingFriendRequests response: ${response.data}'); // Отладочный вывод

      if (response.statusCode == 200) {
        if (response.data is Map && response.data.containsKey('results')) {
          List jsonResponse = response.data['results'];
          // Извлекаем from_user из каждого объекта Friend
          return jsonResponse.map((friendRequest) => FriendRequestDisplayItem(
            id: friendRequest['id'],
            user: User.fromJson(friendRequest['from_user']),
          )).toList();
        } else {
          List jsonResponse = response.data;
          return jsonResponse.map((friendRequest) => FriendRequestDisplayItem(
            id: friendRequest['id'],
            user: User.fromJson(friendRequest['from_user']),
          )).toList();
        }
      } else {
        throw Exception('Failed to load pending friend requests: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to load pending friend requests: ${e.message}');
    }
  }

  Future<List<FriendRequestDisplayItem>> fetchSentFriendRequests() async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/friends/sent_requests/').toString(),
      );

      print('DEBUG: fetchSentFriendRequests response: ${response.data}'); // Отладочный вывод

      if (response.statusCode == 200) {
        if (response.data is Map && response.data.containsKey('results')) {
          List jsonResponse = response.data['results'];
          // Извлекаем to_user из каждого объекта Friend
          return jsonResponse.map((friendRequest) => FriendRequestDisplayItem(
            id: friendRequest['id'],
            user: User.fromJson(friendRequest['to_user']),
          )).toList();
        } else {
          List jsonResponse = response.data;
          return jsonResponse.map((friendRequest) => FriendRequestDisplayItem(
            id: friendRequest['id'],
            user: User.fromJson(friendRequest['to_user']),
          )).toList();
        }
      } else {
        throw Exception('Failed to load sent friend requests: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to load sent friend requests: ${e.message}');
    }
  }

  Future<void> acceptFriendRequest(int requestId) async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/friends/$requestId/accept/').toString(),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to accept friend request: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to accept friend request: ${e.message}');
    }
  }

  Future<void> rejectFriendRequest(int requestId) async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/friends/$requestId/reject/').toString(),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to reject friend request: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to reject friend request: ${e.message}');
    }
  }

  Future<void> cancelSentFriendRequest(int requestId) async {
    // Токен будет добавлен интерцептором AuthService().dio
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/friends/$requestId/cancel_sent/').toString(),
      );

      if (response.statusCode != 204) { // 204 No Content for successful deletion
        throw Exception('Failed to cancel friend request: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to cancel friend request: ${e.message}');
    }
  }

  // New methods for Joint Run Invitations
  Future<void> sendJointRunInvitation({
    required int invitedUserId,
    required DateTime scheduledAt,
    required String location,
    String? comments,
  }) async {
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/joint-run-invitations/').toString(),
        data: {
          'recipient_id': invitedUserId,
          'suggested_time': scheduledAt.toUtc().toIso8601String(), // Convert to UTC ISO 8601 string
          'meeting_location': location,
          'comments': comments,
        },
      );
      if (response.statusCode != 201) {
        throw Exception('Failed to send joint run invitation: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.response != null && e.response!.data != null && e.response!.data is Map && e.response!.data.containsKey('detail')) {
        throw Exception('Failed to send joint run invitation: ${e.response!.data['detail']}');
      } else {
        throw Exception('Failed to send joint run invitation: ${e.message}');
      }
    }
  }

  Future<List<JointRunInvitationDisplayItem>> fetchReceivedJointRunInvitations() async {
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/joint-run-invitations/').toString(),
        queryParameters: {'status': 'pending', 'type': 'received'}, // Filter for pending invitations
      );
      print('DEBUG: fetchReceivedJointRunInvitations response.statusCode: ${response.statusCode}');
      print('DEBUG: fetchReceivedJointRunInvitations response.data.runtimeType: ${response.data.runtimeType}');
      print('DEBUG: fetchReceivedJointRunInvitations response.data: ${response.data}');

      if (response.statusCode == 200) {
        if (response.data is Map && response.data.containsKey('results')) {
          final dynamic resultsData = response.data['results'];
          print('DEBUG: fetchReceivedJointRunInvitations resultsData.runtimeType: ${resultsData.runtimeType}');
          print('DEBUG: fetchReceivedJointRunInvitations resultsData: $resultsData');
          if (resultsData is List) {
            return resultsData.map((invitation) => JointRunInvitationDisplayItem.fromJson(invitation)).toList();
          } else {
            print('Warning: results field is not a List in fetchReceivedJointRunInvitations. Type: ${resultsData.runtimeType}, Data: $resultsData');
            return [];
          }
        } else if (response.data is List) {
          print('DEBUG: fetchReceivedJointRunInvitations response.data is List (non-paginated)');
          return (response.data as List).map((invitation) => JointRunInvitationDisplayItem.fromJson(invitation)).toList();
        } else {
          print('Warning: Unexpected top-level format for received joint run invitations API response. Data: ${response.data}');
          return [];
        }
      } else {
        throw Exception('Failed to load received joint run invitations: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      // Re-throw the actual error to be caught by the UI
      throw Exception('Failed to load received joint run invitations: ${e.message}');
    } catch (e) {
      throw Exception('Error parsing received joint run invitations: $e');
    }
  }

  Future<List<JointRunInvitationDisplayItem>> fetchSentJointRunInvitations() async {
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/joint-run-invitations/').toString(),
        queryParameters: {'status': 'pending', 'type': 'sent'}, // <-- Убедитесь, что 'type': 'sent' здесь
      );
      print('DEBUG: fetchSentJointRunInvitations response.statusCode: ${response.statusCode}');
      print('DEBUG: fetchSentJointRunInvitations response.data.runtimeType: ${response.data.runtimeType}');
      print('DEBUG: fetchSentJointRunInvitations response.data: ${response.data}');
      if (response.statusCode == 200) {
        if (response.data is Map && response.data.containsKey('results')) {
          final dynamic resultsData = response.data['results'];
          print('DEBUG: fetchSentJointRunInvitations resultsData.runtimeType: ${resultsData.runtimeType}');
          print('DEBUG: fetchSentJointRunInvitations resultsData: $resultsData');
          if (resultsData is List) {
            return resultsData.map((invitation) => JointRunInvitationDisplayItem.fromJson(invitation)).toList();
          } else {
            print('Warning: results field is not a List in fetchSentJointRunInvitations. Type: ${resultsData.runtimeType}, Data: $resultsData');
            return [];
          }
        } else if (response.data is List) {
          print('DEBUG: fetchSentJointRunInvitations response.data is List (non-paginated)');
          return (response.data as List).map((invitation) => JointRunInvitationDisplayItem.fromJson(invitation)).toList();
        } else {
          print('Warning: Unexpected top-level format for sent joint run invitations API response. Data: ${response.data}');
          return [];
        }
      } else {
        throw Exception('Failed to load sent joint run invitations: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to load sent joint run invitations: ${e.message}');
    } catch (e) {
      throw Exception('Error parsing sent joint run invitations: $e');
    }
  }

  Future<void> acceptJointRunInvitation(int invitationId) async {
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/joint-run-invitations/$invitationId/accept/').toString(),
      );
      if (response.statusCode != 200) {
        throw Exception('Failed to accept joint run invitation: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.response != null && e.response!.data != null && e.response!.data.containsKey('detail')) {
        throw Exception('Failed to accept joint run invitation: ${e.response!.data['detail']}');
      } else {
        throw Exception('Failed to accept joint run invitation: ${e.message}');
      }
    }
  }

  Future<void> rejectJointRunInvitation(int invitationId) async {
    try {
      final response = await AuthService().dio.post(
        Uri.parse('$_baseUrl/joint-run-invitations/$invitationId/reject/').toString(),
      );
      if (response.statusCode != 200) {
        throw Exception('Failed to reject joint run invitation: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.response != null && e.response!.data != null && e.response!.data.containsKey('detail')) {
        throw Exception('Failed to reject joint run invitation: ${e.response!.data['detail']}');
      } else {
        throw Exception('Failed to reject joint run invitation: ${e.message}');
      }
    }
  }

  Future<void> cancelJointRunInvitation(int invitationId) async {
    try {
      await AuthService().dio.post(
        Uri.parse('$_baseUrl/joint-run-invitations/$invitationId/cancel/').toString(),
      );
    } on DioException catch (e) {
      throw Exception('Failed to cancel joint run invitation: ${e.message}');
    }
  }

  Future<void> removeFriend(int friendshipId) async {
    try {
      final response = await AuthService().dio.delete(
        Uri.parse('$_baseUrl/friends/$friendshipId/').toString(),
      );

      if (response.statusCode != 204) {
        throw Exception('Failed to remove friend: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.response != null && e.response!.data != null && e.response!.data.containsKey('detail')) {
        throw Exception('Failed to remove friend: ${e.response!.data['detail']}');
      } else {
        throw Exception('Failed to remove friend: ${e.message}');
      }
    }
  }

  // New method to fetch planned joint runs
  Future<List<PlannedJointRunDisplayItem>> fetchPlannedJointRuns() async {
    try {
      final response = await AuthService().dio.get(
        Uri.parse('$_baseUrl/planned-joint-runs/').toString(),
      );
      if (response.statusCode == 200) {
        if (response.data is Map && response.data.containsKey('results')) {
          List jsonResponse = response.data['results'];
          return jsonResponse.map((data) => PlannedJointRunDisplayItem.fromJson(data)).toList();
        } else {
          List jsonResponse = response.data;
          return jsonResponse.map((data) => PlannedJointRunDisplayItem.fromJson(data)).toList();
        }
      } else {
        throw Exception('Failed to load planned joint runs: Status ${response.statusCode}');
      }
    } on DioException catch (e) {
      throw Exception('Failed to load planned joint runs: ${e.message}');
    }
  }
}