import 'package:dio/dio.dart';
import 'package:frontend/models/suggested_route.dart';
import 'auth_service.dart';

class SuggestedRouteService {
  final AuthService _authService = AuthService();

  Future<void> sendSuggestedRoute(SuggestedRoute route) async {
    final dio = _authService.dio;
    final baseUrl = _authService.baseUrl;
    try {
      final response = await dio.post(
        '$baseUrl/suggested-routes/',
        data: route.toJson(),
      );
      if (response.statusCode == 201) {
        print('Маршрут успешно отправлен!');
      } else {
        print('Ошибка при отправке маршрута: ${response.statusCode}');
        throw Exception('Ошибка при отправке маршрута');
      }
    } catch (e) {
      print('Ошибка при отправке маршрута: $e');
      rethrow;
    }
  }
} 