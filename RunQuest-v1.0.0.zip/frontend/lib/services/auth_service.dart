//auth_service.dart
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:io';
import 'package:frontend/models/user.dart'; // Import User model
import 'package:latlong2/latlong.dart'; // Import LatLng
import 'package:shared_preferences/shared_preferences.dart'; // Import SharedPreferences
// import 'package:stack_trace/stack_trace.dart'; // Optional for detailed stack trace logging

class AuthService {
  // --- Singleton Setup ---
  static final AuthService _instance = AuthService._internal();

  factory AuthService() {
    return _instance;
  }

  AuthService._internal() {
    // Configure Dio interceptors
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        // Add access token to requests if available
        String? accessToken = await getAccessToken();
        if (accessToken != null) {
          options.headers['Authorization'] = 'Bearer $accessToken';
        }
        print('AuthService Interceptor: Request to ${options.path}'); // Log запроса
        if (options.headers['Authorization'] != null) {
          print('AuthService Interceptor: Authorization header present.');
        } else {
          print('AuthService Interceptor: Authorization header MISSING.');
        }
        return handler.next(options);
      },
      onResponse: (response, handler) {
        print('AuthService Interceptor: Response from ${response.requestOptions.path}, Status: ${response.statusCode}'); // Лог ответа
        return handler.next(response);
      },
      onError: (DioException error, handler) async {
        print('AuthService Interceptor: Error on ${error.requestOptions.path}, Status: ${error.response?.statusCode}'); // Лог ошибки
        // Handle token expiration and refresh
        if (error.response?.statusCode == 401) {
          print('AuthService Interceptor: Received 401, attempting token refresh.');
          // Attempt to refresh token
          String? refreshToken = await getRefreshToken();
          if (refreshToken != null) {
            try {
              // Perform token refresh request using a separate Dio instance
              Dio refreshDio = Dio(BaseOptions(
                connectTimeout: const Duration(milliseconds: 10000),
                receiveTimeout: const Duration(milliseconds: 3000),
              ));
              Response response = await refreshDio.post( // Используем refreshDio
                '$baseUrl/token/refresh/',
                data: {'refresh': refreshToken},
              );

              if (response.statusCode == 200) {
                print('AuthService Interceptor: Token refresh successful.');
                // Save new tokens
                String newAccessToken = response.data['access'];
                // Django Rest Framework Simple JWT might not return a new refresh token every time (ROTATE_REFRESH_TOKENS)
                String newRefreshToken = response.data['refresh'] ?? refreshToken; // Use old one if new one not returned

                await _saveTokens(newAccessToken, newRefreshToken);

                // Retry the original request with the new access token
                error.requestOptions.headers['Authorization'] = 'Bearer $newAccessToken';
                print('AuthService Interceptor: Retrying original request with new token.');
                // Clone requestOptions to avoid issues with DefaultTransformer
                final newOptions = Options(
                  method: error.requestOptions.method,
                  headers: error.requestOptions.headers,
                  extra: error.requestOptions.extra,
                  responseType: error.requestOptions.responseType,
                  contentType: error.requestOptions.contentType,
                  validateStatus: error.requestOptions.validateStatus,
                  receiveDataWhenStatusError: error.requestOptions.receiveDataWhenStatusError,
                  followRedirects: error.requestOptions.followRedirects,
                  maxRedirects: error.requestOptions.maxRedirects,
                  requestEncoder: error.requestOptions.requestEncoder,
                  responseDecoder: error.requestOptions.responseDecoder,
                );
                // Use the main _dio instance for the retried request
                return handler.resolve(await _dio.request(
                  error.requestOptions.path,
                  options: newOptions,
                  data: error.requestOptions.data,
                  queryParameters: error.requestOptions.queryParameters,
                  cancelToken: error.requestOptions.cancelToken,
                  onReceiveProgress: error.requestOptions.onReceiveProgress,
                  onSendProgress: error.requestOptions.onSendProgress,
                ));

              } else {
                // If refresh request didn't return 200 but also didn't throw (unlikely for Dio)
                print('AuthService Interceptor: Token refresh request failed with status ${response.statusCode}. Logging out.');
                await logout();
                return handler.reject(error);
              }
            } catch (e) {
              // Refresh failed, log out user
              print('AuthService Interceptor: Token refresh failed with exception: $e. Logging out.');
              await logout(); // Implement logout
              return handler.reject(error); // Reject the original DioError
            }
          } else {
             print('AuthService Interceptor: No refresh token found. Logging out.');
             await logout(); // No refresh token, logout
             return handler.reject(error); // Reject original error
          }
        }
        return handler.next(error); // Continue with the error
      },
    ));
  }
  // --- End Singleton Setup ---


  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(milliseconds: 10000),
    receiveTimeout: const Duration(milliseconds: 3000),
  ));
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  // Key for SharedPreferences to indicate if user was ever logged in
  final String _loggedInKey = 'user_logged_in';

  // Base URL for your backend API
  final String baseUrl = 'http://192.168.0.123:8000/api'; //10.3.225.198 192.168.0.123
  //final String baseUrl = 'http://127.0.0.1:8000/api'; // TODO: Replace with your actual backend URL
  // Keys for storing tokens securely
  final String _accessTokenKey = 'access_token';
  final String _refreshTokenKey = 'refresh_token';

  User? _currentUser; // Field to store current authenticated user

  // Getter for current user
  User? get currentUser => _currentUser;

  // Public getter for Dio instance
  Dio get dio => _dio;

  // --- Token Management ---

  Future<void> _saveTokens(String accessToken, String refreshToken) async {
    await _storage.write(key: _accessTokenKey, value: accessToken);
    await _storage.write(key: _refreshTokenKey, value: refreshToken);
    // Set SharedPreferences flag after successful login
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_loggedInKey, true);
    print('AuthService._saveTokens: Tokens saved and logged_in flag set.');
  }

  Future<String?> getAccessToken() async {
    String? token = await _storage.read(key: _accessTokenKey);
    // print('AuthService._getAccessToken() returned: $token'); // Можно раскомментировать для детального логгирования
    return token;
  }

  Future<String?> getRefreshToken() async {
    String? token = await _storage.read(key: _refreshTokenKey);
    // print('AuthService._getRefreshToken() returned: $token'); // Можно раскомментировать для детального логгирования
    return token;
  }

  Future<void> deleteTokens() async {
    print('AuthService.deleteTokens() called.'); // Add logging
    // if (Trace.current().frames.length > 1) {
    //   print('deleteTokens triggered from: ${Trace.current().frames[1]}'); // Shows who called deleteTokens
    // }
    await _storage.delete(key: _accessTokenKey);
    await _storage.delete(key: _refreshTokenKey);
    _currentUser = null; // Clear current user on token deletion
    // Clear SharedPreferences flag on logout
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_loggedInKey, false);
    print('AuthService.deleteTokens() finished. Current user cleared and logged_in flag cleared.'); // Add logging
  }

  // New method to check if user was ever logged in using SharedPreferences
  Future<bool> wasUserLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    bool isLoggedIn = prefs.getBool(_loggedInKey) ?? false; // Default to false if key not found
    print('AuthService.wasUserLoggedIn() returned: $isLoggedIn');
    return isLoggedIn;
  }

  Future<bool> hasTokens() async {
    print('AuthService.hasTokens() called.'); // Add logging
    String? accessToken = await getAccessToken();
    String? refreshToken = await getRefreshToken();
    bool result = accessToken != null && refreshToken != null;
    print('AuthService.hasTokens() - AccessToken: ${accessToken != null ? "present" : "null"}, RefreshToken: ${refreshToken != null ? "present" : "null"}'); // Логгирование наличия токенов
    print('AuthService.hasTokens() result: $result'); // Add logging
    return result;
  }

  // --- Authentication Methods ---

  Future<String?> login(String username, String password) async {
    try {
      Response response = await _dio.post(
        '$baseUrl/token/',
        data: {'username': username, 'password': password},
      );

      if (response.statusCode == 200) {
        String accessToken = response.data['access'];
        String refreshToken = response.data['refresh'];
        await _saveTokens(accessToken, refreshToken);
        print('AuthService.login: Login successful, tokens saved.');
        // Fetch and set current user profile after successful login
        await _fetchAndSetCurrentUser();

        return null;
      } else {
        // Handle other status codes (e.g., 401 for invalid credentials)
        print('Login failed: ${response.statusCode}');
        if (response.data != null && response.data.containsKey('detail')) {
             print('Login failed response data: ${response.data}');
             return response.data['detail'];
        }
        return 'Неизвестная ошибка входа.';
      }
    } on DioException catch (e) {
      print('Login error: ${e.message}');
      if (e.response != null && e.response!.data != null && e.response!.data.containsKey('detail')) {
        print('Login error response data: ${e.response?.data}');
        return e.response!.data['detail'];
      }
      return 'Произошла ошибка сети или сервера.';
    }
  }

  Future<String?> register(String username, String email, String password) async {
     try {
       Response response = await _dio.post(
         '$baseUrl/register/',
         data: {'username': username, 'email': email, 'password': password},
       );

       if (response.statusCode == 201) {
         print('AuthService.register: Registration successful.');
         return null; // Return null on success
       } else {
         print('Registration failed: ${response.statusCode} ${response.data}');
         // Try to extract a specific error message from the response
         if (response.data != null && response.data.containsKey('detail')) {
           return response.data['detail'];
         }
         // For Django REST Framework's default UserRegistrationSerializer, errors might be in field-specific maps
         if (response.data != null && response.data.containsKey('username')) {
           return 'Логин: ${response.data['username'][0]}'; // Assuming first error message
         }
         if (response.data != null && response.data.containsKey('email')) {
           return 'Email: ${response.data['email'][0]}'; // Assuming first error message
         }
         if (response.data != null && response.data.containsKey('password')) {
           return 'Пароль: ${response.data['password'][0]}'; // Assuming first error message
         }
         return 'Ошибка регистрации.'; // Generic error
       }
     } on DioException catch (e) {
        print('Registration error: ${e.message}');
        if (e.response != null && e.response!.data != null) {
          if (e.response!.data.containsKey('detail')) {
            return e.response!.data['detail'];
          }
          if (e.response!.data.containsKey('username')) {
            return 'Логин: ${e.response!.data['username'][0]}';
          }
          if (e.response!.data.containsKey('email')) {
            return 'Email: ${e.response!.data['email'][0]}';
        }
          if (e.response!.data.containsKey('password')) {
            return 'Пароль: ${e.response!.data['password'][0]}';
          }
        }
        return 'Произошла ошибка сети или сервера.';
     }
  }

  Future<void> logout() async {
    print('Logging out user...');
    // TODO: Invalidate token on backend if needed (e.g., add refresh token to blacklist)
    // try {
    //   String? refreshToken = await _getRefreshToken();
    //   if (refreshToken != null) {
    //     await _dio.post('$baseUrl/logout/', data: {'refresh_token': refreshToken}); // Пример эндпоинта
    //   }
    // } catch (e) {
    //   print('Error invalidating token on backend: $e');
    // }
    await deleteTokens(); // This will now clear _currentUser as well
    print('AuthService.logout: User logged out. Tokens deleted.');
  }

  // --- User Data Methods ---

  Future<void> _fetchAndSetCurrentUser() async {
      if (!(await hasTokens())) { // Check if tokens still exist before fetching profile
          print('AuthService._fetchAndSetCurrentUser: No tokens, cannot fetch profile.');
          _currentUser = null;
          // If we can't fetch user but there's a flag, it might indicate token issue. Clear flag?
          final prefs = await SharedPreferences.getInstance();
          // await prefs.setBool(_loggedInKey, false); // This is now handled by deleteTokens and loadUserSession
          print('AuthService._fetchAndSetCurrentUser: Current user cleared.');
          return;
      }
      try {
          final profileResponse = await getProfile(); // Fetch current user's profile
           if (profileResponse.statusCode == 200) {
                _currentUser = User.fromJson(profileResponse.data);
                print('AuthService._fetchAndSetCurrentUser: User profile fetched and set: ${_currentUser?.username}');
           } else {
               print('Failed to fetch current user profile after auth: ${profileResponse.statusCode}');
               // Keep tokens but clear user if profile fetch fails (might be temporary issue)
               _currentUser = null;
           }
      } catch (e) {
          print('Error fetching current user profile after auth: $e');
          // If it's a 401, the interceptor should handle logout.
          // For other errors, keep tokens but clear user for safety.
          if (e is DioException && e.response?.statusCode == 401) {
             // Interceptor handles this
          } else {
             _currentUser = null;
          }
      }
  }

  Future<void> refreshCurrentUser() async {
    await _fetchAndSetCurrentUser();
  }

  // --- API Call Methods (using the singleton _dio instance) ---
  // These methods no longer need to explicitly read tokens or set Authorization headers
  // as the interceptor handles it automatically.

  Future<Response> getProfile({int? userId}) async {
    final url = userId == null ? '$baseUrl/profile/' : '$baseUrl/user-profiles/$userId/';
    return await _dio.get(url);
  }

  Future<Response> getUserAchievements({int? userId}) async {
    try {
      final response = await _dio.get(
        '$baseUrl/user-achievements/',
        queryParameters: userId != null ? {'user_id': userId} : null,
      );
      return response;
    } on DioException catch (e) {
      if (e.response != null && e.response!.statusCode == 403) {
        // Specific handling for 403 (Permission Denied)
        return Response(
          requestOptions: e.requestOptions,
          statusCode: 403,
          data: {'profile_access_denied': true, 'message': 'У вас нет доступа к достижениям этого пользователя.'},
        );
      }
      rethrow; // Re-throw other DioErrors
    }
  }

  Future<Response> getUserChallenges({int? userId}) async {
    try {
      final response = await _dio.get(
        '$baseUrl/user-challenges/',
        queryParameters: userId != null ? {'user_id': userId} : null,
      );
      return response;
    } on DioException catch (e) {
      if (e.response != null && e.response!.statusCode == 403) {
        return Response(
          requestOptions: e.requestOptions,
          statusCode: 403,
          data: {'profile_access_denied': true, 'message': 'У вас нет доступа к челленджам этого пользователя.'},
        );
      }
      rethrow;
    }
  }

  Future<Response> getUserRuns({int? userId}) async {
    final url = userId == null ? 
                '$baseUrl/runs/' : 
                '$baseUrl/runs/?user_id=$userId';
    try {
      print('AuthService.getUserRuns() called.'); // Debug print
      Response response = await _dio.get(url);
      return response;
    } on DioException catch (e) {
      print('Error fetching user runs: ${e.message}');
      rethrow;
    }
  }

  Future<Response> getRunDetail(int runId) async {
    return await _dio.get('$baseUrl/runs/$runId/');
  }

  Future<Response> updateProfile(Map<String, dynamic> profileData, {File? avatarFile}) async {
    final String url = '$baseUrl/profile/';
    FormData formData = FormData.fromMap(profileData);
    if (avatarFile != null) {
      formData.files.add(MapEntry(
        'avatar',
        await MultipartFile.fromFile(avatarFile.path, filename: avatarFile.path.split('/').last),
      ));
    }
    return await _dio.patch(
      url,
      data: formData,
      // Dio will set Content-Type for FormData automatically
    );
  }

  Future<Response> sendFriendRequest(int recipientId) async {
    print('[AuthService][sendFriendRequest] Attempting to send friend request to recipientId: $recipientId');
    print('[AuthService][sendFriendRequest] Making POST request to $baseUrl/friends/');
    return await _dio.post( // Removed explicit Options
      '$baseUrl/friends/',
        data: {'to_user': recipientId},
    );
    }

  Future<Response> getFriendshipStatus(int targetUserId) async {
    return await _dio.get(
      '$baseUrl/friends/friendship_status/?user_id=$targetUserId',
    );
  }

  Future<Response> acceptFriendRequest(int friendshipId) async {
    return await _dio.post(
      '$baseUrl/friends/$friendshipId/accept/',
    );
  }

  Future<Response> removeFriend(int friendshipId) async {
    return await _dio.delete(
      '$baseUrl/friends/$friendshipId/',
    );
  }

  Future<Response> cancelFriendRequest(int friendshipId) async {
    return await _dio.post(
      '$baseUrl/friends/$friendshipId/cancel_sent/',
    );
  }

  Future<Response> getMyFriends() async {
    return await _dio.get(
      '$baseUrl/friends/my_friends/',
    );
  }

  Future<Response> getIncomingFriendRequests() async {
    return await _dio.get(
      '$baseUrl/friends/pending_requests/',
    );
  }

  Future<Response> getAllFriendships() async {
    return await _dio.get(
      '$baseUrl/friends/',
    );
  }

  Future<Response> rejectFriendRequest(int friendshipId) async {
    return await _dio.post(
      '$baseUrl/friends/$friendshipId/reject/',
    );
  }

  Future<Response> searchUsers(String query) async {
    return await _dio.get(
      '$baseUrl/user-search/',
      queryParameters: {'username': query},
    );
  }

  Future<Response> getAllChallenges() async {
    try {
      print('AuthService.getAllChallenges() called.'); // Debug print
      Response response = await _dio.get('$baseUrl/challenges/');
      return response;
    } on DioException catch (e) {
      print('Error fetching all challenges: ${e.message}');
      // Propagate the error or return a response indicating failure
      rethrow; // Rethrow the exception
    }
  }

  Future<Response> getRaceTrackStartPoints() async {
    final url = '$baseUrl/race-tracks/start_points/';
    return await _dio.get(url);
  }

  Future<Response> getAllRaceTracks() async {
    final url = '$baseUrl/race-tracks/';
    return await _dio.get(url);
  }

  Future<Map<String, dynamic>?> sendRaceResults(int trackId, int durationSeconds, double distanceCovered, List<LatLng> routePoints) async {
    final url = '$baseUrl/race/finish/';

    final List<List<double>> routeCoords = routePoints.map((latlng) => [latlng.longitude, latlng.latitude]).toList();

    try { // Add try-catch block
      final response = await _dio.post( // Make the request
      url,
      data: {
        'track_id': trackId,
        'duration_seconds': durationSeconds,
          'distance_covered_km': distanceCovered,
          'route_definition': {
          'type': 'LineString',
          'coordinates': routeCoords,
        },
      },
      );

      if (response.statusCode == 201) {
        print('Race results sent successfully!');
        // After successfully sending race results, fetch updated user profile
        await _fetchAndSetCurrentUser();
        return {
          'attemptId': response.data['id'],
          'xpEarned': response.data['xp_earned'],
          'achievementsEarned': response.data['earned_achievements'],
          'challengesCompleted': response.data['completed_challenges'],
          'isRecordBroken': response.data['is_record_broken'],
        };
      } else {
        print('Failed to send race results: ${response.statusCode}');
        // TODO: Show error message to user
        return null; // Return null on failure
      }
    } on DioException catch (e) { // Catch Dio errors
      print('Error sending race results: $e');
       if (e.response != null) {
         print('Error response data: ${e.response?.data}');
       }
      // TODO: Show error message to user
      return null; // Return null on error
    } catch (e) { // Catch other potential errors
      print('An unexpected error occurred while sending race results: $e');
      // TODO: Show error message to user
      return null; // Return null on unexpected error
    }
  }

  // New method to publish a race attempt to the activity feed
  Future<bool> publishRaceAttempt(int attemptId) async {
    final url = '$baseUrl/user-race-attempts/$attemptId/publish_result/';

    try {
      final response = await _dio.post(url);

      if (response.statusCode == 200) {
        print('Race attempt $attemptId published successfully!');
        return true;
      } else {
        print('Failed to publish race attempt $attemptId: ${response.statusCode}');
        if (response.data != null) {
          print('Error response data: ${response.data}');
        }
        return false;
      }
    } on DioException catch (e) {
      print('Error publishing race attempt $attemptId: $e');
      if (e.response != null) {
        print('Error response data: ${e.response?.data}');
      }
      return false;
    }
  }

  // New method to send training results
  Future<Map<String, dynamic>?> sendTrainingResults(int durationSeconds, double distanceMeters, List<LatLng> recordedRoute) async {
    final url = '$baseUrl/runs/';

    final List<List<double>> routeCoords = recordedRoute.map((latlng) => [latlng.longitude, latlng.latitude]).toList();

    try {
      final response = await _dio.post(
        url,
        data: {
          'duration_seconds': durationSeconds,
          'distance_meters': distanceMeters,
          'route_data': {
            'type': 'LineString',
            'coordinates': routeCoords,
          },
        },
      );

      if (response.statusCode == 201) {
        print('Training results sent successfully!');
        // After successfully sending training results, fetch updated user profile
        await _fetchAndSetCurrentUser();
        // Extract calculated_xp_earned, achievementsEarned, and challengesCompleted
        // from the response data. Backend should be returning these.
        final xpEarned = response.data['xp_earned'];
        final achievementsEarned = response.data['earned_achievements'];
        final challengesCompleted = response.data['completed_challenges'];

        return {
          'runId': response.data['id'],
          'xpEarned': xpEarned,
          'achievementsEarned': achievementsEarned,
          'challengesCompleted': challengesCompleted,
        };
      } else {
        print('Failed to send training results: ${response.statusCode}');
        if (response.data != null) {
          print('Error response data: ${response.data}');
        }
        return null;
      }
    } on DioException catch (e) {
      print('Error sending training results: $e');
      if (e.response != null) {
        print('Error response data: ${e.response?.data}');
      }
      return null;
    }
  }

  // New method to publish a training run to the activity feed
  Future<bool> publishTrainingRun(int runId) async {
    final url = '$baseUrl/runs/$runId/publish_result/';

    try {
      final response = await _dio.post(url);

      if (response.statusCode == 200) {
        print('Training run $runId published successfully!');
        return true;
      } else {
        print('Failed to publish training run $runId: ${response.statusCode}');
        if (response.data != null) {
          print('Error response data: ${response.data}');
        }
        return false;
      }
    } on DioException catch (e) {
      print('Error publishing training run $runId: $e');
      if (e.response != null) {
        print('Error response data: ${e.response?.data}');
      }
      return false;
    }
  }

  // New method to load user session based on tokens
  Future<bool> loadUserSession() async {
    print('AuthService.loadUserSession() called.');
    if (await hasTokens()) {
      print('AuthService.loadUserSession: Tokens are present, attempting to fetch user profile.');
      try {
        await _fetchAndSetCurrentUser(); // Attempt to fetch and set user
        if (_currentUser != null) {
          print('AuthService.loadUserSession: User profile loaded, session valid.');
          return true; // Session valid if tokens and user profile are loaded
        } else {
          print('AuthService.loadUserSession: Tokens present but failed to fetch user profile. Clearing tokens.');
          await deleteTokens(); // Clear tokens if profile fetch fails despite tokens existing
          return false; // Session invalid
        }
      } catch (e) {
        print('AuthService.loadUserSession: Error fetching user profile: $e. Clearing tokens.');
        await deleteTokens(); // Clear tokens on any error during profile fetch
        return false; // Session invalid
      }
    } else {
      print('AuthService.loadUserSession: No tokens found.');
      // No tokens, ensure loggedIn flag is false as well
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_loggedInKey, false); // Ensure flag is false
      print('AuthService.loadUserSession: LoggedIn flag ensured false.');
      return false; // No tokens, session invalid
    }
  }

  // Method to join a challenge
  Future<Response> joinChallenge(int challengeId) async {
    try {
      Response response = await _dio.post('$baseUrl/challenges/$challengeId/join/');
      return response;
    } on DioException catch (e) {
      if (e.response != null) {
        return e.response!;
      } else {
        throw Exception('Error joining challenge: ${e.message}');
      }
    }
  }

  // New method to get user's race attempts
  Future<Response> getUserRaceAttempts({int? userId}) async {
    final url = userId == null ? 
                '$baseUrl/user-race-attempts/' : 
                '$baseUrl/user-race-attempts/?user_id=$userId';
    try {
      print('AuthService.getUserRaceAttempts() called.'); // Debug print
      Response response = await _dio.get(url);
      return response;
    } on DioException catch (e) {
      print('Error fetching user race attempts: ${e.message}');
      rethrow; // Rethrow the exception
    }
  }

  // New method to cancel participation in a challenge
  Future<Response> cancelUserChallenge(int userChallengeId) async {
    try {
      Response response = await _dio.delete('$baseUrl/user-challenges/$userChallengeId/');
      print('AuthService.cancelUserChallenge: Challenge participation cancelled successfully: $userChallengeId');
      return response;
    } on DioException catch (e) {
      if (e.response != null) {
        print('AuthService.cancelUserChallenge: Error cancelling challenge: ${e.response?.statusCode} ${e.response?.data}');
        return e.response!;
      } else {
        print('AuthService.cancelUserChallenge: Network error cancelling challenge: ${e.message}');
        throw Exception('Error cancelling challenge: ${e.message}');
      }
    }
  }

  Future<Map<String, dynamic>?> fetchRunDetails(int runId) async {
    try {
      final response = await getRunDetail(runId);
      if (response.statusCode == 200) {
        final data = response.data;
        // Если это GeoJSON Feature, то нужные поля лежат в properties
        if (data is Map && data.containsKey('properties')) {
          return data['properties'] as Map<String, dynamic>;
        }
        // Если это обычный объект, возвращаем как есть
        return data as Map<String, dynamic>;
      } else {
        print('Failed to fetch run details: [31m 1m${response.statusCode} [0m');
        return null;
      }
    } catch (e) {
      print('Error fetching run details: $e');
      return null;
    }
  }

  Future<Map<String, dynamic>?> fetchRaceAttemptDetails(int attemptId) async {
    try {
      final response = await _dio.get('$baseUrl/user-race-attempts/$attemptId/');
      if (response.statusCode == 200) {
        final data = response.data;
        return data as Map<String, dynamic>;
      } else {
        print('Failed to fetch race attempt details: [31m[1m${response.statusCode}[0m');
        return null;
      }
    } catch (e) {
      print('Error fetching race attempt details: $e');
      return null;
    }
  }

  // Получить таблицу лидеров для трека
  Future<Response> getLeaderboard(String trackId) async {
    final url = '$baseUrl/user-race-attempts/leaderboard/?track_id=$trackId';
    return await _dio.get(url);
  }

  // --- User Blocking Methods ---

  Future<bool> blockUser(int userId) async {
    try {
      final response = await _dio.post('${baseUrl}/user-profiles/$userId/block/');
      if (response.statusCode == 200) {
        print('User $userId blocked successfully.');
        return true;
      }
      return false;
    } on DioException catch (e) {
      print('Error blocking user $userId: ${e.message}');
      return false;
    }
  }

  Future<bool> unblockUser(int userId) async {
    try {
      final response = await _dio.post('${baseUrl}/user-profiles/$userId/unblock/');
      if (response.statusCode == 200) {
        print('User $userId unblocked successfully.');
        return true;
      }
      return false;
    } on DioException catch (e) {
      print('Error unblocking user $userId: ${e.message}');
      return false;
    }
  }

  Future<Map<String, bool>> getBlockStatus(int userId) async {
    try {
      final response = await _dio.get('$baseUrl/blocks/is_blocked/?user_id=$userId');
      if (response.statusCode == 200) {
        return {
          'is_blocked_by_viewer': response.data['is_blocked_by_viewer'] ?? false,
          'viewer_is_blocked': response.data['viewer_is_blocked'] ?? false,
        };
      }
      return {'is_blocked_by_viewer': false, 'viewer_is_blocked': false};
    } on DioException catch (e) {
      print('Error getting block status for user $userId: ${e.message}');
      return {'is_blocked_by_viewer': false, 'viewer_is_blocked': false};
    }
  }
} 